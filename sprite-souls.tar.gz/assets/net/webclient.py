"""Web (pygbag / emscripten) transport: the browser can't open raw sockets, so
this talks to the game server over a real browser WebSocket via pygbag's
`platform.window`. It mirrors NetClient's surface (`snapshot`/`prev`/`snap_at`,
`started`/`ended`/`you`/`running`, `send_input`, `interpolated`) so OnlineScene
and the online loop use it unchanged -- only the transport differs by platform.

Design: a tiny JS shim (injected once) owns the WebSocket and buffers incoming
frames in `window.__ss.msgs`; Python drains that buffer each frame in `pump()`.
Buffering + polling avoids proxying Python callbacks back into JS, which is the
brittle part of the interop.

!!! UNVERIFIED: written against the documented pygbag API but not yet run in a
real browser/pygbag build -- the `platform.window` calls (eval, array access,
ws.send) may need small adjustments once tested on the web. Native play
(net/client.py) is the tested path.
"""
from __future__ import annotations

import json
import time

try:
    import platform            # pygbag provides window/document under emscripten
    _WIN = platform.window
except Exception:              # native/CPython: this module is simply unused
    _WIN = None

_SHIM = """
(function(url, joinMsg){
  var st = { open:false, msgs:[], ws:null, err:null };
  window.__ss = st;
  var ws = new WebSocket(url);
  st.ws = ws;
  ws.onopen = function(){ st.open = true; ws.send(joinMsg); };
  ws.onmessage = function(e){ st.msgs.push(e.data); };
  ws.onerror = function(){ st.err = 'error'; };
  ws.onclose = function(){ st.open = false; };
})(%s, %s);
"""


class WebNetClient:
    def __init__(self, host: str, port: int, pid: str, class_id: str,
                 room: str = "", ticket: str = "", *, tls: bool = True):
        self.host = host
        self.port = port
        self.pid = pid
        self.class_id = class_id
        self.room = room
        self.ticket = ticket
        self.tls = tls

        self.you = pid
        self.started = False
        self.ended = None
        self.roster = []
        self.running = False
        self.error = None

        self.snapshot = None
        self.prev = None
        self.snap_at = 0.0

    def connect(self) -> None:
        if _WIN is None:
            raise RuntimeError("WebNetClient requires a pygbag/browser runtime")
        scheme = "wss" if self.tls else "ws"
        url = f"{scheme}://{self.host}:{self.port}/"
        join = json.dumps({"t": "join", "room": self.room, "pid": self.pid,
                           "ticket": self.ticket, "class": self.class_id})
        _WIN.eval(_SHIM % (json.dumps(url), json.dumps(join)))
        self.running = True

    def pump(self) -> None:
        """Drain buffered frames -- call once per game frame from the loop."""
        if _WIN is None or not self.running:
            return
        st = _WIN.__ss
        if getattr(st, "err", None):
            self.error = "ws error"
            self.running = False
            return
        n = int(st.msgs.length)
        for _ in range(n):
            data = st.msgs.shift()          # FIFO
            self._handle(str(data))

    def _handle(self, raw: str) -> None:
        try:
            m = json.loads(raw)
        except ValueError:
            return
        t = m.get("t")
        if t == "joined":
            self.roster = m.get("roster", [])
        elif t == "start":
            self.you = m.get("you", self.pid)
            self.started = True
        elif t == "snap":
            self.prev = self.snapshot
            self.snapshot = m["s"]
            self.snap_at = time.monotonic()
        elif t == "end":
            self.ended = m.get("winner")
            self.running = False
        elif t == "error":
            self.error = m.get("reason", "error")
            self.running = False

    def send_input(self, move, aim, attack: bool, dodge: bool = False, guard: bool = False) -> None:
        if _WIN is None or not self.running:
            return
        try:
            _WIN.__ss.ws.send(json.dumps(
                {"t": "input", "mv": [move[0], move[1]], "aim": aim,
                 "atk": bool(attack), "dg": bool(dodge), "gd": bool(guard)}))
        except Exception:
            pass

    def interpolated(self):
        return self.snapshot, self.prev, self.snap_at

    def close(self) -> None:
        self.running = False
        try:
            if _WIN is not None:
                _WIN.eval("window.__ss && window.__ss.ws && window.__ss.ws.close();")
        except Exception:
            pass
