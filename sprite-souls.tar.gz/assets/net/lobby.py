"""Native lobby auto-matchmaker: joins (or hosts) a Sprite Souls lobby through the
MisterHighscores API + LobbyHub, waits for an opponent, and returns the game-server
connect info the API hands out via "MatchServerReady". Runs the hub receive in a
background thread (like NetClient) so the launcher keeps rendering a status screen.

Uses the shared config's API_URL + API_KEY (net.signalr_ws for the hub, urllib for
REST) so it's the same key as the rest of MisterHighscores. Web builds don't use
this — the browser lobby page opens the game with the connect info in the URL.
"""
from __future__ import annotations

import json
import socket
import threading
import time
import urllib.request

from .signalr_ws import SignalRClient


class LobbyClient:
    def __init__(self, origin: str, key: str, max_players: int = 2):
        self.origin = origin.rstrip("/")
        self.key = key
        self.max_players = max_players       # 2 = 1v1, higher = multiplayer
        self.sr: SignalRClient | None = None

        self.running = False
        self.status = "connecting"
        self.error = None
        self.connect_info = None       # (host, port, room, pid, ticket) once matched

        self._lobby_id = None
        self._my_slug = None
        self._is_host = False
        self._started = False

    # -- REST -----------------------------------------------------------------
    def _rest(self, method: str, path: str, body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(
            f"{self.origin}/api/{path}", data=data, method=method,
            headers={"X-Api-Key": self.key, "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read()
            return json.loads(raw) if raw else None

    # -- lifecycle ------------------------------------------------------------
    def start(self):
        self.running = True
        threading.Thread(target=self._run, daemon=True).start()

    def close(self):
        self.running = False
        try:
            if self.sr:
                self.sr.close()
        except Exception:
            pass

    def _run(self):
        try:
            me = self._rest("GET", "lobbies/whoami")
            self._my_slug = (me or {}).get("profileSlug")

            open_lobbies = self._rest("GET", "lobbies?gameType=spritesouls") or []
            lobby = next((l for l in open_lobbies
                          if l.get("maxPlayers", 2) == self.max_players
                          and len(l.get("members", [])) < l.get("maxPlayers", 2)), None)
            if lobby:
                lobby = self._rest("POST", f"lobbies/{lobby['id']}/join", {})
                self._is_host = False
                self.status = "joined a lobby"
            else:
                lobby = self._rest("POST", "lobbies",
                                   {"name": "Sprite Souls", "gameType": "spritesouls",
                                    "maxPlayers": self.max_players, "targetScore": 3})
                self._is_host = True
                self.status = "hosting a lobby"

            self._lobby_id = lobby["id"]
            self._rest("POST", f"lobbies/{self._lobby_id}/ready", {"isReady": True})

            self.sr = SignalRClient(self.origin, "/hubs/lobby", self.key)
            self.sr.connect()
            self.sr.sock.settimeout(1.0)                 # so the loop can re-check + keep-alive
            self.sr.send_invocation("JoinLobby", self._lobby_id)
            self.status = "waiting for opponent"

            last_ping = time.monotonic()
            while self.running and self.connect_info is None:
                try:
                    for m in self.sr.recv_messages():
                        self._handle(m)
                except socket.timeout:
                    pass
                except (ConnectionError, OSError) as exc:
                    self.error = repr(exc)
                    break
                if time.monotonic() - last_ping > 10:
                    try:
                        self.sr.send_ping()
                    except Exception:
                        pass
                    last_ping = time.monotonic()
        except Exception as exc:                          # noqa: BLE001 - surface any failure on screen
            self.error = repr(exc)
            self.status = "error"
        finally:
            self.running = False

    def _handle(self, m: dict):
        target = m.get("target")
        args = m.get("arguments", [])
        if target == "MatchServerReady" and args:
            p = args[0]
            mine = next((x for x in p.get("players", [])
                         if x.get("profileSlug") == self._my_slug), None)
            if mine:
                self.connect_info = (p["host"], int(p["port"]), p["room"], mine["pid"], mine["ticket"])
        elif target == "LobbyUpdated" and args and self._is_host and not self._started:
            lob = args[0]
            members = lob.get("members", [])
            if len(members) >= self.max_players and all(x.get("isReady") for x in members):
                self._started = True
                self.status = "starting"
                try:
                    self._rest("POST", f"lobbies/{self._lobby_id}/start")
                except Exception:
                    self._started = False
