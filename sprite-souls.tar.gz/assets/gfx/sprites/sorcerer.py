"""The prelate (the "sorcerer" class) and his staff.

A gold-banded mitre crowned with a cross, no face at all, and a
crimson chasuble: his power is liturgical, not arcane. His votive
flame is shared art and lives in props.py.

**He carries the staff in every view**, and its head is not decoration:
`GameScene.cast_fireball()` starts the fireball at exactly that ember and
flies it at exactly that height, so the spell is seen leaving the thing
that made it. Move the staff in this art and the constants in game.py
(`STAFF_TIP_REACH`, `FIREBALL_LIFT`) have to move with it.

It rides his FAR arm — a stave this tall on the near arm would run down
through the mitre in profile — so it sweeps right → left across the body
as he turns away, and the three right-facing views mirror for the left
half of the compass, which swaps which hand holds it.
"""

from ..facing import DirectionalSprite
from ..pixelart import PixelSprite
from .palette import (BONE, BONE_LIT, CRIMSON, CRIMSON_DEEP, CRIMSON_LIT,
                      EMBER, GOLD, GOLD_DEEP, GOLD_SPEC, HOLLOW, SEPIA,
                      SEPIA_DEEP, VOID)

# 32x32 prelate, front view: a tall gold-banded mitre crowned with a
# cross, no face at all — just a hollow with ember eyes — and a crimson
# chasuble with a gold orphrey down the centre. The "sorcerer": his
# power is liturgical, not arcane.
SORCERER_PALETTE = {
    'd': VOID,          # outline
    'G': GOLD,          # mitre bands, cross, orphrey
    'g': GOLD_DEEP,     # gold shade
    'X': GOLD_SPEC,     # gold specular
    'M': BONE_LIT,      # mitre cloth
    'm': BONE,          # mitre shade
    'K': HOLLOW,        # the hollow where a face should be
    'e': EMBER,         # ember eyes
    'R': CRIMSON,       # chasuble
    'r': CRIMSON_DEEP,  # chasuble shade
    'L': CRIMSON_LIT,   # chasuble rim light
    'W': 0xC9BFA6,      # veil
    'w': 0x968B72,      # veil shade
    # The staff: dark wood under a gold finial, so the gold stays a thin
    # accent and the ember at the head is the only lit thing on it.
    'S': SEPIA,         # shaft
    's': SEPIA_DEEP,    # shaft shade / butt
}

SORCERER_SPRITE = PixelSprite(
    palette=SORCERER_PALETTE,
    rows=(
        '..............dMMd..............',
        '.............dMMMmd.............',
        '............dMMMMMmd............',
        '...........dMXMMMMMmd.......d...',
        '..........dMXMMGGMMMmd.....dGd..',
        '.........dMXMMMGGMMMmmd...dGXGd.',
        '........dMXMMMMGGMMMMmmd..dXeXd.',
        '.......dMXMMMMMGGMMMMMmmd.dGeGd.',
        '......dMXGGGGGGGGGGGGGGmmd.dGd..',
        '......dMXggggggggggggggmmd.dSd..',
        '......dMXMMMMMMGGMMMMMMmmd.dSd..',
        '......dMXMMMMMMGGMMMMMMmmd.dSd..',
        '.....dMXMMMMMMMGGMMMMMMMmmddSd..',
        '.....dGGGGGGGGGGGGGGGGGGGGddSd..',
        '.....dggggggggggggggggggggddSd..',
        '.......dMKKKKKKKKKKKKKKmd..dSd..',
        '.......dMKKeeKKKKKKeeKKmd..dSd..',
        '.......dMKKKKKKKKKKKKKKmd..dSd..',
        '......dWWWWWWWWWWWWWWWWWwd.dSd..',
        '..dLLRRRRRRRRWWWWWWRRRRRRRrdSd..',
        '.dLLRRRRRRRRwWWWWwRRRRRRRRrdSdd.',
        '.dLLRRRRRRRRGGGGGGRRRRRRRRrdSdd.',
        '.dLLRRRRRRRRRRRGGRRRRRRRRRrdSdd.',
        '.dLLRRRRRRRRRRRGGRRRRRRRRRrdSdd.',
        '.dLLRRRRRRRRRRRGGRRRRRRRRRrdSdd.',
        '.dLLRRRRRRRRRRRGGRRRRRRRRRrdSdd.',
        '.dLLRRRRRRRRRRRGGRRRRRRRRRrdSdd.',
        '.dLLRRRRRrRRRRRGGRRRRrRRRRrdsdd.',
        '.dLLRRRRRrRRRRRGGRRRRrRRRRrrdrd.',
        '.dLGGGGGGGGGGGGGGGGGGGGGGGGGGrd.',
        '.dLggggggggggggggggggggggggggrd.',
        '...drrd...drrd....drrd...drrd...',
    ),
)

# Back: the mitre is symmetric, so what tells you this is the reverse is
# the pair of infulae — the lappets that hang off the back of a real
# mitre — falling either side of a gold cross on the chasuble, and cloth
# where the hollow face was.
SORCERER_BACK_SPRITE = PixelSprite(
    palette=SORCERER_PALETTE,
    rows=(
        '..............dMMd..............',
        '.............dMMMmd.............',
        '............dMMMMMmd............',
        '...d.......dMXMMMMMmd...........',
        '..dGd.....dMXMMGGMMMmd..........',
        '.dGXGd...dMXMMMGGMMMmmd.........',
        '.dXeXd..dMXMMMMGGMMMMmmd........',
        '.dGeGd.dMXMMMMMGGMMMMMmmd.......',
        '..dGd.dMXGGGGGGGGGGGGGGmmd......',
        '..dSd.dMXggggggggggggggmmd......',
        '..dSd.dMXMMMMMMGGMMMMMMmmd......',
        '..dSd.dMXMMMMMMGGMMMMMMmmd......',
        '..dSddMXMMMMMMMGGMMMMMMMmmd.....',
        '..dSddGGGGGGGGGGGGGGGGGGGGd.....',
        '..dSddggggggggggggggggggggd.....',
        '..dSd..dMMMMMMMMMMMMMMMMmd......',
        '..dSd..dMMMMMmMMMMmMMMMMmd......',
        '..dSd..dmmmmmmmmmmmmmmmmmd......',
        '..dSd.dWWWWWWWWWWWWWWWWWwd......',
        '..dSdRRRRRRRRWWWWWWRRRRRRRrrrd..',
        '.ddSdRRRRRRRwWWWWwRRRRRRRRrrrrd.',
        '.ddSdRRRWWRRRRGGRRRRWWRRRRrrrrd.',
        '.ddSdRRRWWRRRRGGRRRRWWRRRRrrrrd.',
        '.ddSdRRRWWRGGGGGGGGRWWRRRRrrrrd.',
        '.ddSdRRRWWRggggggggRWWRRRRrrrrd.',
        '.ddSdRRRWWRRRRGGRRRRWWRRRRrrrrd.',
        '.ddSdRRRWWRRRRGGRRRRWWRRRRrrrrd.',
        '.ddsdRRRwwRRRRGGRRRRwwRRRRrrrrd.',
        '.dLdRRRRGGRRRRGGRRRRGGRRRRrrrrd.',
        '.dLGGGGGGGGGGGGGGGGGGGGGGGGGGrd.',
        '.dLggggggggggggggggggggggggggrd.',
        '...drrd...drrd....drrd...drrd...',
    ),
)

# Side: a mitre in profile is a blade, not a cone — the narrowest
# silhouette in the cast, which is exactly what makes the prelate's turn
# read from across the arena. The gold orphrey runs over the crown and
# down the leading edge of the chasuble.
SORCERER_SIDE_SPRITE = PixelSprite(
    palette=SORCERER_PALETTE,
    rows=(
        '..............dMd...............',
        '.............dMMmd..............',
        '.............dMMmd..............',
        '............dMXMmmd.............',
        '.....d......dMXMmmd.............',
        '....dGd....dMXMGmmmd............',
        '...dGXGd...dMXMGmmmd............',
        '...dXeXd..dMXMMGMmmmd...........',
        '...dGeGd..dGGGGGGGGGd...........',
        '....dGd...dgggggggggd...........',
        '....dSd...dMXMMGMmmmd...........',
        '....dSd...dMXMMGMmmmd...........',
        '....dSd..dMXMMMGMmmmmd..........',
        '....dSd..dGGGGGGGGGGGd..........',
        '....dSd..dgggggggggggd..........',
        '....dSd...dMMMKKKKKKd...........',
        '....dSd...dMMMKKeKKKd...........',
        '....dSd...dMMMKKKKKKd...........',
        '....dSd.dWWWWWWWWWWWWWwd........',
        '....dSdLRRRRRRRWWWWRRRRrrd......',
        '....ddLRRRRRRRRwWWwRRRRRrrd.....',
        '....ddLRRRRRRRRRRRRRRRGGrrd.....',
        '....ddLRRRRRRRRRRRRRRRGGrrd.....',
        '....ddLRRRRRRRRRRRRRRRGGrrd.....',
        '....ddLRRRRRRRRRRRRRRRGGrrd.....',
        '....ddLRRRRRRRRRRRRRRRGGrrd.....',
        '....ddLRRRRRRRRRRRRRRRGGrrd.....',
        '....ddLRRRRRrRRRRRRRRRGGrrd.....',
        '....ddLRRRRRrRRRRRRRRRGGrrd.....',
        '.....dLGGGGGGGGGGGGGGGGGGrd.....',
        '.....dLggggggggggggggggggrd.....',
        '.......drrd.......drrd..........',
    ),
)

# Three-quarters toward the camera: the mitre is caught between its
# broad face and its narrow blade, so it is the one body whose turn reads
# from the silhouette alone. The orphrey slides off centre and the
# trailing ember eye drops to a single pixel.
SORCERER_FRONT_SIDE_SPRITE = PixelSprite(
    palette=SORCERER_PALETTE,
    rows=(
        '...............dMd..............',
        '..............dMMmd.............',
        '..............dMMmd.............',
        '.............dMXMMmmd.......d...',
        '...........dMXMMGGMmmd.....dGd..',
        '..........dMXMMMGGMMmmd...dGXGd.',
        '..........dMXMMMGGMMMmmd..dXeXd.',
        '.........dMXMMMMGGMMMmmmd.dGeGd.',
        '........dMXGGGGGGGGGGGGmmd.dGd..',
        '........dMXggggggggggggmmd.dSd..',
        '........dMXMMMMGGMMMMMmmd..dSd..',
        '........dMXMMMMGGMMMMMmmd..dSd..',
        '.......dMXMMMMMGGMMMMMMmmd.dSd..',
        '.......dGGGGGGGGGGGGGGGGGGddSd..',
        '.......dggggggggggggggggggddSd..',
        '........dMKKKKKKKKKKKKmd...dSd..',
        '........dMKeKKKKKKeeKKmd...dSd..',
        '........dMKKKKKKKKKKKKmd...dSd..',
        '.......dWWWWWWWWWWWWWWWwd..dSd..',
        '...dLLRRRRRRRWWWWWWRRRRrrrddSd..',
        '..dLLRRRRRRRwWWWWwRRRRRrrrrdSd..',
        '..dLLRRRRRRRRGGGGGGRRRRrrrrdSd..',
        '..dLLRRRRRRRRRRRGGRRRRrrrrrdSd..',
        '..dLLRRRRRRRRRRRGGRRRRrrrrrdSd..',
        '..dLLRRRRRRRRRRRGGRRRRrrrrrdSd..',
        '..dLLRRRRRRRRRRRGGRRRRrrrrrdSd..',
        '..dLLRRRRRRRRRRRGGRRRRrrrrrdSd..',
        '..dLLRRRRRrRRRRRGGRRRRrrrrrdsd..',
        '..dLLRRRRRrRRRRRGGRRRRrrrrrdd...',
        '..dLGGGGGGGGGGGGGGGGGGGGGGrd....',
        '..dLggggggggggggggggggggggrd....',
        '....drrd...drrd....drrd.........',
    ),
)

# Three-quarters away: mitre cloth where the hollow was, and the two
# infulae plus the chasuble's gold cross all slide left of centre —
# together they read as a back turned away rather than a flat panel.
SORCERER_BACK_SIDE_SPRITE = PixelSprite(
    palette=SORCERER_PALETTE,
    rows=(
        '...............dMd..............',
        '..............dMMmd.............',
        '..............dMMmd.............',
        '...d.........dMXMMmmd...........',
        '..dGd......dMXMMGGMmmd..........',
        '.dGXGd....dMXMMMGGMMmmd.........',
        '.dXeXd....dMXMMMGGMMMmmd........',
        '.dGeGd...dMXMMMMGGMMMmmmd.......',
        '..dGd...dMXGGGGGGGGGGGGmmd......',
        '..dSd...dMXggggggggggggmmd......',
        '..dSd...dMXMMMMGGMMMMMmmd.......',
        '..dSd...dMXMMMMGGMMMMMmmd.......',
        '..dSd..dMXMMMMMGGMMMMMMmmd......',
        '..dSd..dGGGGGGGGGGGGGGGGGGd.....',
        '..dSd..dggggggggggggggggggd.....',
        '..dSd...dMMMMMMMMMMMMMMd........',
        '..dSd...dMMMmMMMMMmMMMMd........',
        '..dSd...dmmmmmmmmmmmmmmd........',
        '..dSd..dWWWWWWWWWWWWWWWwd.......',
        '..ddLLRRRRRRRWWWWWWRRRRrrrd.....',
        '..dLLRRRRRRRwWWWWwRRRRRrrrrd....',
        '..dLLRWWRRRRGGRRRRWWRRrrrrrd....',
        '..dLLRWWRRRRGGRRRRWWRRrrrrrd....',
        '..dLLRWWRGGGGGGGGRWWRRrrrrrd....',
        '..dLLRWWRggggggggRWWRRrrrrrd....',
        '..dLLRWWRRRRGGRRRRWWRRrrrrrd....',
        '..dLLRWWRRRRGGRRRRWWRRrrrrrd....',
        '..dLLRwwRRRRGGRRRRwwRRrrrrrd....',
        '..dLLRGGRRRRGGRRRRGGRRrrrrrd....',
        '..dLGGGGGGGGGGGGGGGGGGGGGGrd....',
        '..dLggggggggggggggggggggggrd....',
        '....drrd...drrd....drrd.........',
    ),
)

SORCERER_VIEWS = DirectionalSprite(front=SORCERER_SPRITE,
                                   back=SORCERER_BACK_SPRITE,
                                   side=SORCERER_SIDE_SPRITE,
                                   front_side=SORCERER_FRONT_SIDE_SPRITE,
                                   back_side=SORCERER_BACK_SIDE_SPRITE)
