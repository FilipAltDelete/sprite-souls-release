"""The pixel-art system. Sprites are defined AS TEXT (see sprites/):
arrays of strings where each character is a pixel, '.' is transparent
and other characters index a per-sprite palette. There are no image
asset files — to add or change art, edit the pixel maps. This also
means the web (pygbag) build has zero assets to download."""

import math
from dataclasses import dataclass
from typing import Dict, List

import pygame

from . import platform


@dataclass(frozen=True)
class PixelSprite:
    rows: tuple
    palette: Dict[str, int]


def rgb(color: int):
    """0xRRGGBB int -> (r, g, b) tuple."""
    return ((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF)


_surface_cache: Dict[tuple, pygame.Surface] = {}
_tint_cache: Dict[tuple, pygame.Surface] = {}
_scale_cache: Dict[tuple, pygame.Surface] = {}
_flip_cache: Dict[int, pygame.Surface] = {}
_squash_cache: Dict[tuple, pygame.Surface] = {}


def create_pixel_surface(sprite: PixelSprite, pixel_size: int = 1) -> pygame.Surface:
    """Render a PixelSprite into a pygame Surface. `pixel_size` scales
    each art pixel up (1 = a 32x32 sprite becomes a 32x32 surface)."""
    key = (id(sprite), pixel_size)
    cached = _surface_cache.get(key)
    if cached is not None:
        return cached

    width = len(sprite.rows[0]) * pixel_size
    height = len(sprite.rows) * pixel_size
    surf = pygame.Surface((width, height), pygame.SRCALPHA)
    for y, row in enumerate(sprite.rows):
        for x, ch in enumerate(row):
            if ch == '.':
                continue
            color = sprite.palette.get(ch)
            if color is None:
                raise ValueError(f"Pixel sprite: no palette entry for '{ch}'")
            surf.fill(rgb(color), (x * pixel_size, y * pixel_size, pixel_size, pixel_size))
    _surface_cache[key] = surf
    return surf


def tint_fill(surf: pygame.Surface, color: int) -> pygame.Surface:
    """Solid-color silhouette keeping alpha (Phaser setTintFill)."""
    key = (id(surf), 'fill', color)
    cached = _tint_cache.get(key)
    if cached is None:
        mask = pygame.mask.from_surface(surf)
        cached = mask.to_surface(setcolor=rgb(color) + (255,), unsetcolor=(0, 0, 0, 0))
        _tint_cache[key] = cached
    return cached


def tint_mult(surf: pygame.Surface, color: int) -> pygame.Surface:
    """Multiply tint keeping alpha (Phaser setTint)."""
    key = (id(surf), 'mult', color)
    cached = _tint_cache.get(key)
    if cached is None:
        cached = surf.copy()
        cached.fill(rgb(color), special_flags=pygame.BLEND_RGB_MULT)
        _tint_cache[key] = cached
    return cached


def scaled(surf: pygame.Surface, scale: float) -> pygame.Surface:
    """Nearest-neighbour scale with a small cache (scale rounded to 2
    decimals — plenty for the dragon's takeoff/landing growth)."""
    scale = round(scale, 2)
    if scale == 1:
        return surf
    key = (id(surf), scale)
    cached = _scale_cache.get(key)
    if cached is None:
        w = max(1, int(surf.get_width() * scale))
        h = max(1, int(surf.get_height() * scale))
        cached = pygame.transform.scale(surf, (w, h))
        _scale_cache[key] = cached
    return cached


def flipped(surf: pygame.Surface) -> pygame.Surface:
    """Mirror horizontally, cached. Side-view art is only ever drawn
    facing screen-right; the left-facing view is this."""
    cached = _flip_cache.get(id(surf))
    if cached is None:
        cached = pygame.transform.flip(surf, True, False)
        _flip_cache[id(surf)] = cached
    return cached


def squash_x(surf: pygame.Surface, factor: float) -> pygame.Surface:
    """Narrow a surface horizontally without changing its height — one
    frame of the turn animation (see gfx/facing.py). Cached by the
    *resulting pixel width*, so a whole turn can only ever cost as many
    scales as the sprite is wide."""
    width = max(1, round(surf.get_width() * factor))
    if width == surf.get_width():
        return surf
    key = (id(surf), width)
    cached = _squash_cache.get(key)
    if cached is None:
        cached = pygame.transform.scale(surf, (width, surf.get_height()))
        _squash_cache[key] = cached
    return cached


_tilt_cache: Dict[tuple, pygame.Surface] = {}


def tilted(surf: pygame.Surface, degrees: float) -> pygame.Surface:
    """A body rocked about its own FEET rather than its centre — one
    frame of the walk (see GameScene.walk_tilt).

    Rotating a standing sprite about its middle would swing its feet out
    from under it. So the sprite is first padded onto a square canvas
    with its midbottom at the canvas centre, and only then rotated: the
    pivot comes back at the centre of the result, which is why the caller
    places these by that centre — `camera.blit_body` — rather than by
    the sprite's midbottom.

    An upright body is handed straight back untouched: no canvas, no
    rotation, nothing cached. That matters more than it looks — bodies
    spend most of their lives upright (standing, attacking, flying), and
    the wyrm's takeoff alone scales through dozens of sprite sizes that
    would each want a canvas of their own. It also means the caller must
    place the result differently depending on whether it leaned, which is
    what `camera.blit_body` is for.

    Cached by whole degrees, and a canvas is ~5x the area of the sprite,
    so what does get cached costs real memory: one entry per (view, tint,
    pose). That is why the caller quantises its lean to a few poses and
    holds it at zero mid-turn — feed this a continuous angle or every
    frame of a turn squash and it will happily cache thousands.
    """
    degrees = round(degrees)
    if degrees == 0:
        return surf
    key = (id(surf), degrees)
    cached = _tilt_cache.get(key)
    if cached is None:
        w, h = surf.get_size()
        # Big enough that no corner of the sprite leaves the canvas at
        # any angle: the far corner is hypot(w/2, h) from the pivot.
        size = 2 * math.ceil(math.hypot(w / 2, h)) + 2
        pad = pygame.Surface((size, size), pygame.SRCALPHA)
        pad.blit(surf, (size // 2 - w // 2, size // 2 - h), special_flags=platform.ALPHA_BLIT)
        cached = pygame.transform.rotate(pad, degrees)
        _tilt_cache[key] = cached
    return cached


def draw_pointing(target: pygame.Surface, img: pygame.Surface,
                  grip_x: float, grip_y: float, angle_rad: float) -> None:
    """Draw an up-pointing sprite pivoted at its bottom-center 'grip',
    rotated to point along `angle_rad` (screen coords, y down). This is
    the pygame equivalent of Phaser's setOrigin(0.5, 1) + setRotation."""
    h = img.get_height()
    cx = grip_x + math.cos(angle_rad) * h / 2
    cy = grip_y + math.sin(angle_rad) * h / 2
    rot = pygame.transform.rotate(img, -math.degrees(angle_rad) - 90)
    target.blit(rot, rot.get_rect(center=(round(cx), round(cy))),
                special_flags=platform.ALPHA_BLIT)
