from core.units import UNIT

# Logical render resolution. The window is scaled to fit; drawing always
# works in this coordinate space. Screen pixels, never world units — the
# world is bigger than this in both directions and the camera scrolls
# across it (gfx/camera.py).
WIDTH = 1280
HEIGHT = 720
FPS = 60

# The world is a flat plane viewed through a tilted camera (see
# gfx/camera.py), so its depth axis is foreshortened on screen by this
# factor. ALL gameplay — positions, ranges, collision — happens in world
# units on that plane; only drawing goes through the projection.
CAMERA_TILT = 0.6

# The playable plane. Both of these are larger than the view can show at
# once, which is the camera's whole job: it scrolls to keep the player
# out of the edges of the frame (gfx/camera.py) and stops at the world's
# own edge, while the player keeps walking to it.
#
# WORLD_W used to be written as the identity `WORLD_W = WIDTH`, because a
# camera that cannot move plus an oblique projection (screen_x ==
# world_x) can only ever show a world exactly as wide as the screen. The
# projection is still oblique — the camera just takes its own scroll off
# afterwards, so world x still maps to screen x one for one without
# having to start in the same place. Dropping that identity is what made
# a bigger map possible at all.
#
# Depth is foreshortened when drawn (2400 * 0.6 = 1440 rows, two screens
# deep) but never in the sim, so a world unit north-south is worth the
# same as one east-west to everything except the eye.
WORLD_W = 100 * UNIT            # 3200 — two and a half screens across
WORLD_H = 75 * UNIT             # 2400
