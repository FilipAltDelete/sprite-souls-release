"""Character class definitions: starting attributes, growth and attack
config. Data-driven — adding a class means an entry here, a module in
gfx/sprites/ and a mapping in CLASS_SPRITES. No pygame imports."""

from dataclasses import dataclass

from .stats import Attributes
from .units import SECOND, UNIT

# Attack styles: 'slash' (sword sweep), 'stab' (dagger jab),
# 'fireball' (projectile).
# Dodge styles: 'roll' (a committed ground roll) and 'blink' (an
# instant, cursor-aimed teleport).
# Guard styles: 'shield' (a stance held while E is down, covering the
# arc it is pointed at), 'barrier' (a timed ward covering every
# direction) and 'parry' (a short window that staggers what it catches).


@dataclass(frozen=True)
class ClassAttack:
    style: str
    # Multiplies derived attack_speed (attacks per second).
    speed_multiplier: float
    # Multiplies derived attack_damage (melee styles only).
    damage_multiplier: float
    # Melee reach, or projectile travel distance for fireball.
    range: float
    # Half-width of the melee swing arc in degrees (0 for projectiles).
    half_arc_degrees: float
    # Mana spent per cast (spell styles only).
    mana_cost: float = 0.0
    # How many swings one attack plays. Each lands its share of the
    # damage, so a pair is a flurry rather than twice the hurt — the
    # flagellant has a knife in each hand and uses both.
    swings: int = 1


@dataclass(frozen=True)
class ClassDodge:
    style: str
    # Shown on the class-select card — a mechanic that differs per class
    # is worth naming, or the player only finds out by dying.
    name: str
    # How long the i-frames last. A roll is committed for exactly this
    # long; a blink has already arrived, so this is grace time only.
    duration_ms: float
    # Idle time after the dodge ends before it can be used again.
    cooldown_ms: float
    # Roll only: multiplies move_speed for the length of the roll, so
    # the distance covered is move_speed * this * duration.
    speed_multiplier: float = 1.0
    # Blink only: world units crossed instantly.
    distance: float = 0.0


@dataclass(frozen=True)
class ClassGuard:
    style: str
    # Shown on the class-select card, like the dodge's: a defence that
    # works differently per class has to be readable before the fight.
    name: str
    # How long the guard holds. A shield is a maximum (it can be let go
    # of sooner, and breaks if it is not); the other two run in full.
    duration_ms: float
    # Idle time after the guard ends before it can be raised again.
    cooldown_ms: float
    # Half-width of the arc the guard covers, measured off the player's
    # facing_angle. 180 covers every direction (the ward); anything less
    # has to be *pointed* at the blow, so turning is part of defending.
    half_arc_degrees: float = 180.0
    # Parry only: how long a boss whose blow is caught is staggered.
    stun_ms: float = 0.0
    # Shield only: fraction of move_speed kept while the stance is up.
    move_multiplier: float = 1.0
    # Barrier only: mana spent to raise it.
    mana_cost: float = 0.0


@dataclass(frozen=True)
class CharacterClass:
    id: str
    name: str
    description: str
    base_attributes: Attributes
    # Attribute gains automatically applied on each level-up.
    growth_per_level: Attributes
    attack: ClassAttack
    dodge: ClassDodge
    guard: ClassGuard
    # Multiplies derived move_speed (1 = normal).
    move_speed_multiplier: float
    # Accent color for UI (class-select cards, name tints).
    color: int


CLASSES = {
    'knight': CharacterClass(
        id='knight',
        name='Knight',
        description='A stalwart armored fighter. High health and heavy hits.',
        base_attributes=Attributes(strength=12, dexterity=8, intelligence=4, vitality=12),
        growth_per_level=Attributes(strength=3, dexterity=1, intelligence=0, vitality=2),
        attack=ClassAttack(style='slash', speed_multiplier=1, damage_multiplier=1,
                           range=1.875 * UNIT, half_arc_degrees=75),
        # The reference dodge the other two are tuned against.
        dodge=ClassDodge(style='roll', name='Roll', duration_ms=0.3 * SECOND,
                         cooldown_ms=0.8 * SECOND, speed_multiplier=1.3),
        # The only guard that is a *stance*: held down, aimed by turning,
        # and paid for with the two things he otherwise has — his swing
        # and his feet. Nothing inside the arc gets through at all, which
        # is what the 1.5s cap and the broken guard are there to bound.
        guard=ClassGuard(style='shield', name='Shield block',
                         duration_ms=1.5 * SECOND, cooldown_ms=0.7 * SECOND,
                         half_arc_degrees=100, move_multiplier=0.45),
        move_speed_multiplier=1,
        color=0xC0392B,
    ),
    'sorcerer': CharacterClass(
        id='sorcerer',
        name='Sorcerer',
        description='A fragile spellcaster. Big mana pool, bigger explosions.',
        base_attributes=Attributes(strength=4, dexterity=7, intelligence=15, vitality=6),
        growth_per_level=Attributes(strength=0, dexterity=1, intelligence=4, vitality=1),
        attack=ClassAttack(style='fireball', speed_multiplier=0.8, damage_multiplier=1,
                           range=10.625 * UNIT, half_arc_degrees=0, mana_cost=6),
        # He doesn't roll — he steps out of the world and back into it
        # somewhere else. Roughly three knight-rolls of ground, crossed
        # in no time at all, which is what pays for the shorter i-frames
        # and the longer cooldown.
        dodge=ClassDodge(style='blink', name='Blink (aimed)',
                         duration_ms=0.2 * SECOND, cooldown_ms=1 * SECOND,
                         distance=6.5625 * UNIT),
        # Cast and forgotten about: two seconds where nothing at all
        # touches him, from any direction, while he keeps moving and
        # casting. It costs two fireballs, and the cooldown is longer
        # than the ward so it can never simply be left on.
        guard=ClassGuard(style='barrier', name='Barrier (2s)',
                         duration_ms=2 * SECOND, cooldown_ms=3.5 * SECOND,
                         mana_cost=12),
        move_speed_multiplier=1,
        color=0x4653C9,
    ),
    'thief': CharacterClass(
        id='thief',
        name='Thief',
        description='A swift shadow. Fast attacks and faster feet.',
        base_attributes=Attributes(strength=8, dexterity=14, intelligence=6, vitality=8),
        growth_per_level=Attributes(strength=1, dexterity=3, intelligence=1, vitality=1),
        attack=ClassAttack(style='stab', speed_multiplier=2.6, damage_multiplier=0.4,
                           range=1.375 * UNIT, half_arc_degrees=75, swings=2),
        # The knight's roll, but it carries much further: a longer burst
        # held for longer, on top of the class's own faster feet.
        dodge=ClassDodge(style='roll', name='Long roll', duration_ms=0.38 * SECOND,
                         cooldown_ms=0.8 * SECOND, speed_multiplier=1.8),
        # A window, not a wall: a fifth of the knight's block, pointed at
        # a narrower arc, and worth nothing at all unless it is open at
        # the moment the blow lands. What it buys is the one second the
        # boss spends staggered afterwards.
        guard=ClassGuard(style='parry', name='Parry (stuns)',
                         duration_ms=0.3 * SECOND, cooldown_ms=1.1 * SECOND,
                         half_arc_degrees=70, stun_ms=1 * SECOND),
        move_speed_multiplier=1.5,
        color=0x3E7D4F,
    ),
}

# Card order on the class-select screen.
CLASS_ORDER = ['knight', 'sorcerer', 'thief']
