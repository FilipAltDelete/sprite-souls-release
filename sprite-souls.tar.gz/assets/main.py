"""Sprite Souls 3 — pygame-ce entry point.

The game loop is async so the SAME file runs both natively (MiSTer,
desktop) and as WebAssembly via pygbag: the browser build needs
`await asyncio.sleep(0)` every frame to yield to the event loop, and
plain CPython runs the identical loop through asyncio.run().
"""

import asyncio
import math
import sys

import pygame

import sfx
from scenes.class_select import ClassSelectScene
from scenes.game import GameScene
from scenes.manager import SceneManager
from settings import FPS, HEIGHT, WIDTH


def _online_config():
    """(host, port, room, pid, ticket, class_id) if an online match was asked for,
    else None. On the web the lobby opens the page with ?server=host:port&room=..
    &pid=..&ticket=..&class=..; on desktop pass --online host:port room pid ticket [class]."""
    if sys.platform == 'emscripten':
        try:
            import urllib.parse
            import platform
            q = urllib.parse.parse_qs(str(platform.window.location.search).lstrip('?'))
            get = lambda k, d='': q.get(k, [d])[0]
            server = get('server')
            if not server:
                return None
            host, _, port = server.partition(':')
            return (host, int(port or 443), get('room'), get('pid'), get('ticket'), get('class', 'knight'))
        except Exception:
            return None
    if '--online' in sys.argv:
        a = sys.argv[sys.argv.index('--online') + 1:][:5]
        if len(a) >= 4:
            host, _, port = a[0].partition(':')
            return (host, int(port or 8765), a[1], a[2], a[3], a[4] if len(a) > 4 else 'knight')
    return None


async def run_online(screen, clock, cfg):
    """Play a 1v1 against the authoritative server. Input: WASD move, mouse aim,
    Space / left-click attack. Rendering is snapshot-driven (server-authoritative)."""
    from scenes.online import OnlineScene
    from gfx import camera
    host, port, room, pid, class_id = cfg[0], cfg[1], cfg[2], cfg[3], cfg[5]
    ticket = cfg[4]
    if sys.platform == 'emscripten':
        from net.webclient import WebNetClient
        net = WebNetClient(host, port, pid, class_id, room, ticket, tls=(port == 443))
    else:
        from net.client import NetClient
        net = NetClient(host, port, pid, class_id, room, ticket)
    net.connect()
    scene = OnlineScene(net)

    running = True
    while running and getattr(net, 'running', True):
        dt = min(clock.tick(FPS), 50)
        if hasattr(net, 'pump'):
            net.pump()                     # web transport drains its WS buffer here
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        mvx = (1 if keys[pygame.K_d] else 0) - (1 if keys[pygame.K_a] else 0)
        mvy = (1 if keys[pygame.K_s] else 0) - (1 if keys[pygame.K_w] else 0)
        aim = None
        snap = net.snapshot
        if snap:
            me = next((p for p in snap['players'] if p['id'] == net.you), None)
            if me:
                sx, sy = camera.project(me['x'], me['y'])
                mx, my = pygame.mouse.get_pos()
                aim = math.atan2(my - sy, mx - sx)
        attack = keys[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]
        dodge = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]
        guard = keys[pygame.K_e]
        net.send_input((mvx, mvy), aim, attack, dodge=dodge, guard=guard)

        scene.update(dt)
        scene.draw(screen)
        pygame.display.flip()
        await asyncio.sleep(0)

    if hasattr(net, 'close'):
        net.close()


async def run_offline(screen, clock):
    manager = SceneManager()
    manager.add('class-select', ClassSelectScene(manager))
    manager.add('game', GameScene(manager))
    manager.start('class-select')

    while manager.running:
        # Cap the step so a background tab / hiccup can't produce a
        # giant delta that teleports everything.
        dt_ms = min(clock.tick(FPS), 50)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                manager.quit()
            else:
                manager.current.handle_event(event)

        manager.current.update(dt_ms)
        manager.current.draw(screen)
        pygame.display.flip()

        # Mandatory for the web build: hand control back to the browser.
        await asyncio.sleep(0)


async def main():
    pygame.init()
    sfx.init()

    flags = 0
    if sys.platform != 'emscripten':  # pygbag/web: plain windowed surface
        flags = pygame.SCALED
        if '--fullscreen' in sys.argv:
            flags |= pygame.FULLSCREEN
    screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)
    pygame.display.set_caption('Sprite Souls 3')
    clock = pygame.time.Clock()

    online = _online_config()
    if online:
        await run_online(screen, clock, online)
    else:
        await run_offline(screen, clock)

    pygame.quit()


asyncio.run(main())
