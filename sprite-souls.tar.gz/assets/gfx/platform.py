"""Platform render adaptations, isolated so the rest of the game stays clean.

On the MiSTer FPGA (DE10-Nano, ARMv7 Cortex-A9) two pygame operations fault --
verified on real hardware:
  * pygame's own per-pixel-alpha blitter (RGBA source -> RGBA destination)
    aborts (SIGABRT); routing the same blit through SDL2's blitter is fine.
  * transform.smoothscale segfaults (SIGSEGV); nearest-neighbour scale is fine
    (and is the correct look at 240p anyway).
Only the intermediate composites that build onto an SRCALPHA scratch hit the
first case -- the main scene surface is opaque, so ordinary sprite draws
(SRCALPHA -> opaque) are already safe.

MiSTer mode is opt-in via the SS_MISTER env var (set by the MiSTer launcher), so
every value here is a no-op on desktop and web and PC/web behaviour is unchanged.
"""

import os

import pygame

IS_MISTER = bool(os.environ.get("SS_MISTER"))

# Headless authoritative-server role: the sim runs with no display/audio/text.
# Presentation primitives (render_text, sfx, add_effect) short-circuit so the
# server never builds surfaces it won't draw and needs no libSDL2_ttf.
IS_HEADLESS = bool(os.environ.get("SS_HEADLESS"))

# special_flags for a blit that composites a per-pixel-alpha source ONTO a
# per-pixel-alpha surface. 0 keeps pygame's default blitter off MiSTer.
ALPHA_BLIT = pygame.BLEND_ALPHA_SDL2 if IS_MISTER else 0


def smoothscale(surf: pygame.Surface, size) -> pygame.Surface:
    """smoothscale, except on MiSTer where it faults -> nearest scale."""
    if IS_MISTER:
        return pygame.transform.scale(surf, size)
    return pygame.transform.smoothscale(surf, size)
