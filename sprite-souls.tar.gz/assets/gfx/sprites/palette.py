"""The shared colour ramps every sprite draws from.

Blasphemous never uses pure black or fully saturated colour.
Outlines are warm/cold near-blacks; every ramp is 3 steps (deep /
mid / light) plus an optional specular. Reuse these before
inventing a new hue, and if you tune one, tune it here so the whole
cast stays in step.
"""

VOID = 0x140F14        # warm near-black — outlines, the dark inside a hood
VOID_COLD = 0x0E161C   # cold near-black — outlines on the frost cast
HOLLOW = 0x0B0908      # the shadow inside a hood/mask: darker than any outline

BONE_DEEP = 0x8A785A   # bone / ivory ramp — the dominant "light" of the world
BONE = 0xC4B394
BONE_LIT = 0xE3D5B4
BONE_SPEC = 0xFBF6E6

GOLD_DEEP = 0x8A6A18   # tarnished liturgical gold — trim, halos, reliquaries
GOLD = 0xC9A227
GOLD_SPEC = 0xF3E7C0

CRIMSON_DEEP = 0x4E0C13  # the single saturated accent: blood / vestments
CRIMSON = 0x8E1C22
CRIMSON_LIT = 0xA83240

SEPIA_DEEP = 0x2E2619   # sackcloth / leather / weathered wood
SEPIA_MID = 0x4A3D2B
SEPIA = 0x6B5940
SEPIA_LIT = 0x9A8060

EMBER = 0xE86A2A       # what looks back at you out of the dark
