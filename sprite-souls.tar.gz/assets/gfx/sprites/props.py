"""Art used by more than one character, so it belongs to none of them.

The votive flame is both the prelate's cast projectile and the
particle the devil's fire breath sprays.
"""

from ..pixelart import PixelSprite

# 16x16 votive flame: a pale-gold core in amber fire with a deep blood
# rim — holy fire, not a fireball.
FIREBALL_SPRITE = PixelSprite(
    palette={
        'o': 0xA83A1E,  # ember rim
        'O': 0x6B1418,  # deep blood flicker
        'Y': 0xE3A72A,  # amber flame
        'W': 0xFFF3D0,  # pale-gold core
    },
    rows=(
        '.......Y........',
        '......YWY.......',
        '.....oYWWY......',
        '....oYYWWYo.....',
        '...oYYWWWWYo....',
        '..OoYYWWWWYYo...',
        '..OoYWWWWWWYo...',
        '.OoYYWWWWWWYYo..',
        '.OoYYWWWWWWYYo..',
        '..OoYYWWWWYYo...',
        '..OooYYWWYYoo...',
        '...OooYYYYoo....',
        '....OooYYoo.....',
        '.....OoooO......',
        '......OoO.......',
        '................',
    ),
)
