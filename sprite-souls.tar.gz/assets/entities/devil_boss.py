"""Boss 1: the devil duelist. Two attacks, each with its own telegraph
color: an orange-flash windup into a trident lunge (contact damage),
and a red-flash windup into a fire-breath cone. It reactively dodges
player attacks with i-frames."""

import math
import random

from core.mathutil import angle_between, dist, wrap_angle
from core.units import PX, SECOND, UNIT
from gfx import camera
from gfx.pixelart import create_pixel_surface, draw_pointing, tint_mult
from gfx.sprites import DEVIL_VIEWS, FIREBALL_SPRITE, TRIDENT_SPRITE
from scenes.effects import LerpParticle

from .boss import AreaHit, Boss

# Distances and speeds are world units (speeds per second); see core/units.
AGGRO_RANGE = 10 * UNIT
# Close enough to consider opening an attack.
STRIKE_RANGE = 2.5 * UNIT
CHASE_SPEED = 3.125 * UNIT
STRAFE_SPEED = 2.1875 * UNIT
WANDER_SPEED = 1.25 * UNIT
LUNGE_SPEED = 11.25 * UNIT
DODGE_SPEED = 10 * UNIT
# Telegraph duration before the lunge — the player's reaction window.
WINDUP_MS = 0.45 * SECOND
LUNGE_MS = 0.22 * SECOND
# Vulnerable pause after an attack — the player's punish window.
RECOVER_MS = 0.55 * SECOND
DODGE_MS = 0.26 * SECOND
DODGE_COOLDOWN_MS = 1.1 * SECOND
# How far away a player melee swing still provokes a dodge attempt.
MELEE_DODGE_RANGE = 4.0625 * UNIT
# How far away a fireball cast still provokes a dodge attempt.
RANGED_DODGE_RANGE = 10.625 * UNIT
DODGE_CHANCE = 0.6
# Fire breath: red telegraph, then a locked-direction cone of flames.
FIRE_WINDUP_MS = 0.5 * SECOND
FIRE_BREATH_MS = 0.75 * SECOND
FIRE_RANGE = 5 * UNIT
FIRE_HALF_ARC = math.radians(35)
TOUCH_DAMAGE = 12
FIRE_DAMAGE = 9
# Head height on the 1.5-UNIT-tall body — a SCREEN height, not a world
# distance: the breath leaves its mouth, not the floor.
MOUTH_LIFT = 26 * PX


class DevilBoss(Boss):
    display_name = 'Devil Duelist'

    def __init__(self, scene, x, y):
        super().__init__(scene, x, y, DEVIL_VIEWS,
                         scale=1.5, max_health=120, xp_reward=100)
        self.ai_state = 'idle'
        self.state_timer_ms = 0.0
        self.dodge_cooldown_ms = 0.0
        self.strafe_dir = 1
        self.lunge_angle = 0.0
        self.breath_angle = 0.0
        self.flame_spawn_ms = 0.0
        self.wander_timer_ms = 0.0
        self.wander_vx = 0.0
        self.wander_vy = 0.0
        self.trident_surf = create_pixel_surface(TRIDENT_SPRITE)
        self.fireball_surf = create_pixel_surface(FIREBALL_SPRITE)

    @property
    def is_lunging(self):
        return self.ai_state == 'lunge'

    @property
    def is_dodging(self):
        return self.ai_state == 'dodge'

    @property
    def is_walking(self):
        """A lunge is thrown, not walked — it crosses three body-lengths
        in a fifth of a second, and a body waddling through that would
        read as strolling into you."""
        return not (self.is_dodging or self.is_lunging)

    @property
    def contact_damage(self):
        return TOUCH_DAMAGE if self.is_lunging else None

    def update_ai(self, player_x, player_y, dt_ms):
        self.dodge_cooldown_ms = max(0.0, self.dodge_cooldown_ms - dt_ms)
        self.state_timer_ms -= dt_ms
        self.tint = None
        self.alpha = 0.5 if self.is_dodging else 1.0  # ghosting = i-frames

        d = dist(self.x, self.y, player_x, player_y)
        to_player = angle_between(self.x, self.y, player_x, player_y)

        state = self.ai_state
        if state == 'idle':
            self._wander(dt_ms)
            if d <= AGGRO_RANGE:
                self.ai_state = 'chase'

        elif state == 'chase':
            self.set_velocity(math.cos(to_player) * CHASE_SPEED,
                              math.sin(to_player) * CHASE_SPEED)
            if d <= STRIKE_RANGE:
                roll = random.random()
                if roll < 0.45:
                    self._enter_windup()
                elif roll < 0.75:
                    self.ai_state = 'strafe'
                    self.state_timer_ms = random.randint(500, 1100)
                    self.strafe_dir = 1 if random.random() < 0.5 else -1
                else:
                    self._enter_fire_windup()
            elif d > AGGRO_RANGE * 1.4:
                self.ai_state = 'idle'

        elif state == 'strafe':
            if self.state_timer_ms <= 0:
                if d <= STRIKE_RANGE * 1.2:
                    if random.random() < 0.7:
                        self._enter_windup()
                    else:
                        self._enter_fire_windup()
                else:
                    self.ai_state = 'chase'
            else:
                # Circle the player, drifting back into a comfortable band.
                tangent = to_player + (math.pi / 2) * self.strafe_dir
                vx = math.cos(tangent) * STRAFE_SPEED
                vy = math.sin(tangent) * STRAFE_SPEED
                if d > 90:
                    vx += math.cos(to_player) * 40
                    vy += math.sin(to_player) * 40
                elif d < 50:
                    vx -= math.cos(to_player) * 40
                    vy -= math.sin(to_player) * 40
                self.set_velocity(vx, vy)

        elif state == 'windup':
            # Stand still, flash orange: trident lunge is coming.
            self.set_velocity(0, 0)
            if math.floor(self.state_timer_ms / 90) % 2 == 0:
                self.tint = 0xFFAA55
            if self.state_timer_ms <= 0:
                self.tint = None
                self.ai_state = 'lunge'
                self.state_timer_ms = LUNGE_MS
                self.lunge_angle = to_player
                self.set_velocity(math.cos(to_player) * LUNGE_SPEED,
                                  math.sin(to_player) * LUNGE_SPEED)

        elif state == 'lunge':
            # Velocity was set on entry; ride it out.
            if self.state_timer_ms <= 0:
                self.ai_state = 'recover'
                self.state_timer_ms = RECOVER_MS
                self.set_velocity(0, 0)

        elif state == 'firewindup':
            # Stand still, flash red: fire breath is coming.
            self.set_velocity(0, 0)
            if math.floor(self.state_timer_ms / 90) % 2 == 0:
                self.tint = 0xFF4444
            if self.state_timer_ms <= 0:
                self.tint = None
                self.ai_state = 'firebreath'
                self.state_timer_ms = FIRE_BREATH_MS
                # Direction locks here — stepping out of the cone dodges it.
                self.breath_angle = to_player
                self.flame_spawn_ms = 0.0

        elif state == 'firebreath':
            self.set_velocity(0, 0)
            self._spawn_flames(dt_ms)
            if self.state_timer_ms <= 0:
                self.ai_state = 'recover'
                self.state_timer_ms = RECOVER_MS

        elif state == 'recover':
            # Vulnerable pause — the player's punish window.
            self.set_velocity(0, 0)
            if self.state_timer_ms <= 0:
                self.ai_state = 'chase'

        elif state == 'dodge':
            if self.state_timer_ms <= 0:
                self.alpha = 1.0
                self.ai_state = 'chase'

        self._face(to_player)

    def _face(self, to_player):
        """Which way the body is turned — the base class animates the
        rest. A duelist squares up: it keeps its eyes on the player
        whenever it is engaged, holds whatever direction it committed an
        attack in, and only looks where it is going while wandering."""
        if self.ai_state == 'lunge':
            self.facing_angle = self.lunge_angle
        elif self.ai_state == 'firebreath':
            self.facing_angle = self.breath_angle  # locked with the cone
        elif self.ai_state == 'idle':
            if self.wander_vx or self.wander_vy:
                self.facing_angle = math.atan2(self.wander_vy, self.wander_vx)
        else:
            self.facing_angle = to_player

    def poll_area_attack(self, player_x, player_y):
        if self.ai_state != 'firebreath':
            return None
        if dist(self.x, self.y, player_x, player_y) > FIRE_RANGE + 10:
            return None
        angle_to = angle_between(self.x, self.y, player_x, player_y)
        if abs(wrap_angle(angle_to - self.breath_angle)) > FIRE_HALF_ARC + 0.1:
            return None
        return AreaHit(damage=FIRE_DAMAGE)

    def on_stun(self):
        """Parried: the lunge or the breath it was committed to is gone,
        and it comes round in `recover` — so the stagger hands the player
        the punish window twice over."""
        self.ai_state = 'recover'
        self.state_timer_ms = RECOVER_MS
        self.alpha = 1.0

    def on_player_attack(self, player_x, player_y, ranged):
        # Committed to its own attack (or already dodging) — can't react.
        if self.ai_state in ('windup', 'lunge', 'dodge', 'firewindup', 'firebreath'):
            return
        if self.dodge_cooldown_ms > 0:
            return

        d = dist(self.x, self.y, player_x, player_y)
        if d > (RANGED_DODGE_RANGE if ranged else MELEE_DODGE_RANGE):
            return
        if random.random() > DODGE_CHANCE:
            return

        to_player = angle_between(self.x, self.y, player_x, player_y)
        side = 1 if random.random() < 0.5 else -1
        tangent = to_player + (math.pi / 2) * side
        # Sidestep with a small backward component.
        vx = math.cos(tangent) * DODGE_SPEED - math.cos(to_player) * 120
        vy = math.sin(tangent) * DODGE_SPEED - math.sin(to_player) * 120

        self.ai_state = 'dodge'
        self.state_timer_ms = DODGE_MS
        self.dodge_cooldown_ms = DODGE_COOLDOWN_MS
        self.set_velocity(vx, vy)

    def draw(self, target):
        super().draw(target)
        self._draw_trident(target)

    def _draw_trident(self, target):
        """Show the trident during melee: aimed in windup, extended in the lunge."""
        if self.ai_state == 'windup':
            a = angle_between(self.x, self.y, *self.scene.player_pos())
            offset = 14
        elif self.ai_state == 'lunge':
            a = self.lunge_angle
            offset = 32
        else:
            return
        gx, gy = camera.project(self.x + math.cos(a) * offset,
                                self.y + math.sin(a) * offset)
        draw_pointing(target, self.trident_surf, gx, gy - self.display_height / 2,
                      camera.project_angle(a))

    def _spawn_flames(self, dt_ms):
        """Spray flame particles across the breath cone."""
        self.flame_spawn_ms -= dt_ms
        while self.flame_spawn_ms <= 0:
            self.flame_spawn_ms += 40
            a = self.breath_angle + FIRE_HALF_ARC * (random.random() * 2 - 1)
            reach = FIRE_RANGE * (0.6 + random.random() * 0.4)
            tint = 0xFFAA33 if random.random() < 0.5 else 0xFF7733
            surf = tint_mult(self.fireball_surf, tint)
            self.scene.add_effect(LerpParticle(
                surf,
                self.x + math.cos(a) * 20, self.y + math.sin(a) * 20,
                self.x + math.cos(a) * reach, self.y + math.sin(a) * reach,
                lift=MOUTH_LIFT,
                scale0=0.5 + random.random() * 0.4, scale1=1.4,
                duration_ms=320 + random.random() * 120,
            ))

    def _enter_windup(self):
        self.ai_state = 'windup'
        self.state_timer_ms = WINDUP_MS

    def _enter_fire_windup(self):
        self.ai_state = 'firewindup'
        self.state_timer_ms = FIRE_WINDUP_MS

    def _wander(self, dt_ms):
        self.wander_timer_ms -= dt_ms
        if self.wander_timer_ms <= 0:
            self.wander_timer_ms = random.randint(1000, 2500)
            if random.random() < 0.5:
                self.wander_vx = self.wander_vy = 0.0
            else:
                angle = random.random() * math.pi * 2
                self.wander_vx = math.cos(angle) * WANDER_SPEED
                self.wander_vy = math.sin(angle) * WANDER_SPEED
        self.set_velocity(self.wander_vx, self.wander_vy)
