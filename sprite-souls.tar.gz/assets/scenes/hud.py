"""HUD overlay: class, level, XP and health — drawn on top of the game
each frame (unaffected by camera shake, like the Phaser overlay scene)."""

import math

import pygame

from gfx.pixelart import rgb
from gfx.text import draw_text
from settings import HEIGHT, WIDTH


def draw_hud(screen: pygame.Surface, player_state) -> None:
    p = player_state
    stats = p.derived_stats
    lines = [
        f'{p.character_class.name}  —  Level {p.level}',
        f'HP {math.ceil(p.health)}/{round(stats.max_health)}   '
        f'MP {math.ceil(p.mana)}/{round(stats.max_mana)}',
        f'STR {p.attributes.strength}  DEX {p.attributes.dexterity}  '
        f'INT {p.attributes.intelligence}  VIT {p.attributes.vitality}',
        f'DMG {stats.attack_damage:.1f}   {stats.attack_speed:.2f} atk/s',
    ]
    y = 10
    for line in lines:
        rect = draw_text(screen, line, 14, 0xECF0F1, 12, y)
        y += rect.height + 2

    # XP bar along the bottom of the screen, Diablo-style.
    ratio = p.xp / p.xp_to_next_level
    bar = pygame.Surface((WIDTH, 10), pygame.SRCALPHA)
    bar.fill((0, 0, 0, 153))
    screen.blit(bar, (0, HEIGHT - 10))
    pygame.draw.rect(screen, rgb(0x8E44AD), (0, HEIGHT - 10, int(WIDTH * ratio), 10))
