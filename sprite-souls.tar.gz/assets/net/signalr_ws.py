#!/usr/bin/env python3
"""Minimal SignalR (JSON protocol) client over a hand-rolled WebSocket — stdlib only, no pip.

Flow:  HTTP POST {base}{hub}/negotiate?negotiateVersion=1  (X-Api-Key)
       -> WS upgrade GET {hub}?id={connectionToken}         (X-Api-Key header)
       -> SignalR handshake  {"protocol":"json","version":1}\\x1e
       -> messages are 0x1e-separated JSON:
            send invocation {"type":1,"target":"...","arguments":[...]}
            recv invocation {"type":1,"target":"Tick"|"MatchEnded"|..., "arguments":[...]}
            ping {"type":6}
Works over ws (http) and wss (https). The MiSTer client sends the key as the X-Api-Key header; a
browser client that can't set WS headers would pass ?access_token= instead (the hub accepts both).
"""
from __future__ import annotations

import base64
import json
import os
import socket
import ssl
import struct
import threading
from urllib import request as urlrequest
from urllib.parse import urlparse

RS = 0x1E  # ASCII record separator terminating each SignalR message


class SignalRClient:
    def __init__(self, base_url: str, hub_path: str, api_key: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.hub_path = hub_path if hub_path.startswith("/") else "/" + hub_path
        self.api_key = api_key
        self.sock = None
        self._recvbuf = b""
        self._send_lock = threading.Lock()   # serialize writes: keepalive thread vs. main thread

    def connect(self) -> None:
        token = self._negotiate()
        u = urlparse(self.base_url)
        secure = u.scheme == "https"
        host = u.hostname
        port = u.port or (443 if secure else 80)

        raw = socket.create_connection((host, port), timeout=10)
        if secure:
            raw = ssl.create_default_context().wrap_socket(raw, server_hostname=host)
        self.sock = raw

        key = base64.b64encode(os.urandom(16)).decode()
        path = f"{self.hub_path}?id={token}"
        upgrade = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            f"X-Api-Key: {self.api_key}\r\n"
            "\r\n"
        )
        raw.sendall(upgrade.encode())
        status = self._read_http_headers().split(b"\r\n", 1)[0]
        if b"101" not in status:
            raise RuntimeError("WS upgrade failed: " + status.decode(errors="replace"))

        self._send_text(json.dumps({"protocol": "json", "version": 1}) + chr(RS))

    def _negotiate(self) -> str:
        url = f"{self.base_url}{self.hub_path}/negotiate?negotiateVersion=1"
        req = urlrequest.Request(url, data=b"", method="POST",
                                 headers={"X-Api-Key": self.api_key})
        with urlrequest.urlopen(req, timeout=10) as r:
            neg = json.loads(r.read())
        token = neg.get("connectionToken") or neg.get("connectionId")
        if not token:
            raise RuntimeError("negotiate: no connection token")
        return token

    def _read_http_headers(self) -> bytes:
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = self.sock.recv(4096)
            if not chunk:
                break
            data += chunk
        return data

    # ── WebSocket framing (client frames must be masked) ──────────────────────
    def _send_text(self, text: str) -> None:
        payload = text.encode()
        header = bytearray([0x81])  # FIN + text opcode
        mask = os.urandom(4)
        n = len(payload)
        if n < 126:
            header.append(0x80 | n)
        elif n < 65536:
            header.append(0x80 | 126)
            header += struct.pack(">H", n)
        else:
            header.append(0x80 | 127)
            header += struct.pack(">Q", n)
        header += mask
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        with self._send_lock:
            self.sock.sendall(bytes(header) + masked)

    def _recv_exact(self, n: int) -> bytes:
        data = b""
        while len(data) < n:
            chunk = self.sock.recv(n - len(data))
            if not chunk:
                raise ConnectionError("socket closed")
            data += chunk
        return data

    def _recv_frame(self):
        b = self._recv_exact(2)
        opcode = b[0] & 0x0F
        masked = b[1] & 0x80
        ln = b[1] & 0x7F
        if ln == 126:
            ln = struct.unpack(">H", self._recv_exact(2))[0]
        elif ln == 127:
            ln = struct.unpack(">Q", self._recv_exact(8))[0]
        mask = self._recv_exact(4) if masked else b""
        payload = self._recv_exact(ln)
        if masked:
            payload = bytes(c ^ mask[i % 4] for i, c in enumerate(payload))
        return opcode, payload

    # ── SignalR messages ──────────────────────────────────────────────────────
    def send_invocation(self, target: str, *args) -> None:
        self._send_text(json.dumps({"type": 1, "target": target, "arguments": list(args)}) + chr(RS))

    def send_ping(self) -> None:
        """Proactive SignalR keep-alive. The server drops a client it hasn't heard from within its
        ClientTimeoutInterval, so we ping on our own schedule instead of only echoing server pings."""
        self._send_text(json.dumps({"type": 6}) + chr(RS))

    def recv_messages(self) -> list[dict]:
        """Blocking: read one WS frame and return the SignalR messages in it. Auto-answers pings."""
        opcode, payload = self._recv_frame()
        if opcode == 0x8:
            raise ConnectionError("ws closed by server")
        if opcode == 0x9:  # ping -> pong
            self.sock.sendall(bytes([0x8A, 0x80]) + os.urandom(4))
            return []
        self._recvbuf += payload
        out: list[dict] = []
        while True:
            idx = self._recvbuf.find(bytes([RS]))
            if idx < 0:
                break
            raw = self._recvbuf[:idx]
            self._recvbuf = self._recvbuf[idx + 1:]
            if not raw:
                continue
            try:
                m = json.loads(raw)
            except Exception:
                continue
            if m.get("type") == 6:  # SignalR keep-alive ping -> reply
                self._send_text(json.dumps({"type": 6}) + chr(RS))
                continue
            out.append(m)
        return out

    def close(self) -> None:
        try:
            self.sock.close()
        except Exception:
            pass
