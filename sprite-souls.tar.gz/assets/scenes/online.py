"""Online match renderer: draws the arena and every fighter from the server's
snapshots -- no local simulation, the server is authoritative. Positions are
interpolated between the last two 30Hz snapshots so motion stays smooth at 60fps.

Input is fed in from the platform launcher (the same twin-stick that drives the
offline game), forwarded to the server as an Intent via NetClient.send_input.
"""
from __future__ import annotations

import time

import pygame

from core.mathutil import lerp
from core.units import UNIT
from gfx import camera
from gfx.facing import create_views
from gfx.pixelart import rgb
from gfx.sprites import CLASS_SPRITES
from gfx.text import draw_text
from settings import HEIGHT, WIDTH, WORLD_H, WORLD_W

ARENA_DARK = 0x171B14
ARENA_GRID = 0x20261C
PLAYER_RADIUS = 0.5 * UNIT
SNAP_MS = 1000.0 / 30.0


class OnlineScene:
    def __init__(self, net):
        self.net = net
        self._sprites = {}
        self._snapped = False
        camera.snap_to(WORLD_W / 2, WORLD_H / 2)

    def _sprite(self, class_id):
        s = self._sprites.get(class_id)
        if s is None:
            s = create_views(CLASS_SPRITES[class_id])["front"]
            self._sprites[class_id] = s
        return s

    def _fighters(self):
        """[(player_dict, x, y)] with positions interpolated prev->current."""
        cur, prev, at = self.net.interpolated()
        if not cur:
            return []
        alpha = min(1.0, (time.monotonic() - at) * 1000.0 / SNAP_MS) if prev else 1.0
        prev_by_id = {p["id"]: p for p in prev["players"]} if prev else {}
        out = []
        for p in cur["players"]:
            pp = prev_by_id.get(p["id"])
            if pp:
                out.append((p, lerp(pp["x"], p["x"], alpha), lerp(pp["y"], p["y"], alpha)))
            else:
                out.append((p, p["x"], p["y"]))
        return out

    def update(self, dt_ms):
        # Frame the fight: lock on the midpoint of the fighters every frame (no
        # follow lag, so a fast-moving pair never trails off-screen). The
        # snapshot interpolation keeps the midpoint's motion smooth.
        fs = self._fighters()
        if not fs:
            return
        cx = sum(x for _, x, _ in fs) / len(fs)
        cy = sum(y for _, _, y in fs) / len(fs)
        camera.snap_to(cx, cy)

    def draw(self, screen):
        screen.fill(rgb(ARENA_DARK))
        self._draw_ground(screen)

        for p, x, y in sorted(self._fighters(), key=lambda t: t[2]):
            if not p["alive"]:
                continue
            camera.blit_shadow(screen, x, y, PLAYER_RADIUS)
            camera.blit_body(screen, self._sprite(p["cls"]), x, y)
            self._draw_healthbar(screen, p, x, y)

        self._draw_hud(screen)

    def _draw_ground(self, screen):
        """A faint world grid so motion reads against something. Cheap: a few
        lines projected to screen; the camera tilt turns the horizontals into
        the same foreshortened look the offline floor has."""
        step = 4 * UNIT
        col = rgb(ARENA_GRID)
        x = 0
        while x <= WORLD_W:
            a = camera.project(x, 0)
            b = camera.project(x, WORLD_H)
            pygame.draw.line(screen, col, a, b, 1)
            x += step
        y = 0
        while y <= WORLD_H:
            a = camera.project(0, y)
            b = camera.project(WORLD_W, y)
            pygame.draw.line(screen, col, a, b, 1)
            y += step

    def _draw_healthbar(self, screen, p, x, y):
        w = 22
        sx, sy = camera.project(x, y)
        top = int(sy - 34)
        left = int(sx - w / 2)
        pygame.draw.rect(screen, (0, 0, 0), (left, top, w, 4))
        frac = max(0.0, p["hp"] / p["mhp"]) if p["mhp"] else 0.0
        colour = 0x2ECC71 if p["id"] == self.net.you else 0xE74C3C
        if frac > 0:
            pygame.draw.rect(screen, rgb(colour), (left, top, int(w * frac), 4))

    def _draw_hud(self, screen):
        s = self.net.snapshot
        if not s:
            draw_text(screen, "CONNECTING", 16, 0xECF0F1, WIDTH / 2, HEIGHT / 2, anchor="center")
            return
        wins = "  ".join("%s %d" % (p["id"], p["wins"]) for p in s["players"])
        draw_text(screen, "ROUND %d" % s["round"], 16, 0xECF0F1, WIDTH / 2, 8, anchor="center")
        draw_text(screen, wins, 12, 0xBDC3C7, WIDTH / 2, 26, anchor="center", outline=0)
        if self.net.ended is not None:
            won = self.net.ended == self.net.you
            draw_text(screen, "YOU WIN" if won else "YOU LOSE", 16,
                      0x2ECC71 if won else 0xE74C3C, WIDTH / 2, HEIGHT / 2, anchor="center")
