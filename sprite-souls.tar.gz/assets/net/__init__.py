"""Networking for online matches: a stdlib WebSocket layer, the authoritative
game server, and the client transport. Kept dependency-free so the same code
runs on the server host, on MiSTer (raw sockets), and — with a browser-WebSocket
transport swapped in — under pygbag on the web."""
