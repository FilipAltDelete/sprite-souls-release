"""The penitent demon (the devil duelist boss) and its trident.

Horns grown out like dead branches, an exposed rib cage and
tattered wings. Its fire breath is drawn with the votive flame in
props.py.
"""

from ..facing import DirectionalSprite
from ..pixelart import PixelSprite
from .palette import BONE_DEEP, BONE_LIT, CRIMSON, GOLD, GOLD_DEEP, HOLLOW

DEVIL_PALETTE = {
    'd': 0x1A0A0C,  # outline
    # Kept brighter than the rest of the cast on purpose: the devil's
    # telegraphs are multiply tints (orange lunge / red breath) and a
    # dark base leaves them no headroom to tell apart.
    'R': 0xA32A22,  # flesh crimson
    'r': 0x5E1216,  # deep crimson / tail
    'L': 0xD06046,  # flesh rim light
    'K': HOLLOW,    # sockets and maw
    'Y': 0xE8A02A,  # ember eyes
    'H': 0xD8C6A0,  # horn bone
    'h': 0x9A886A,  # horn shade
    'B': BONE_LIT,  # ribs and teeth
    'b': BONE_DEEP, # rib shade
    'W': 0x3A1620,  # wing membrane
    'w': 0x5A2430,  # wing edge
}

# Front: horns grown out like dead branches, a gaunt crimson face with
# ember eyes and a bone-toothed maw, an exposed rib cage, tattered
# maroon wings and a spaded tail.
DEVIL_SPRITE = PixelSprite(
    palette=DEVIL_PALETTE,
    rows=(
        '...HH......................HH...',
        '...Hh......................hH...',
        '...HH.HH................HH.HH...',
        '....Hh.Hh..............hH.hH....',
        '....HH..HH............HH..HH....',
        '.....HHhHH............HHhHH.....',
        '......HHHh............hHHH......',
        '.......HHd............dHH.......',
        '.........dLRRRRRRRrrrd..........',
        '.......dLLRRRRRRRRRRrrrrd.......',
        '......dLLRKYYKRRRRKYYKrrrd......',
        '......dLLRKYYKRRRRKYYKrrrd......',
        '......dLLRRRRRRRRRRRRRrrrd......',
        '.......dLLRKBKBKBKBKBrrrd.......',
        '........dLRKKKKKKKKKKrrd........',
        '..........dLRRRRRRrrrd..........',
        '...........dLRRRRrrrd...........',
        '......Ww.dLRRRRRRRrrrrd.wW......',
        '.....WWw.dLBBBBRRBBbbrd.wWW.....',
        '....WWWw.dLRRRRRRRrrrrd.wWWW....',
        '...WWWWw.dLbBBBRRBBbbrd.wWWWW...',
        '..WWWWWw.dLRRRRRRRrrrrd.wWWWWW..',
        '..WWWWw..dLbBBBRRBBbbrd..wWWWW..',
        '...WWw...dLRRRRRRRrrrrd...wWW...',
        '....W....dLRRRRRRRrrrrd....W....',
        '.........dLRRRRRRRrrrrd.........',
        '.........dRRrd....dRRrd..rr.....',
        '.........dRRd......dRRd...rr....',
        '.........dRRd......dRRd....rr...',
        '........dHhRd......dRhHd....rr..',
        '........dHHhd......dhHHd...rrr..',
        '..........................rr....',
    ),
)

# Back: the ribs become the spine they hang off — beaded vertebrae in
# their own shadow, running up into a ridge over the back of the skull.
# The wing struts move to the outer edge (you are seeing the far face of
# the membrane) and the tail falls between the hooves.
DEVIL_BACK_SPRITE = PixelSprite(
    palette=DEVIL_PALETTE,
    rows=(
        '...HH......................HH...',
        '...Hh......................hH...',
        '...HH.HH................HH.HH...',
        '....Hh.Hh..............hH.hH....',
        '....HH..HH............HH..HH....',
        '.....HHhHH............HHhHH.....',
        '......HHHh............hHHH......',
        '.......HHd............dHH.......',
        '.........dLRRRRRRRrrrd..........',
        '.......dLLRRRRRRRRRRrrrrd.......',
        '......dLLRRRRRRRRRRRRRrrrd......',
        '......dLLRRRRRRRRRRRRRrrrd......',
        '......dLLRRRRRRRBBRRRRrrrd......',
        '.......dLLRRRRRRBBRRRrrrd.......',
        '........dLRRRRRBBRRRRrrd........',
        '..........dLRRRRBBrrrd..........',
        '...........dLRRBBrrrd...........',
        '......wW.dLRRRRKBBKrrrd.Ww......',
        '.....wWW.dLRRRRRKKrrrrd.WWw.....',
        '....wWWW.dLRRRRKBBKrrrd.WWWw....',
        '...wWWWW.dLRRRRRKKrrrrd.WWWWw...',
        '..wWWWWW.dLRRRRKBBKrrrd.WWWWWw..',
        '..wWWWW..dLRRRRRKKrrrrd..WWWWw..',
        '...wWW...dLRRRRKBBKrrrd...WWw...',
        '....W....dLRRRRRKKrrrrd....W....',
        '.........dLRRRRKBBKrrrd.........',
        '.........dRRrd.rr.dRRrd.........',
        '.........dRRd..rr..dRRd.........',
        '.........dRRd..rr..dRRd.........',
        '........dHhRd..rr..dRhHd........',
        '........dHHhd.rrrr.dhHHd........',
        '..............rr................',
    ),
)

# Side: the horns rake back off a snouted profile, one wing spread
# behind, the ribs read along the flank, and the tail hooks down and
# away. Body mass sits on the same column as the other two views so the
# devil turns on the spot instead of sliding.
DEVIL_SIDE_SPRITE = PixelSprite(
    palette=DEVIL_PALETTE,
    rows=(
        '........HH......................',
        '........Hh......................',
        '........HH.HH...................',
        '.........Hh.Hh..................',
        '.........HH..HH.................',
        '..........HHhHH.................',
        '...........HHHh.................',
        '............HHd.................',
        '...........dLRRRRRRRrd..........',
        '..........dLRRRRRRRRRRrd........',
        '..........dLRKYYKRRRRRRrd.......',
        '..........dLRKYYKRRRRRRRd.......',
        '..........dLRRRRRRRRRRRRd.......',
        '..........dLRRKBKBKBKBKBd.......',
        '...........dLRKKKKKKKKKd........',
        '............dLRRRRRRrrd.........',
        '.............dLRRRRrrd..........',
        '.......Ww..dLRRRRRRrrd..........',
        '......WWw..dLBBBRRbbrd..........',
        '.....WWWw..dLRRRRRRrrd..........',
        '....WWWWw..dLbBBRRbbrd..........',
        '...WWWWWw..dLRRRRRRrrd..........',
        '....WWWWw..dLbBBRRbbrd..........',
        '......WWw..dLRRRRRRrrd..........',
        '........W..dLRRRRRRrrd..........',
        '.......rrrrdLRRRRRRrrd..........',
        '.....rr....dRRrd.dRRrd..........',
        '....rr.....dRRd...dRRd..........',
        '....rr.....dRRd...dRRd..........',
        '.....rr...dHhRd..dRhHd..........',
        '......rr..dHHhd..dhHHd..........',
        '.......rr.......................',
    ),
)

# Three-quarters toward the camera: trailing eye socket down to one
# ember pixel, torso narrowed, and the wings gone asymmetric — the far
# one spread, the near one foreshortened against the body. Wing struts
# stay on the inner edge, as on the front view.
DEVIL_FRONT_SIDE_SPRITE = PixelSprite(
    palette=DEVIL_PALETTE,
    rows=(
        '....HH.....................HH...',
        '....Hh.....................hH...',
        '....HH.HH...............HH.HH...',
        '.....Hh.Hh.............hH.hH....',
        '.....HH..HH...........HH..HH....',
        '......HHhHH...........HHhHH.....',
        '.......HHHh...........hHHH......',
        '........HHd...........dHH.......',
        '..........dLRRRRRRRrrd..........',
        '........dLLRRRRRRRRRrrrd........',
        '.......dLLRKYKRRRKYYKrrrd.......',
        '.......dLLRKYKRRRKYYKrrrd.......',
        '.......dLLRRRRRRRRRRRrrrd.......',
        '........dLLRKBKBKBKBrrrd........',
        '.........dLRKKKKKKKKrrd.........',
        '..........dLRRRRRRrrd...........',
        '...........dLRRRRrrd............',
        '.....WWw.dLRRRRRRrrrd.wW........',
        '....WWWw.dLBBBRRBbbrd.wW........',
        '...WWWWw.dLRRRRRRrrrd.wWW.......',
        '..WWWWWw.dLbBBRRBbbrd.wWW.......',
        '.WWWWWWw.dLRRRRRRrrrd.wWWW......',
        '.WWWWWw..dLbBBRRBbbrd..wWW......',
        '..WWWw...dLRRRRRRrrrd...wW......',
        '...W.....dLRRRRRRrrrd....W......',
        '.........dLRRRRRRrrrd...........',
        '.........dRRrd...dRRrd...rr.....',
        '.........dRRd.....dRRd....rr....',
        '.........dRRd.....dRRd.....rr...',
        '........dHhRd.....dRhHd.....rr..',
        '........dHHhd.....dhHHd....rrr..',
        '...........................rr...',
    ),
)

# Three-quarters away: the spine sits left of centre where a body turned
# away-and-right puts it, the wing struts move to the outer edge (you are
# seeing the far face of the membrane, as on the back view), and the tail
# falls between the hooves.
DEVIL_BACK_SIDE_SPRITE = PixelSprite(
    palette=DEVIL_PALETTE,
    rows=(
        '....HH.....................HH...',
        '....Hh.....................hH...',
        '....HH.HH...............HH.HH...',
        '.....Hh.Hh.............hH.hH....',
        '.....HH..HH...........HH..HH....',
        '......HHhHH...........HHhHH.....',
        '.......HHHh...........hHHH......',
        '........HHd...........dHH.......',
        '..........dLRRRRRRRrrd..........',
        '........dLLRRRRRRRRRrrrd........',
        '.......dLLRRRRRRRRRRRrrrd.......',
        '.......dLLRRRRRRRRRRRrrrd.......',
        '.......dLLRRRRBBRRRRRrrrd.......',
        '........dLLRRRBBRRRRrrrd........',
        '.........dLRRBBRRRRRrrd.........',
        '..........dLRBBRRRrrd...........',
        '...........dLRBBRrrd............',
        '.....wWW.dLRKBBKrrrrd.Ww........',
        '....wWWW.dLRRKKrrrrrd.Ww........',
        '...wWWWW.dLRKBBKrrrrd.WWw.......',
        '..wWWWWW.dLRRKKrrrrrd.WWw.......',
        '.wWWWWWW.dLRKBBKrrrrd.WWWw......',
        '.wWWWWW..dLRRKKrrrrrd..WWw......',
        '..wWWW...dLRKBBKrrrrd...Ww......',
        '...W.....dLRRKKrrrrrd....W......',
        '.........dLRKBBKrrrrd...........',
        '.........dRRrd.rr.dRRrd.........',
        '.........dRRd..rr..dRRd.........',
        '.........dRRd..rr..dRRd.........',
        '........dHhRd..rr..dRhHd........',
        '........dHHhd.rrrr.dhHHd........',
        '..............rr................',
    ),
)

DEVIL_VIEWS = DirectionalSprite(front=DEVIL_SPRITE, back=DEVIL_BACK_SPRITE,
                                side=DEVIL_SIDE_SPRITE,
                                front_side=DEVIL_FRONT_SIDE_SPRITE,
                                back_side=DEVIL_BACK_SIDE_SPRITE)

# 32x32 ceremonial fork pointing straight up: three rusted-iron prongs
# still wet at the tips, on a black wooden haft with brass bands. The
# devil's melee weapon.
TRIDENT_SPRITE = PixelSprite(
    palette={
        'X': 0xE8DEC2,   # prong tip
        'R': CRIMSON,    # blood on the prongs
        'S': 0x8E8574,   # rusted iron
        's': 0x4A443A,   # iron shade
        'B': 0x2A1F16,   # black wooden haft
        'b': 0x160F0A,   # haft shade
        'G': GOLD,       # brass band
        'g': GOLD_DEEP,  # brass shade
    },
    rows=(
        '..............XS................',
        '..............RS................',
        '........XS....RS....XS..........',
        '........RS....SS....RS..........',
        '........Rs....Ss....Rs..........',
        '........Ss....Ss....Ss..........',
        '........Ss....Ss....Ss..........',
        '........Ss....Ss....Ss..........',
        '........SSSSSSSSSSSSSS..........',
        '........ssssssSSssssss..........',
        '..............Bb................',
        '..............Bb................',
        '..............Gg................',
        '..............Gg................',
        '..............Bb................',
        '..............Bb................',
        '..............Bb................',
        '..............Bb................',
        '..............Bb................',
        '..............Bb................',
        '..............Gg................',
        '..............Gg................',
        '..............Bb................',
        '..............Bb................',
        '..............Bb................',
        '..............Bb................',
        '..............Bb................',
        '..............bb................',
        '................................',
        '................................',
        '................................',
        '................................',
    ),
)
