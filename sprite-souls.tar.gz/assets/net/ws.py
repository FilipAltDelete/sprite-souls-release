"""A minimal RFC 6455 WebSocket layer over asyncio streams — just the text +
control frames a game needs, no dependencies. Server frames go out unmasked,
client frames masked, per spec. Used by both net/server.py and the native
client transport; the browser (pygbag) uses the JS WebSocket instead."""
from __future__ import annotations

import base64
import hashlib
import os
import struct

_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

OP_TEXT = 0x1
OP_CLOSE = 0x8
OP_PING = 0x9
OP_PONG = 0xA


def _accept(key: str) -> str:
    return base64.b64encode(hashlib.sha1((key + _GUID).encode()).digest()).decode()


async def server_handshake(reader, writer) -> None:
    """Complete the upgrade for an incoming client connection."""
    req = b""
    while b"\r\n\r\n" not in req:
        chunk = await reader.read(1024)
        if not chunk:
            raise ConnectionError("closed during handshake")
        req += chunk
    key = ""
    for line in req.decode("latin1").split("\r\n"):
        if line.lower().startswith("sec-websocket-key:"):
            key = line.split(":", 1)[1].strip()
    writer.write((
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {_accept(key)}\r\n\r\n"
    ).encode())
    await writer.drain()


async def client_handshake(reader, writer, host: str, path: str = "/") -> None:
    """Open the upgrade from the client side."""
    key = base64.b64encode(os.urandom(16)).decode()
    writer.write((
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Key: {key}\r\n"
        "Sec-WebSocket-Version: 13\r\n\r\n"
    ).encode())
    await writer.drain()
    resp = b""
    while b"\r\n\r\n" not in resp:
        chunk = await reader.read(1024)
        if not chunk:
            raise ConnectionError("closed during handshake")
        resp += chunk
    if b" 101 " not in resp.split(b"\r\n", 1)[0]:
        raise ConnectionError("handshake refused: " + resp.split(b"\r\n", 1)[0].decode("latin1"))


def encode(payload, *, mask: bool, opcode: int = OP_TEXT) -> bytes:
    data = payload.encode() if isinstance(payload, str) else payload
    frame = bytearray([0x80 | opcode])
    n = len(data)
    mbit = 0x80 if mask else 0
    if n < 126:
        frame.append(mbit | n)
    elif n < 65536:
        frame.append(mbit | 126)
        frame += struct.pack(">H", n)
    else:
        frame.append(mbit | 127)
        frame += struct.pack(">Q", n)
    if mask:
        m = os.urandom(4)
        frame += m
        frame += bytes(b ^ m[i % 4] for i, b in enumerate(data))
    else:
        frame += data
    return bytes(frame)


async def read_frame(reader):
    """Return (opcode, payload_bytes). Raises on a clean/abrupt close."""
    hdr = await reader.readexactly(2)
    opcode = hdr[0] & 0x0F
    masked = hdr[1] & 0x80
    ln = hdr[1] & 0x7F
    if ln == 126:
        ln = struct.unpack(">H", await reader.readexactly(2))[0]
    elif ln == 127:
        ln = struct.unpack(">Q", await reader.readexactly(8))[0]
    mask = await reader.readexactly(4) if masked else b"\x00\x00\x00\x00"
    data = bytearray(await reader.readexactly(ln))
    if masked:
        for i in range(ln):
            data[i] ^= mask[i % 4]
    return opcode, bytes(data)
