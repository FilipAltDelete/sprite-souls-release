"""The ossuary wyrm (the ice dragon boss), its tail, claw and shards.

Branching ivory antlers, a tarnished brass browband and hollow
sockets with cold light behind them — the ice dragon built out of
reliquary bone. The cold hue is gameplay language, so it stays.
"""

from ..facing import DirectionalSprite
from ..pixelart import PixelSprite
from .palette import VOID_COLD

# 32x32 ossuary wyrm, front view: branching ivory antlers, a tarnished
# brass browband, hollow sockets with cold light behind them, dark
# verdigris wing membranes on pale wing-bone, and an exposed rib cage
# down the belly. Still reads as the ice dragon — the cold hue is
# gameplay language — but built out of reliquary bone.
ICE_DRAGON_PALETTE = {
    'd': VOID_COLD,  # outline
    'B': 0xB9C9CE,   # bone plate
    'b': 0x8497A0,   # bone shade
    'c': 0x455A63,   # crevice / nostril
    'L': 0xEDF4F2,   # bone specular
    'W': 0x2B4F58,   # wing membrane (verdigris)
    'w': 0x9FB8BC,   # wing-bone strut
    'V': 0xE2E7D8,   # rib
    'v': 0x1A2429,   # the gap between ribs — near-black, or it reads
                     # as a striped barrel instead of a rib cage
    'E': 0x9BE9F5,   # cold light in the sockets
    'H': 0xE8DFC4,   # antler ivory
    'h': 0xA6997A,   # antler shade
    'G': 0xA88A2E,   # tarnished brass browband
}

ICE_DRAGON_SPRITE = PixelSprite(
    palette=ICE_DRAGON_PALETTE,
    rows=(
        '..W........hH......Hh........W..',
        '.WW........dHHd..dHHd........WW.',
        '.WWw.......dHHd..dHHd.......wWW.',
        '.WWWw......dHHdBBdHHd......wWWW.',
        '.WWWWw....dBBBBBBBBBBd....wWWWW.',
        '.WWWWw....dGGGGGGGGGGd....wWWWW.',
        '.WWWWwWWdBcEEcBBBBcEEcBdWWwWWWW.',
        '.WWWWwWWdBcEEcBBBBcEEcBdWWwWWWW.',
        '.WWWwwWWdBBBBBBBBBBBBBBdWWwwWWW.',
        '.WWwwWWWWdBBBBBLLBBBBBdWWWWwwWW.',
        '.WwwWWWWWWdBBcBBBBcBBdWWWWWWwwW.',
        '..WwWWWWWWdBBBBBBBBBBdWWWWWWwW..',
        '..WwWWWWdBBBVVVvvVVVBBBdWWWWwW..',
        '...wWWWWdBBvvvvvvvvvvBBdWWWWw...',
        '.......dBBBVVVVvvVVVVBBBd.......',
        '.......dBbBvvvvvvvvvvBBBd.......',
        '......dBBBBVVVVvvVVVVBBBBd......',
        '......dBbBBvvvvvvvvvvBBbBd......',
        '......dBBBBVVVVvvVVVVBBBBd......',
        '......dBBbBvvvvvvvvvvBbBBd......',
        '.......dBBBVVVVvvVVVVBBBd.......',
        '.......dBbBvvvvvvvvvvBbBd.......',
        '........dBBVVVVvvVVVVBBd........',
        '........dBBBvvvvvvvvBBBd........',
        '........dBBbd......dbBBd........',
        '........dBBbd......dbBBd........',
        '.......dBBBd........dBBBd.......',
        '......dHhBBd........dBBhHd......',
        '.............bBVBb..............',
        '..............bVb...............',
        '................................',
        '................................',
    ),
)

# Back: no sockets, no browband — the rib cage is replaced by the spine
# it hangs off, a beaded ivory ridge running from the nape to the tail,
# and the tail now points at the camera so it hangs below the feet. This
# is the view the player is *meant* to be looking at: the wyrm turns too
# slowly to keep its face on them, and its back is where it is safe.
ICE_DRAGON_BACK_SPRITE = PixelSprite(
    palette=ICE_DRAGON_PALETTE,
    rows=(
        '..W........hH......Hh........W..',
        '.WW........dHHd..dHHd........WW.',
        '.WWw.......dHHd..dHHd.......wWW.',
        '.WWWw......dHHdBBdHHd......wWWW.',
        '.WWWWw....dBBBBBBBBBBd....wWWWW.',
        '.WWWWw....dGGGGGGGGGGd....wWWWW.',
        '.WWWWwWWdBBBBBBBBBBBBBBdWWwWWWW.',
        '.WWWWwWWdBBBBBBLLBBBBBBdWWwWWWW.',
        '.WWWwwWWdBBBBBBBBBBBBBBdWWwwWWW.',
        '.WWwwWWWWdBBBBBccBBBBBdWWWWwwWW.',
        '.WwwWWWWWWdBBBBccBBBBdWWWWWWwwW.',
        '..WwWWWWWWdBBBBBBBBBBdWWWWWWwW..',
        '..WwWWWWdBBBBBcVVcBBBBBdWWWWwW..',
        '...wWWWWdBbBBBcVVcBBBbBdWWWWw...',
        '.......dBBBBBBcVVcBBBBBBd.......',
        '.......dBbBBBBcVVcBBBBbBd.......',
        '......dBBBBBBBcVVcBBBBBBBd......',
        '......dBbBBBBBcVVcBBBBBbBd......',
        '......dBBBBBBBcVVcBBBBBBBd......',
        '......dBBbBBBBcVVcBBBBbBBd......',
        '.......dBBBBBBcVVcBBBBBBd.......',
        '.......dBbBBBBcVVcBBBBbBd.......',
        '........dBBBBBcVVcBBBBBd........',
        '........dBBBBBcVVcBBBBBd........',
        '........dBBbd......dbBBd........',
        '........dBBbd......dbBBd........',
        '.......dBBBd........dBBBd.......',
        '......dHhBBd........dBBhHd......',
        '............bBBVBBb.............',
        '............bBBVBBb.............',
        '.............bBVBb..............',
        '..............bVb...............',
    ),
)

# Side: the only view where the wyrm is a serpent rather than a heraldic
# crest — antlers over a long skull, the neck sweeping down into a
# ribbed barrel, the near wing half-raised behind it, and the tail
# trailing off the hindquarters. Feet stay on row 27, the same row the
# front view stands on, or the body would hop when it turns.
ICE_DRAGON_SIDE_SPRITE = PixelSprite(
    palette=ICE_DRAGON_PALETTE,
    rows=(
        '.................hH....Hh.......',
        '................dHHd..dHHd......',
        '................dHHd..dHHd......',
        '................dHHdBBdHHd......',
        '................dBBBBBBBBd......',
        '................dGGGGGGGGGGd....',
        '..W.............dBcEEcBBBBBBd...',
        '..WWw...........dBcEEcBBBBBBBd..',
        '.WWWWw..........dBBBBBBBBBcBBd..',
        '.WWWWWw.........dBBBBBBBBBBBd...',
        '.WWWWWWw........dBBBBBBBBBd.....',
        '.WWWWWWWw.......dBBBBBBd........',
        '.WWWWWWWWw......dBBBBd..........',
        '.WWWWWWWWWw....dBBBBd...........',
        '.WWWWWWWWWWw..dBBBBd............',
        '..WWWWWWWWWwdBBBBBBBBd..........',
        '...WWWWWWWwdBBBVVvVVBBBBd.......',
        '....WWWWWwdBBBvvvvvvBBBBBd......',
        '.....WWWwdBBBVVvVVvVVBBBBd......',
        '......WwdBBBBvvvvvvvvBBBBBd.....',
        '.....wdBBBBVVvVVvVVVBBBBBd......',
        '..bbBdBBBBvvvvvvvvvvBBBBBd......',
        'bBBBBdBBBVVvVVvVVVVBBBBBd.......',
        '.....dBBBBvvvvvvvvvBBBBBd.......',
        '.....dBBBBBBBBBBBBBBBBBd........',
        '.....dBBbd.....dbBBd............',
        '.....dBBBd.....dBBBd............',
        '....dHhBBd....dBBhHd............',
        '................................',
        '................................',
        '................................',
        '................................',
    ),
)

# Three-quarters toward the camera. The wyrm's front and side views are
# different *poses* — heraldic wings-spread versus serpent profile — so
# unlike the humanoids this one cannot just be the front narrowed: the
# far wing spreads, the near wing foreshortens against the body, the
# trailing socket loses a pixel of cold light, and the whole rib barrel
# shifts and narrows as it turns off-axis.
ICE_DRAGON_FRONT_SIDE_SPRITE = PixelSprite(
    palette=ICE_DRAGON_PALETTE,
    rows=(
        '.W..........hH......Hh.....W....',
        'WW..........dHHd..dHHd....WW....',
        'WWw.........dHHd..dHHd...wWW....',
        'WWWw........dHHdBBdHHd..wWWW....',
        'WWWWw.......dBBBBBBBBBBdwWWW....',
        'WWWWw.......dGGGGGGGGGGdwWWW....',
        'WWWWwWWWWWdBcEcBBBBcEEcBdwWWW...',
        'WWWWwWWWWWdBcEcBBBBcEEcBdwWWW...',
        'WWWwwWWWWWdBBBBBBBBBBBBcBdwWWW..',
        'WWwwWWWWWWWdBBBBBLLBBBBBdwWWW...',
        'WwwWWWWWWWWWdBBcBBBBcBBdwWWWW...',
        'WwWWWWWWWWWWdBBBBBBBBBBdwWWW....',
        'WwWWWWWWWWdBBBVVvvVVVBBBdwWW....',
        '.wWWWWWWWWdBBvvvvvvvvvBBdwW.....',
        '.........dBBBVVVvvVVVBBBd.......',
        '.........dBbBvvvvvvvvBBBd.......',
        '........dBBBVVVVvvVVVVBBBd......',
        '........dBbBBvvvvvvvvBBbBd......',
        '........dBBBVVVVvvVVVVBBBd......',
        '........dBBbBvvvvvvvvBbBBd......',
        '.........dBBBVVVvvVVVBBBd.......',
        '.........dBbBvvvvvvvvBBBd.......',
        '..........dBBVVVvvVVVBBd........',
        '..........dBBvvvvvvvvBBd........',
        '.........dBBbd.....dbBBd........',
        '.........dBBbd.....dbBBd........',
        '........dBBBd.......dBBBd.......',
        '.......dHhBBd.......dBBhHd......',
        '...........bBVBb................',
        '............bVb.................',
        '................................',
        '................................',
    ),
)

# Three-quarters away: sockets gone, the beaded spine ridge sitting left
# of centre where a body turned away-and-right puts it, and the tail
# swung round toward the camera so it hangs below the feet.
ICE_DRAGON_BACK_SIDE_SPRITE = PixelSprite(
    palette=ICE_DRAGON_PALETTE,
    rows=(
        '.W..........hH......Hh.....W....',
        'WW..........dHHd..dHHd....WW....',
        'WWw.........dHHd..dHHd...wWW....',
        'WWWw........dHHdBBdHHd..wWWW....',
        'WWWWw.......dBBBBBBBBBBdwWWW....',
        'WWWWw.......dGGGGGGGGGGdwWWW....',
        'WWWWwWWWWWdBBBBBBBBBBBBBdwWWW...',
        'WWWWwWWWWWdBBBBBBLLBBBBBdwWWW...',
        'WWWwwWWWWWdBBBBBBBBBBBBBBdwWWW..',
        'WWwwWWWWWWWdBBBBBccBBBBBdwWWW...',
        'WwwWWWWWWWWWdBBBBccBBBBdwWWWW...',
        'WwWWWWWWWWWWdBBBBBBBBBBdwWWW....',
        'WwWWWWWWWWdBBBcVVcBBBBBBdwWW....',
        '.wWWWWWWWWdBbBcVVcBBBBBBdwW.....',
        '.........dBBBcVVcBBBBBBBd.......',
        '.........dBbBcVVcBBBBBBBd.......',
        '........dBBBBcVVcBBBBBBBBd......',
        '........dBbBBcVVcBBBBBBbBd......',
        '........dBBBBcVVcBBBBBBBBd......',
        '........dBBbBcVVcBBBBBBbBd......',
        '.........dBBBcVVcBBBBBBBd.......',
        '.........dBbBcVVcBBBBBBBd.......',
        '..........dBBcVVcBBBBBBd........',
        '..........dBBcVVcBBBBBBd........',
        '.........dBBbd.....dbBBd........',
        '.........dBBbd.....dbBBd........',
        '........dBBBd.......dBBBd.......',
        '.......dHhBBd.......dBBhHd......',
        '...........bBBVBBb..............',
        '...........bBBVBBb..............',
        '............bBVBb...............',
        '.............bVb................',
    ),
)

ICE_DRAGON_VIEWS = DirectionalSprite(front=ICE_DRAGON_SPRITE,
                                     back=ICE_DRAGON_BACK_SPRITE,
                                     side=ICE_DRAGON_SIDE_SPRITE,
                                     front_side=ICE_DRAGON_FRONT_SIDE_SPRITE,
                                     back_side=ICE_DRAGON_BACK_SIDE_SPRITE)

# 32x32 wyrm tail pointing straight up: bone plates tapering to an
# ivory spine, with smaller spurs down the sides. Swept across the arc
# behind the dragon.
DRAGON_TAIL_SPRITE = PixelSprite(
    palette={
        'd': VOID_COLD,  # outline
        'S': 0xEDE2C4,   # ivory spurs
        'B': 0xB9C9CE,   # bone plate
        'b': 0x8497A0,   # plate shade
        'c': 0x2E4048,   # the seam where one plate overlaps the next
        'L': 0xEDF4F2,   # plate specular
    },
    rows=(
        '...............S................',
        '..............dSSd..............',
        '..............dSSd..............',
        '.............dLBBd..............',
        '.............dLBBbd.............',
        '.............dccccd.............',
        '............dLBBBBbd............',
        '............dLBBBBbd............',
        '..........SSdLBBBBbd............',
        '...........dLBBBBBbd............',
        '...........dLBBBBBbdSS..........',
        '...........dccccccccd...........',
        '..........dLBBBBBBBBbd..........',
        '..........dLBBBBBBBBbd..........',
        '........SSdLBBBBBBBBbd..........',
        '.........dLBBBBBBBBBBbd.........',
        '.........dLBBBBBBBBBBbdSS.......',
        '.........dccccccccccccd.........',
        '........dLBBBBBBBBBBBBbd........',
        '........dLBBBBBBBBBBBBbd........',
        '......SSdLBBBBBBBBBBBBbd........',
        '.......dLBBBBBBBBBBBBBBbd.......',
        '.......dLBBBBBBBBBBBBBBbdSS.....',
        '.......dccccccccccccccccd.......',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
    ),
)

# 32x32 wyrm claw pointing straight up: three ivory talons, fanned,
# tapering to hooked tips. Swept across the arc in front of the dragon.
DRAGON_CLAW_SPRITE = PixelSprite(
    palette={
        'S': 0xEDE2C4,  # talon ivory
        's': 0x8E846A,  # talon shade
    },
    rows=(
        '................................',
        '................................',
        '.........S.......S.......S......',
        '.........S.......S.......S......',
        '........SS......SS......SS......',
        '........SS......SS......SS......',
        '.......sSS.....sSS.....sSS......',
        '.......sSS.....sSS.....sSS......',
        '.......sSSs....sSSs....sSSs.....',
        '.......sSSs....sSSs....sSSs.....',
        '......ssSSs...ssSSs...ssSSs.....',
        '......ssSSs...ssSSs...ssSSs.....',
        '......ssss....ssss....ssss......',
        '......ssss....ssss....ssss......',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
    ),
)

# 16x16 bone splinter: an ivory shard with a cold pale rim and a
# fracture line across the lower half.
ICE_SHARD_SPRITE = PixelSprite(
    palette={
        'i': 0x6B8189,  # cold rim
        'W': 0xE2E7D8,  # ivory core
        'v': 0x8E9A94,  # the fracture face turned away from the light
    },
    rows=(
        '.......W........',
        '......iWi.......',
        '.....iWWWi......',
        '....iWWWWWi.....',
        '...iWWWWvvvvi...',
        '..iWWWWWvvvvvi..',
        '..iWWWWvvvvvvi..',
        '..iWWWvvvvvvvi..',
        '...iWWvvvvvvi...',
        '....iWvvvvvi....',
        '.....ivvvvi.....',
        '......ivvi......',
        '.......ii.......',
        '................',
        '................',
        '................',
    ),
)
