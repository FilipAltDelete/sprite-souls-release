"""Small angle/vector helpers (equivalents of Phaser.Math.Angle.*).
No pygame imports."""

import math


def wrap_angle(a: float) -> float:
    """Wrap an angle to [-pi, pi]."""
    return (a + math.pi) % (2 * math.pi) - math.pi


def rotate_to(current: float, target: float, max_step: float) -> float:
    """Rotate `current` toward `target` by at most `max_step` radians,
    taking the shortest path."""
    diff = wrap_angle(target - current)
    if abs(diff) <= max_step:
        return wrap_angle(target)
    return wrap_angle(current + math.copysign(max_step, diff))


def dist(x1: float, y1: float, x2: float, y2: float) -> float:
    return math.hypot(x2 - x1, y2 - y1)


def angle_between(x1: float, y1: float, x2: float, y2: float) -> float:
    return math.atan2(y2 - y1, x2 - x1)


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t
