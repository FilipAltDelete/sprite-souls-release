"""Authoritative arena sim for online matches -- pure logic, no pygame, so the
same code runs headless on the server, natively on MiSTer/PC, and in the browser
(pygbag). Deliberately generic in the number of fighters: 1v1 is just two, and a
10-player free-for-all is the same code with a bigger roster.

Deterministic given a seed (obstacle scatter + spawn), so a server and its
clients agree on the map. No boss and no levelling in these modes -- a match is
best-of-N rounds of straight combat; character speccing is layered on later
through PlayerState/attributes, which this already routes every number through.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .classes import CLASSES
from .mathutil import angle_between, dist, wrap_angle
from .obstacles import scatter
from .player_state import PlayerState
from .units import UNIT

from settings import WORLD_W, WORLD_H

SNAPSHOT_VERSION = 1

PLAYER_RADIUS = 0.5 * UNIT
ATTACK_RANGE = 1.4 * UNIT          # melee reach measured from the attacker's centre
ATTACK_HALF_ARC = 1.0              # radians either side of facing that a swing covers
SWING_MS = 180                     # how long a swing reads as "attacking" in snapshots
ROUND_RESET_MS = 2500              # pause between rounds
SPAWN_INSET = 0.22                 # fighters start this far in from the arena edges

DODGE_MS = 200                     # dash duration -- also the i-frame window
DODGE_COOLDOWN_MS = 650
DODGE_SPEED_MULT = 2.6             # dash is this much faster than a walk
GUARD_MOVE_MULT = 0.45             # you shuffle behind a raised guard
GUARD_HALF_ARC = 1.2              # a raised guard blocks hits from within this arc of facing


@dataclass
class Intent:
    """One fighter's inputs for a tick. Extend here (spells, etc.) as the kit
    grows -- the sim, snapshot and net protocol all read from this one place."""
    move: Tuple[float, float] = (0.0, 0.0)   # desired direction, each axis -1..1
    aim: Optional[float] = None              # facing angle (radians); None = aim with movement
    attack: bool = False
    dodge: bool = False                      # dash + brief invulnerability
    guard: bool = False                      # hold to block frontal hits


@dataclass
class Fighter:
    pid: str
    class_id: str
    x: float
    y: float
    facing: float
    state: PlayerState
    intent: Intent = field(default_factory=Intent)
    last_attack_ms: float = -1e9
    swing_until_ms: float = 0.0
    dodge_until_ms: float = 0.0          # dashing + invulnerable while now < this
    dodge_cd_until_ms: float = 0.0
    dodge_dir: float = 0.0
    guarding: bool = False
    alive: bool = True
    wins: int = 0


@dataclass
class MatchConfig:
    players: Dict[str, str]            # pid -> class_id
    best_of: int = 5
    density: float = 0.15              # arena forest density (light for the 1v1 map)
    seed: int = 0
    # Authoritative per-player spec, keyed by pid, supplied by the server (from
    # the API's CharacterState) -- NEVER by the client. Each is a dict like
    # {"str":.., "dex":.., "int":.., "vit":.., "level":..}. Omitted -> the class
    # base. This is the anti-cheat boundary: clients send input only, never
    # stats, and all damage/speed derive from these server-held attributes.
    specs: Dict[str, dict] = field(default_factory=dict)


class Match:
    def __init__(self, config: MatchConfig):
        self.cfg = config
        self.time_ms = 0.0
        # Seed first so the scatter and the spawn spread are reproducible: one
        # match per process, so seeding the global RNG is enough (same call the
        # offline game makes).
        random.seed(config.seed)
        self.obstacles = scatter(WORLD_W, WORLD_H, density=config.density)

        self.fighters: Dict[str, Fighter] = {}
        for pid, spawn in self._spawn_points(list(config.players)):
            class_id = config.players[pid]
            x, y = spawn
            self.fighters[pid] = Fighter(
                pid=pid, class_id=class_id, x=x, y=y,
                facing=angle_between(x, y, WORLD_W / 2, WORLD_H / 2),  # look at centre
                state=self._make_state(class_id, config.specs.get(pid)))

        self.round = 1
        self.round_active = True
        self.round_reset_at = 0.0
        self.over = False
        self.winner: Optional[str] = None

    @staticmethod
    def _make_state(class_id: str, spec) -> PlayerState:
        """Build the authoritative PlayerState. `spec` (from the server, never
        the client) overrides the class base attributes/level so a spec'd
        character fights with its real stats and nothing else can be faked."""
        state = PlayerState(CLASSES[class_id])
        if spec:
            a = state.attributes
            a.strength = spec.get("str", a.strength)
            a.dexterity = spec.get("dex", a.dexterity)
            a.intelligence = spec.get("int", a.intelligence)
            a.vitality = spec.get("vit", a.vitality)
            state.level = spec.get("level", state.level)
            state.health = state.derived_stats.max_health
            state.mana = state.derived_stats.max_mana
        return state

    # -- inputs ---------------------------------------------------------------
    def set_intent(self, pid: str, intent: Intent) -> None:
        f = self.fighters.get(pid)
        if f is not None:
            f.intent = intent

    # -- simulation -----------------------------------------------------------
    def tick(self, dt_ms: float) -> None:
        self.time_ms += dt_ms
        if self.over:
            return
        if not self.round_active:
            if self.time_ms >= self.round_reset_at:
                self._start_round()
            return

        for f in self.fighters.values():
            if f.alive:
                self._control(f, dt_ms)
        self._separate()
        for f in self.fighters.values():
            if f.alive and f.intent.attack:
                self._attack(f)

        self._check_round()

    def _separate(self) -> None:
        """Bodies don't pass through each other: push overlapping fighters
        apart so they meet at contact distance and stay there, which is what
        keeps a chase stable instead of oscillating through the target."""
        fs = [f for f in self.fighters.values() if f.alive]
        min_d = 2 * PLAYER_RADIUS
        for i in range(len(fs)):
            a = fs[i]
            for j in range(i + 1, len(fs)):
                b = fs[j]
                dx, dy = b.x - a.x, b.y - a.y
                d = math.hypot(dx, dy)
                if d >= min_d:
                    continue
                if d < 1e-6:
                    dx, dy, d = 1.0, 0.0, 1.0        # exactly stacked: split along x
                push = (min_d - d) / 2.0
                nx, ny = dx / d, dy / d
                a.x -= nx * push
                a.y -= ny * push
                b.x += nx * push
                b.y += ny * push
                a.x, a.y = self.obstacles.resolve(a.x, a.y, PLAYER_RADIUS)
                b.x, b.y = self.obstacles.resolve(b.x, b.y, PLAYER_RADIUS)

    def _control(self, f: Fighter, dt_ms: float) -> None:
        now = self.time_ms
        inp = f.intent
        dt = dt_ms / 1000.0
        if inp.aim is not None:
            f.facing = inp.aim

        # Start a dodge: a fast dash in the move (or facing) direction, invulnerable
        # for its duration -- the read-and-react beat that makes trading blows a fight.
        if inp.dodge and now >= f.dodge_cd_until_ms and now >= f.dodge_until_ms:
            mvx, mvy = inp.move
            f.dodge_dir = math.atan2(mvy, mvx) if (mvx or mvy) else f.facing
            f.dodge_until_ms = now + DODGE_MS
            f.dodge_cd_until_ms = now + DODGE_COOLDOWN_MS

        dodging = now < f.dodge_until_ms
        f.guarding = inp.guard and not dodging

        if dodging:
            speed = f.state.derived_stats.move_speed * DODGE_SPEED_MULT
            f.x += math.cos(f.dodge_dir) * speed * dt
            f.y += math.sin(f.dodge_dir) * speed * dt
        else:
            vx, vy = inp.move
            if vx or vy:
                length = math.hypot(vx, vy)
                speed = f.state.derived_stats.move_speed * (GUARD_MOVE_MULT if f.guarding else 1.0)
                if inp.aim is None:
                    f.facing = math.atan2(vy, vx)
                f.x += vx / length * speed * dt
                f.y += vy / length * speed * dt

        f.x = min(max(f.x, 0.0), WORLD_W)
        f.y = min(max(f.y, 0.0), WORLD_H)
        f.x, f.y = self.obstacles.resolve(f.x, f.y, PLAYER_RADIUS)

    def _attack(self, f: Fighter) -> None:
        interval = 1000.0 / f.state.derived_stats.attack_speed
        if self.time_ms - f.last_attack_ms < interval:
            return
        f.last_attack_ms = self.time_ms
        f.swing_until_ms = self.time_ms + SWING_MS
        reach = ATTACK_RANGE + PLAYER_RADIUS
        damage = f.state.derived_stats.attack_damage
        for other in self.fighters.values():
            if other is f or not other.alive:
                continue
            if dist(f.x, f.y, other.x, other.y) > reach:
                continue
            to_other = angle_between(f.x, f.y, other.x, other.y)
            if abs(wrap_angle(to_other - f.facing)) > ATTACK_HALF_ARC:
                continue
            if self.time_ms < other.dodge_until_ms:          # dodging -> invulnerable
                continue
            if other.guarding:                                # raised guard blocks frontal hits
                from_attacker = angle_between(other.x, other.y, f.x, f.y)
                if abs(wrap_angle(from_attacker - other.facing)) <= GUARD_HALF_ARC:
                    continue
            if other.state.take_damage(damage):
                other.alive = False

    def _check_round(self) -> None:
        alive = [f for f in self.fighters.values() if f.alive]
        if len(alive) > 1:
            return
        self.round_active = False
        self.round_reset_at = self.time_ms + ROUND_RESET_MS
        if alive:
            winner = alive[0]
            winner.wins += 1
            if winner.wins > self.cfg.best_of // 2:
                self.over = True
                self.winner = winner.pid

    def _start_round(self) -> None:
        self.round += 1
        self.round_active = True
        for pid, spawn in self._spawn_points(list(self.fighters)):
            f = self.fighters[pid]
            f.x, f.y = spawn
            f.facing = angle_between(f.x, f.y, WORLD_W / 2, WORLD_H / 2)
            f.alive = True
            f.state.restore()
            f.intent = Intent()
            f.dodge_until_ms = 0.0
            f.dodge_cd_until_ms = 0.0
            f.swing_until_ms = 0.0
            f.guarding = False

    def _spawn_points(self, pids: List[str]) -> List[Tuple[str, Tuple[float, float]]]:
        """Evenly spaced on a ring around the arena centre so no fighter starts
        on another. The ring is kept TIGHT -- a 1v1 spawns the two ~320 units
        apart so both are framed from the first frame and the fight starts at
        once, rather than a long walk across a huge world. It widens with the
        roster so a big free-for-all still fits everyone."""
        n = len(pids)
        cx, cy = WORLD_W / 2, WORLD_H / 2
        r = max(5 * UNIT, 1.5 * UNIT * n)
        out = []
        for i, pid in enumerate(pids):
            a = math.pi + math.tau * i / n   # start on the left, go round
            out.append((pid, (cx + math.cos(a) * r, cy + math.sin(a) * r)))
        return out

    # -- serialization --------------------------------------------------------
    def snapshot(self) -> dict:
        return {
            "v": SNAPSHOT_VERSION,
            "t": round(self.time_ms),
            "round": self.round,
            "over": self.over,
            "winner": self.winner,
            "players": [
                {
                    "id": f.pid,
                    "cls": f.class_id,
                    "x": round(f.x, 1),
                    "y": round(f.y, 1),
                    "a": round(f.facing, 3),
                    "hp": round(f.state.health, 1),
                    "mhp": round(f.state.derived_stats.max_health, 1),
                    "sw": self.time_ms < f.swing_until_ms,
                    "dg": self.time_ms < f.dodge_until_ms,
                    "gd": f.guarding,
                    "alive": f.alive,
                    "wins": f.wins,
                }
                for f in self.fighters.values()
            ],
        }
