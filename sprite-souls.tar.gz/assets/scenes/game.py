"""The main gameplay scene: the arena, the player, and the boss rush.
Movement is WASD/arrows, attack is Space (facing) or left-click (aim),
Shift is the dodge and E the guard — both of whose styles are the
class's own, see ClassDodge and ClassGuard — Esc returns to class
select."""

import bisect
import math
import random

import pygame

from core import obstacles
import sfx
from core.classes import CLASSES
from core.mathutil import angle_between, dist, wrap_angle
from core.player_state import PlayerState
from core.units import PX, SECOND, TILE, TURN, UNIT
from entities.devil_boss import DevilBoss
from entities.ice_dragon_boss import IceDragonBoss
from gfx import camera, platform
from gfx.facing import Turner, create_views
from gfx.pixelart import (create_pixel_surface, flipped, rgb, scaled, squash_x,
                          tilted, tint_fill, tint_mult)
from gfx.sprites import (BOULDER_SPRITE, CLASS_GUARD_SPRITES, CLASS_SPRITES,
                         CLASS_SWING_SPRITES, DAGGER_SPRITE, DEAD_TREE_SPRITE,
                         FERN_SPRITE, FIREBALL_SPRITE, PINE_SPRITE,
                         SHIELD_BACK_SPRITE, SHIELD_SPRITE, STUMP_SPRITE,
                         SWORD_SPRITE)
from gfx.walk import Waddle
from settings import CAMERA_TILT, HEIGHT, WIDTH, WORLD_H, WORLD_W

from .effects import (Afterimage, ArcTrail, Barrier, BossAnnounce, Explosion,
                      FloatingText, GroundFlare, WeaponSweep, ease_out_cubic)
from .hud import draw_hud
from .manager import Scene

# Invulnerability window after taking contact damage.
CONTACT_DAMAGE_COOLDOWN_MS = 0.7 * SECOND
# How long a melee weapon takes to travel its arc. The body's empty-
# handed swing art is held for exactly this long, so the weapon is in
# precisely one place at a time.
SWING_MS = 0.16 * SECOND
# The gap between swings for a class that plays more than one (see
# ClassAttack.swings). Short enough that the second is already coming
# back before the first has finished — a flurry, not two attacks.
SWING_INTERVAL_MS = 0.11 * SECOND
FIREBALL_SPEED = 14.375 * UNIT          # per second
PLAYER_RADIUS = 0.5 * UNIT
# Pale liturgical gold for the prelate's blink — the ghost it leaves and
# the puff at both ends. Deliberately not the ice-blue of a freeze or the
# orange/red of the devil's telegraphs: every flash colour in this game
# means exactly one thing.
BLINK_COLOR = 0xE8D9A0
# The prelate's staff head, where his fire is already burning before he
# throws it: a fireball starts there and flies at that height, so the
# spell is seen leaving the thing that made it. A world distance out to
# the side (the staff rides his far arm, the opposite side from the
# knight's shield) and a SCREEN height up the shaft — they are hurled,
# not rolled. Both are read off the art in gfx/sprites/sorcerer.py; move
# the staff there and these move with it.
STAFF_TIP_REACH = 0.375 * UNIT
FIREBALL_LIFT = 22 * PX
# Chest height on a body standing on the plane — where held weapons swing
# from and where spells leave the hand. Screen height too: it is exactly
# half of PLAYER_RADIUS's number and nothing but the unit says so.
PLAYER_HAND_LIFT = 16 * PX

# --- the guard (E) ----------------------------------------------------
# One colour per style, because every flash in this game means exactly
# one thing: cold steel for the shield turning a blow, violet-white for
# the prelate's ward, pale green for the flagellant's parry. None of the
# three is the blink's pale gold or the ice-blue of a freeze.
GUARD_COLORS = {
    'shield': 0xBFC7CF,
    'barrier': 0x9AA8FF,
    'parry': 0x8FE6A8,
}
# What comes up when a blow dies on the guard — the styles stop things
# differently enough to be worth naming as they do it.
GUARD_MESSAGES = {
    'shield': 'Blocked!',
    'barrier': 'Warded!',
    'parry': 'Parry!',
}
# How far out a guard's impact spark lands. A world distance: it is a
# position on the plane, and the projection foreshortens it.
GUARD_IMPACT_REACH = 0.5 * UNIT
# Where the shield ends up once it is up: out in front of the body, and
# held close deliberately — the depth axis is what carries it up and down
# the screen as he turns, and further out means it rides past his head
# when he faces away instead of tucking in behind his back.
SHIELD_OFFSET = 0.4 * UNIT
# Where it comes up FROM: hanging on his near arm, which is where the
# body art carries it — a quarter turn off his heading, so the start of
# the raise lines up with the resting shield in every view. Pressing E
# has to look like a shield being brought up and across, not like a
# shield appearing at arm's length.
SHIELD_REST_REACH = 0.3 * UNIT
SHIELD_REST_LIFT = 8 * PX
SHIELD_RAISE_MS = 0.13 * SECOND
# How far the shield's covered sector is painted across the floor. It
# stands for a direction, not a reach — nothing about the block cares how
# far away the blow started — so it is drawn just long enough to be read
# at a glance without becoming a searchlight.
GUARD_ARC_RADIUS = 1.6 * UNIT
# Where the band's inner edge sits, as a fraction of that radius — it
# stands off the body rather than being painted around his feet.
GUARD_ARC_INNER = 0.72
# The ward's sphere. A radius on screen rather than on the plane — it is
# a ball standing around the body, so it is never flattened.
BARRIER_RADIUS = 27 * PX
# The last of a held block, where the covered sector starts to flicker.
# The only warning before the guard breaks, and the reason it needs no
# meter on the HUD.
GUARD_FATIGUE_MS = 0.35 * SECOND

_guard_arc_cache = {}


def _guard_arc_surface(half_arc, angle, color):
    """The arc a raised shield covers, as a decal on the plane: built in
    world units and flattened once, so what is painted is exactly the
    projection of the arc `_inside_guard_arc` tests against.

    A *band* along the outer edge rather than a filled wedge, and that
    is not decoration: a filled wedge in front of the player is already
    the swing (see melee_attack), and two mechanics may not wear the
    same shape. A band standing off him at arm's length reads as what it
    is — a wall on that side.

    Cached per rounded heading. Rebuilding two polygons every frame for
    a stance the player holds for a second and a half is the sort of
    thing the pygbag build notices first."""
    key = (round(angle, 1), round(half_arc, 2), color)
    surf = _guard_arc_cache.get(key)
    if surf is None:
        r = int(GUARD_ARC_RADIUS)
        surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        steps = max(8, int(half_arc * 2 / 0.15))

        def sector(radius, fill):
            points = [(r, r)]
            for i in range(steps + 1):
                a = angle - half_arc + (half_arc * 2) * i / steps
                points.append((r + radius * math.cos(a), r + radius * math.sin(a)))
            pygame.draw.polygon(surf, fill, points)

        sector(r, rgb(color))
        # pygame's draw writes its colour straight into an SRCALPHA
        # surface rather than blending, so a transparent sector punches
        # the middle back out and leaves the rim.
        sector(r * GUARD_ARC_INNER, (0, 0, 0, 0))
        surf = camera.flatten(surf)
        _guard_arc_cache[key] = surf
    return surf


# The forest floor: loam, and the same loam a shade lighter where the
# diamond tiling picks it out. Those two used to be a visible checker —
# they are now four values apart on purpose. The tiling is still the
# clearest thing telling the eye this plane is tilted rather than seen
# from overhead, and the player can still count it across the map, but a
# forest floor with a legible tile grid reads as a paved courtyard with
# trees standing on it. What does the work now is the litter scattered
# over the top (see _sow_litter).
ARENA_DARK = 0x171B14
ARENA_LIGHT = 0x1A1E16
# The seam is the line that decides between "ground" and "flagstones",
# and it decides it almost on its own — three values off the loam it
# separates is a diamond you can still find if you look for it, and six
# is grout.
ARENA_SEAM = 0x141811
# Floor outside the arena is still drawn — it just gets dimmed, so the
# play boundary reads as the wood getting too thick to enter rather than
# a hard invisible wall. Written as what the floor is multiplied *by*:
# black at 150/255 alpha over it and a multiply by 105/255 are the same
# arithmetic, and the multiply is a blend flag on a rect fill rather than
# a screen-sized surface. The out-of-bounds bands move with the view now,
# so this is paid every frame instead of once at startup. The scenery
# standing out there is tinted by the same number, or the treeline would
# be lit while the ground under it was not.
ARENA_OOB_TINT = 0x696969
ARENA_OOB_MULT = rgb(ARENA_OOB_TINT)
# What is strewn over the loam. Everything here is drawn *flattened* by
# the camera tilt, exactly as a ground decal is: a patch of moss is a
# circle on the plane, and a circle on the plane is an ellipse on screen.
FLOOR_DAPPLE = 0x0F1210     # the shade under a canopy nobody drew
FLOOR_MOSS = 0x243019
FLOOR_MOSS_LIT = 0x2E3C21
FLOOR_ROOT = 0x2E2619
FLOOR_LEAF = 0x3D2F1A
FLOOR_LEAF_DEAD = 0x574320   # the one warm note down there
FLOOR_STONE = 0x35353B
# The litter is baked once and never re-rolled, so it is seeded: what is
# random per playthrough is the forest standing on the floor
# (core/obstacles.py), not the texture of the floor itself. A fixed seed
# also means art tuning here is comparable between runs.
FLOOR_LITTER_SEED = 41077
# Floor tiles are diamonds at the camera's own ratio, so the tiling reads
# as squares lying on the tilted plane.
FLOOR_TILE_W = 1 * TILE
# The diamond's height on screen, rounded to an EVEN number of pixels.
# The floor is now a repeating patch blitted at whole-pixel offsets as
# the view scrolls, so the pattern's period has to be a whole number of
# pixels — a fractional one drifts and opens seams between patches. Two
# pixels off the true 67.2 is a 1% error in the tile's aspect and
# invisible; a seam running down the arena is not.
FLOOR_TILE_H = 2 * round(FLOOR_TILE_W * CAMERA_TILT / 2)
# The tiling repeats every two tiles across (the light/dark checker flips
# with each one) and every two rows down, which is one tile high since
# rows are offset by half a diamond.
_PERIOD_W = 2 * int(FLOOR_TILE_W)
_PERIOD_H = FLOOR_TILE_H
# The baked patch is a whole number of those periods and at least a
# screen across, so however the view is scrolled at most two by two of
# them floor the entire frame.
FLOOR_PATCH_W = _PERIOD_W * math.ceil(WIDTH / _PERIOD_W)
FLOOR_PATCH_H = _PERIOD_H * math.ceil(HEIGHT / _PERIOD_H)


def _wrapped(x, y, reach, w, h):
    """Every place something at (x, y) has to be drawn for the patch to
    still tile: itself, plus a copy across whichever edges it overhangs.

    The patch is laid out on a grid (see _draw_floor), so anything drawn
    on it that runs off one edge has to arrive at the opposite one, or a
    seam opens the moment the view scrolls past it. A tuft of moss half
    over the right edge is a tuft of moss half over the left edge."""
    xs = [x]
    if x - reach < 0:
        xs.append(x + w)
    if x + reach > w:
        xs.append(x - w)
    ys = [y]
    if y - reach < 0:
        ys.append(y + h)
    if y + reach > h:
        ys.append(y - h)
    return [(px, py) for px in xs for py in ys]
# --- the forest ------------------------------------------------------
# What each kind of prop in core/obstacles.py looks like, and how wide a
# contact shadow it casts. The kind name is the whole of the join between
# the two files: core decides what a pine stops, this decides what one
# looks like. A kind missing from here will raise on the first frame
# rather than quietly not being drawn.
PROP_ART = {
    'pine': PINE_SPRITE,
    'dead_tree': DEAD_TREE_SPRITE,
    'boulder': BOULDER_SPRITE,
    'stump': STUMP_SPRITE,
    'fern': FERN_SPRITE,
}
# A shadow is the footprint on the ground, not the spread of the thing
# above it: a fir's shadow is the foot of its trunk, so it is a good deal
# narrower than the circle you collide with.
PROP_SHADOW = {
    'pine': 0.22 * UNIT,
    'dead_tree': 0.22 * UNIT,
    'boulder': 0.5 * UNIT,
    'stump': 0.3 * UNIT,
    'fern': 0.16 * UNIT,
}
# Scenery is lit by the same overcast nothing the bodies are, but there
# is a great deal more of it: at the alpha a body casts, several hundred
# contact shadows stop reading as shadows and start reading as holes in
# the ground.
PROP_SHADOW_ALPHA = 55
# Room kept clear of scenery around the spawn point. Death puts the
# player back here with no say in it, so it is the one place on the map
# that must never be a thicket.
SPAWN_CLEARING = 5 * UNIT
# What a trunk drops to while a body that would otherwise be lost behind
# it is standing there. Not zero: a tree that vanishes reads as a bug,
# and the player still has to know the thing is in the way.
OCCLUDER_ALPHA = 90
# How far a prop can reach from its own ground point, for deciding what
# is on screen. Read off the art and the largest size anything is grown
# to, rather than written down, so a taller tree cannot be clipped away
# by a number nobody remembered to raise.
_PROP_BIGGEST = max(obstacles.PROP_SCALES)
PROP_MAX_H = max(len(art.rows) for art in PROP_ART.values()) * _PROP_BIGGEST
PROP_MAX_W = max(len(art.rows[0]) for art in PROP_ART.values()) * _PROP_BIGGEST

# Where the next boss comes in: a ring around the player rather than a
# fixed set of arena coordinates. The world is far larger than the view
# now, so a corner of the map is somewhere the player would have to go
# looking for the fight. Near enough that the whole ring is on screen
# (the far end is under a third of the frame away in either direction,
# foreshortening included), far enough that nothing lands in their lap.
BOSS_SPAWN_RING = (9 * UNIT, 12 * UNIT)


class _PropView:
    """One scattered prop, with everything drawing it needs already
    worked out. Built once when the forest is sown: the surface, its
    mirroring and the dimming on anything standing outside the world
    never change, and there can be several hundred of them."""

    __slots__ = ('x', 'y', 'surf', 'shadow')

    def __init__(self, x, y, surf, shadow):
        self.x = x
        self.y = y
        self.surf = surf
        self.shadow = shadow


_fade_cache = {}


def _faded(surf):
    """A prop with a body behind it, drawn see-through.

    Cached per surface, because `set_alpha` is a property of the surface
    rather than of the blit — without a copy, fading one fir would fade
    every fir on the map, including the ones with nothing behind them."""
    out = _fade_cache.get(id(surf))
    if out is None:
        out = surf.copy()
        out.set_alpha(OCCLUDER_ALPHA)
        _fade_cache[id(surf)] = out
    return out


class _Projectile:
    __slots__ = ('x', 'y', 'vx', 'vy', 'damage', 'max_dist', 'traveled', 'active')

    def __init__(self, x, y, angle, damage, max_dist):
        self.x, self.y = x, y
        self.vx = math.cos(angle) * FIREBALL_SPEED
        self.vy = math.sin(angle) * FIREBALL_SPEED
        self.damage = damage
        self.max_dist = max_dist
        self.traveled = 0.0
        self.active = True


class GameScene(Scene):
    def enter(self, class_id='knight', god_mode=False,
              mode='bossmode', role='client', nameplates=None, seed=None):
        # mode: 'bossmode' (solo) | '1v1' | 'multiplayer'.
        # role: 'client' (renders) | 'server' (headless authoritative sim).
        # nameplates: {player_id: display_name} shown above characters in MP.
        # seed: makes the sim deterministic (forest scatter, spawn points, boss
        # AI) -- one match per process, so seeding the global RNG is enough.
        self.mode = mode
        self.role = role
        self.headless = (role == 'server')
        self.nameplates = nameplates or {}
        if seed is not None:
            random.seed(seed)
        self.god_mode = god_mode
        self.player_state = PlayerState(CLASSES[class_id])

        self.player_views = create_views(CLASS_SPRITES[class_id])
        # The body drawn while a swing is playing, for a class that
        # carries its weapon in its art — the same views with an empty
        # hand, since the weapon is out being swung. None for a class
        # that was never drawn holding one.
        swing_art = CLASS_SWING_SPRITES.get(class_id)
        self.player_swing_views = create_views(swing_art) if swing_art else None
        # Likewise for the guard: the body with the shield arm empty,
        # drawn while the scene holds that shield up in front of him.
        guard_art = CLASS_GUARD_SPRITES.get(class_id)
        self.player_guard_views = create_views(guard_art) if guard_art else None
        self.player_turner = Turner(self.player_views)
        self.sword_surf = create_pixel_surface(SWORD_SPRITE)
        self.shield_surf = create_pixel_surface(SHIELD_SPRITE)
        self.shield_back_surf = create_pixel_surface(SHIELD_BACK_SPRITE)
        self.dagger_surf = create_pixel_surface(DAGGER_SPRITE)
        self.fireball_surf = create_pixel_surface(FIREBALL_SPRITE)

        self.player_x, self.player_y = WORLD_W / 2, WORLD_H / 2
        # The view starts already looking at him. Scene instances are
        # reused, so without this it would open wherever the last visit
        # left it and pan across the map on the first frame.
        camera.snap_to(self.player_x, self.player_y)
        # A forest per playthrough rather than a level: the scatter is
        # unseeded, so entering the game twice is entering two different
        # woods. It has to exist before the first boss is spawned — a
        # boss resolves against it on its very first physics frame.
        self._sow_forest()
        self.enemies = []
        self.projectiles = []
        self.effects = []
        # Pending (delay_ms, callback) pairs — Phaser's delayedCall.
        self.scheduled = []

        self.time_ms = 0.0
        self.last_attack_ms = -math.inf
        # While this holds, the swing is on screen and the sword is in
        # the air rather than in his hand — see _player_surface().
        self.swing_until = 0.0
        self.last_contact_damage_ms = -math.inf
        self.dodge_until = 0.0
        self.dodge_cooldown_until = 0.0
        self.dodge_angle = 0.0
        # -inf rather than 0: `guard_until` doubles as "when the guard
        # ended", and the shield spends a moment coming down from it, so
        # a zero here would lower a shield he never raised on frame one.
        self.guard_until = -math.inf
        self.guard_cooldown_until = 0.0
        # When the shield started coming up, so the raise can be animated
        # rather than the shield simply appearing at arm's length.
        self.guard_started_ms = -math.inf
        # E still held down. Only the shield stance cares: the ward and
        # the parry window are out of the player's hands once cast.
        self.guard_held = False
        # Where he is in his stride. Every body in the arena has one.
        self.waddle = Waddle()
        self.frozen_until = 0.0
        self.hit_flash_until = 0.0
        self.shake_until = 0.0
        self.boss_index = 0
        # Direction the player last moved or attacked in: it aims keyboard
        # attacks and picks which side of the body is drawn. Starts at
        # +y — toward the camera — to match the Turner's front view.
        self.facing_angle = math.pi / 2

        # The floor patch and vignette are static (a repeating ground tile and
        # a screen-sized darkening), so build them once and reuse across every
        # entry -- re-picking a class or respawning then costs nothing here.
        cls = GameScene
        if getattr(cls, '_floor_cache', None) is None:
            cls._floor_cache = self._create_floor_patch()
        if getattr(cls, '_vignette_cache', None) is None:
            cls._vignette_cache = self._vignette()
        self.floor = cls._floor_cache
        self.vignette = cls._vignette_cache
        self.world = pygame.Surface((WIDTH, HEIGHT))

        self.spawn_boss()

    # --- the forest ------------------------------------------------------

    def _sow_forest(self):
        """Scatter the map's scenery and work out how to draw it.

        The field is kept sorted by depth (core/obstacles.py does the
        sorting), which is what lets `_visible_props` cut the slice that
        can reach the frame with two bisections instead of walking
        several hundred trees every frame."""
        # Density is a property of the MAP/mode, identical on every platform
        # (cross-play safe): the 1v1/multiplayer arena is a light, quick-loading
        # wood; boss-rush keeps the full 9000-throw forest. The full forest
        # rejection-samples for ~12s on the MiSTer A9, which is why the online
        # modes use the lighter map.
        # 1v1/multiplayer = light arena; boss-rush keeps a fuller (but not the
        # full 9000-throw, ~17s-on-A9) wood so it still loads in a few seconds.
        density = 0.15 if self.mode in ('1v1', 'multiplayer') else 0.4
        self.obstacles = obstacles.scatter(
            WORLD_W, WORLD_H, density=density,
            clearings=((self.player_x, self.player_y, SPAWN_CLEARING),))
        self.props = [self._prop_view(p) for p in self.obstacles.props]
        self._prop_depths = [p.y for p in self.obstacles.props]

    @staticmethod
    def _prop_view(prop):
        surf = scaled(create_pixel_surface(PROP_ART[prop.kind]), prop.scale)
        if prop.flipped:
            surf = flipped(surf)
        if not (0 <= prop.x <= WORLD_W and 0 <= prop.y <= WORLD_H):
            # The treeline outside the world, dimmed by exactly what the
            # floor out there is dimmed by. Lit trees standing on unlit
            # ground would undo the whole point of the boundary.
            surf = tint_mult(surf, ARENA_OOB_TINT)
        return _PropView(prop.x, prop.y, surf,
                         PROP_SHADOW[prop.kind] * prop.scale)

    def _visible_props(self):
        """The props that can reach the frame this frame, still in depth
        order. A prop stands *up* from its ground point, so one whose
        feet are below the bottom edge can still have its crown in
        shot — hence the extra sprite height on that end and none on the
        other."""
        top = camera.unproject(0, -8)[1]
        bottom = camera.unproject(0, HEIGHT + PROP_MAX_H)[1]
        lo = bisect.bisect_left(self._prop_depths, top)
        hi = bisect.bisect_right(self._prop_depths, bottom)
        ox = camera.scroll()[0]
        return [view for view in self.props[lo:hi]
                if -PROP_MAX_W <= view.x - ox <= WIDTH + PROP_MAX_W]

    def _body_rects(self):
        """Where on screen the bodies are that a trunk must not be
        allowed to swallow — the player, and every boss, because a boss
        whose telegraph flash is behind a fir is a boss whose attack
        cannot be read. Paired with the world depth they stand at, since
        only a prop *in front* of a body can hide it."""
        sx, sy = camera.project(self.player_x, self.player_y)
        rects = [(self.player_y,
                  pygame.Rect(round(sx - PLAYER_RADIUS),
                              round(sy - PLAYER_RADIUS * 2),
                              round(PLAYER_RADIUS * 2), round(PLAYER_RADIUS * 2)))]
        for boss in self.enemies:
            bx, by = camera.project(boss.x, boss.y)
            height = boss.display_height
            rects.append((boss.y,
                          pygame.Rect(round(bx - boss.radius),
                                      round(by - boss.ground_lift - height),
                                      round(boss.radius * 2), round(height))))
        return rects

    def _draw_prop(self, target, view, bodies):
        sx, sy = camera.project(view.x, view.y)
        rect = view.surf.get_rect(
            midbottom=(round(sx), round(sy + camera.FOOT_SINK)))
        surf = view.surf
        for depth, body in bodies:
            if depth < view.y and rect.colliderect(body):
                surf = _faded(surf)
                break
        target.blit(surf, rect, special_flags=platform.ALPHA_BLIT)

    # --- helpers other objects use -------------------------------------

    def player_pos(self):
        return self.player_x, self.player_y

    def add_effect(self, effect):
        if self.headless:   # server sims state only; effects are pure-visual
            return
        self.effects.append(effect)

    def schedule(self, delay_ms, callback):
        self.scheduled.append([delay_ms, callback])

    @property
    def is_player_dodging(self):
        """I-frames — every dodge style grants them for its duration."""
        return self.time_ms < self.dodge_until

    @property
    def is_player_committed(self):
        """Mid-roll: the body is thrown along a fixed heading and neither
        input nor attacks get a say until it lands. A blink is *not*
        committed — it has already arrived, so the prelate keeps control
        for the rest of his i-frames."""
        return (self.is_player_dodging
                and self.player_state.character_class.dodge.style == 'roll')

    @property
    def is_player_frozen(self):
        return self.time_ms < self.frozen_until

    @property
    def is_player_guarding(self):
        """The guard is up: a shield raised, a ward standing, or the
        parry window open. Every style refuses damage while this holds —
        what differs is *which* damage, which is `_guard_stops`."""
        return self.time_ms < self.guard_until

    @property
    def is_player_bracing(self):
        """Holding the shield. A stance rather than an action: it takes
        the arm and the feet with it, so the knight is slowed and cannot
        swing. The ward and the parry are cast and let go of, and leave
        their owner free to fight — anything that means "the shield is
        up" must ask this, anything that means "cannot be hurt from
        there" must ask is_player_guarding."""
        return (self.is_player_guarding
                and self.player_state.character_class.guard.style == 'shield')

    # --- input ----------------------------------------------------------

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                self.try_attack(self.facing_angle)
            elif event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT):
                self.try_dodge()
            elif event.key == pygame.K_e:
                self.try_guard()
            elif event.key == pygame.K_ESCAPE:
                self.manager.start('class-select')
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_e:
                self.lower_guard()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # The cursor picks a spot on the ground plane, not a screen
            # pixel — unproject before this becomes a world heading.
            wx, wy = camera.unproject(*event.pos)
            self.try_attack(angle_between(self.player_x, self.player_y, wx, wy))

    # --- update ---------------------------------------------------------

    def update(self, dt_ms):
        self.time_ms += dt_ms
        self.player_state.regenerate(dt_ms / 1000)
        self.waddle.advance(self.handle_movement(dt_ms), dt_ms)
        self.player_turner.update(self.facing_angle, dt_ms)
        self._update_guard()

        for boss in self.enemies:
            # Staggered: no AI and neither damage channel, so a parry
            # buys a real window rather than a boss that keeps swinging
            # while it reels. It still moves under physics_update (it
            # has none — stun() zeroes the velocity) and still takes hits.
            if not boss.is_stunned:
                boss.update_ai(self.player_x, self.player_y, dt_ms)
            boss.physics_update(dt_ms)
            self._collide_with_boss(boss)
            hit = (None if boss.is_stunned
                   else boss.poll_area_attack(self.player_x, self.player_y))
            if hit:
                applied = self.damage_player(hit.damage, boss)
                if applied and hit.freeze_ms:
                    self.freeze_player(hit.freeze_ms)

        self._update_projectiles(dt_ms)

        for item in self.scheduled[:]:
            item[0] -= dt_ms
            if item[0] <= 0:
                self.scheduled.remove(item)
                item[1]()

        self.effects = [e for e in self.effects if e.update(dt_ms)]
        self.enemies = [b for b in self.enemies if not b.dead]

        # Boss rush: spawn the next boss when the arena is empty.
        if not self.enemies:
            self.spawn_boss()

        # Last, so the view follows where everything actually ended up —
        # a blow that shoved him out of a boss counts as much as a step.
        # It only moves at all once he leaves the middle of the frame;
        # see camera.follow, which is also why nothing above needs to
        # know the view can move.
        camera.follow(self.player_x, self.player_y, dt_ms)

    def _collide_with_boss(self, boss):
        """Circle collider: block the player at the boss body and apply
        contact damage — skipped entirely while dodging, so the roll
        passes straight through the enemy."""
        if not boss.collidable or self.is_player_dodging:
            return
        d = dist(self.player_x, self.player_y, boss.x, boss.y)
        min_d = PLAYER_RADIUS + boss.radius
        if d >= min_d:
            return
        # Push the player out along the contact normal (boss is immovable).
        if d > 0:
            nx = (self.player_x - boss.x) / d
            ny = (self.player_y - boss.y) / d
        else:
            nx, ny = 1.0, 0.0
        self.player_x = boss.x + nx * min_d
        self.player_y = boss.y + ny * min_d
        self._clamp_player()

        # Souls-style: casual contact is harmless unless an attack is
        # active — and a staggered boss is not attacking, whatever state
        # it was caught in.
        damage = None if boss.is_stunned else boss.contact_damage
        if damage is not None:
            self.damage_player(damage, boss)

    def _clamp_player(self):
        """Keep the player inside the world and out of the scenery.

        Every way the player's position can change goes through here —
        walking, a roll, a blink, being shoved out of a boss — which is
        the only reason one call to the forest covers all of them. A new
        one that skips it walks through trees."""
        self.player_x = min(max(self.player_x, PLAYER_RADIUS), WORLD_W - PLAYER_RADIUS)
        self.player_y = min(max(self.player_y, PLAYER_RADIUS), WORLD_H - PLAYER_RADIUS)
        self.player_x, self.player_y = self.obstacles.resolve(
            self.player_x, self.player_y, PLAYER_RADIUS)

    def try_dodge(self):
        if self.is_player_frozen:
            return  # frozen solid
        if self.is_player_dodging or self.time_ms < self.dodge_cooldown_until:
            return

        # Dodging out of a block drops the shield: you cannot roll along
        # behind it. Nothing happens to a ward or a parry window, which
        # is what makes blinking while warded worth doing.
        self.lower_guard()

        dodge = self.player_state.character_class.dodge
        if dodge.style == 'blink':
            self._blink(dodge)
        else:
            # Roll toward the current movement input; backstep-style
            # toward facing if standing still. handle_movement() does the
            # travelling — a roll happens over its whole duration.
            vx, vy = self._movement_input()
            self.dodge_angle = math.atan2(vy, vx) if (vx or vy) else self.facing_angle

        self.dodge_until = self.time_ms + dodge.duration_ms
        self.dodge_cooldown_until = self.dodge_until + dodge.cooldown_ms

    def _blink(self, dodge):
        """The prelate's dodge: gone and arrived in the same frame.

        Aimed with the *cursor*, not the movement keys — so he can throw
        himself somewhere his feet were never heading. The whole distance
        is always crossed: clamping the jump to a cursor sitting near the
        player would turn the escape into a shuffle at exactly the moment
        it is needed."""
        wx, wy = camera.unproject(*pygame.mouse.get_pos())
        dx, dy = wx - self.player_x, wy - self.player_y
        angle = math.atan2(dy, dx) if (dx or dy) else self.facing_angle

        # Leave the ghost behind before the body moves off the spot. It is
        # a flat tint_fill silhouette rather than a faded copy of the
        # sprite: this cast is high-contrast against a near-black floor,
        # so a merely translucent body still reads as a *body*, and for a
        # beat the player sees two prelates and no clue which one they
        # are. A solid pale shape can only be residue. (tint_mult is no
        # use here — it can only darken, which turns the bone mitre muddy.)
        ghost = squash_x(tint_fill(self.player_turner.surface(), BLINK_COLOR),
                         self.player_turner.squash)
        self.add_effect(Afterimage(ghost, self.player_x, self.player_y))
        self._blink_flare(self.player_x, self.player_y)

        self.player_x += math.cos(angle) * dodge.distance
        self.player_y += math.sin(angle) * dodge.distance
        self._clamp_player()

        self._blink_flare(self.player_x, self.player_y)
        # Arrive already facing the way he went: animating the turn would
        # read as a spin across ground he never crossed.
        self.facing_angle = angle
        self.player_turner.face_now(angle)

    def _blink_flare(self, x, y):
        """The light on the floor at each end of a jump. A ground decal,
        so the body standing in it is never washed out by it."""
        self.add_effect(GroundFlare(x, y, 0.75 * UNIT, BLINK_COLOR))

    # --- the guard ------------------------------------------------------

    def try_guard(self):
        """E: raise the class's own guard — see ClassGuard. The shield is
        a stance that stays up while E is held; the ward and the parry
        are struck once and run their own duration out."""
        if self.is_player_frozen:
            return  # frozen solid
        if self.is_player_committed:
            return  # mid-roll, both hands busy
        if self.time_ms < self.swing_until:
            # Mid-swing: the body is already holding one piece of gear out
            # in front of it. Letting the guard open here would ask it to
            # let go of the sword and the shield at once, and there is no
            # view of him carrying neither.
            return
        if self.is_player_guarding or self.time_ms < self.guard_cooldown_until:
            return

        guard = self.player_state.character_class.guard
        if guard.style == 'barrier':
            # Mana is checked before the cooldown is committed, exactly
            # as a failed fireball doesn't lock the attack button.
            if not self.player_state.spend_mana(guard.mana_cost):
                self.show_floating_text('Out of mana', 0x5DADE2)
                return
            self.add_effect(Barrier(self.player_pos, BARRIER_RADIUS,
                                    GUARD_COLORS['barrier'], guard.duration_ms,
                                    lift=PLAYER_HAND_LIFT))
        elif guard.style == 'parry':
            self._parry_flourish(guard)
        else:
            self.guard_held = True

        self.guard_started_ms = self.time_ms
        self.guard_until = self.time_ms + guard.duration_ms
        self.guard_cooldown_until = self.guard_until + guard.cooldown_ms

    def lower_guard(self):
        """Letting go of E takes a held shield down early — and only a
        held shield; nothing else is still in the player's hands. The
        cooldown runs from the moment the arm comes down, so a block held
        for a single blow costs less than one held through a whole
        exchange."""
        if not self.guard_held:
            return
        self.guard_held = False
        if self.is_player_guarding:
            guard = self.player_state.character_class.guard
            self.guard_until = self.time_ms
            self.guard_cooldown_until = self.time_ms + guard.cooldown_ms

    def _update_guard(self):
        """A shield held for its whole duration *breaks* rather than
        quietly going away, and says so. It is the only way a guard ends
        while the player is still holding it, so it is the only one that
        needs explaining."""
        if self.guard_held and not self.is_player_guarding:
            self.guard_held = False
            self.show_floating_text('Guard broken', GUARD_COLORS['shield'])

    def _guard_stops(self, source):
        """Does the raised guard stop this blow — and what does stopping
        it do? The three styles differ exactly here: the shield only
        covers the arc it is pointed at, the ward covers everything, and
        the parry covers its arc AND staggers whoever swung."""
        guard = self.player_state.character_class.guard
        if not self._inside_guard_arc(source, guard):
            return False

        self._guard_impact(source, guard)
        if guard.style == 'parry':
            # One blow per press: the window closes on what it caught.
            self.guard_until = self.time_ms
            self._parry_stun(source, guard)
        return True

    def _inside_guard_arc(self, source, guard):
        """Where the blow came from, against where the guard is pointed.
        The arc is measured off `facing_angle`, so it is aimed by turning
        — a hit from the flank walks straight past a shield. A guard with
        a half-arc of 180 (the ward) can never fail this, and a blow with
        no source on the plane has no direction to test.

        The direction comes from the *body* that owns the blow, not from
        the blow itself, which is exact for cones, sweeps and contact and
        a few degrees generous for a boss-owned shard that has outlived
        the swoop that fired it. Generous is the right way round."""
        if source is None:
            return True
        to_source = angle_between(self.player_x, self.player_y, source.x, source.y)
        return abs(wrap_angle(to_source - self.facing_angle)) <= \
            math.radians(guard.half_arc_degrees)

    def _guard_impact(self, source, guard):
        """The spark where the blow died, out on the guard's own surface
        facing whatever threw it — so a block reads as something being
        caught rather than as damage that failed to turn up."""
        color = GUARD_COLORS[guard.style]
        angle = self.facing_angle
        if source is not None:
            angle = angle_between(self.player_x, self.player_y, source.x, source.y)
        self.add_effect(Explosion(
            self.player_x + math.cos(angle) * GUARD_IMPACT_REACH,
            self.player_y + math.sin(angle) * GUARD_IMPACT_REACH,
            0.28 * UNIT, color=color, lift=PLAYER_HAND_LIFT))
        self.show_floating_text(GUARD_MESSAGES[guard.style], color)

    def _parry_stun(self, source, guard):
        """The parry's whole reward: whoever's blow was caught reels for
        a second, wide open. A boss inside its own i-frames is
        untouchable rather than staggerable — the dragon mid-flight is
        the case that matters — so there the parry is 'only' a free
        block, and it says nothing it can't back up."""
        if source is None or source.is_dodging:
            return
        source.stun(guard.stun_ms)
        self.add_effect(FloatingText(source.x, source.y - 1.75 * UNIT,
                                     'Stunned!', 18, GUARD_COLORS['parry']))

    def _parry_flourish(self, guard):
        """The tell: a knife flicked across the guarded arc and a short
        trail on the ground under it, both lasting exactly as long as the
        window does. A window nobody can see is a window nobody can
        learn."""
        half_arc = math.radians(guard.half_arc_degrees)
        # The knife doing the flicking is one of the pair in his hands, so
        # the body has to let go of it for the length of the window — the
        # same hand-over a swing makes, for the same reason.
        self.swing_until = max(self.swing_until, self.time_ms + guard.duration_ms)
        self.add_effect(WeaponSweep(self.player_pos, self.dagger_surf,
                                    self.facing_angle, half_arc,
                                    grip_radius=14, duration_ms=guard.duration_ms,
                                    lift=PLAYER_HAND_LIFT))
        self.add_effect(ArcTrail(self.player_x, self.player_y, 1.25 * UNIT,
                                 self.facing_angle, half_arc,
                                 GUARD_COLORS['parry'], 0.22, guard.duration_ms))

    def _movement_input(self):
        # An external input source (e.g. a gamepad launcher) can drive movement
        # by setting self.ext_move to a (dx, dy) direction; None = keyboard.
        ext = getattr(self, 'ext_move', None)
        if ext is not None:
            return ext
        keys = pygame.key.get_pressed()
        left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        up = keys[pygame.K_UP] or keys[pygame.K_w]
        down = keys[pygame.K_DOWN] or keys[pygame.K_s]
        return (1 if right else 0) - (1 if left else 0), (1 if down else 0) - (1 if up else 0)

    def handle_movement(self, dt_ms):
        """Move the player for this frame. Returns the ground he *walked*
        — a roll covers more than any step and is not a walk, and being
        frozen is not one either, so both report nothing to the stride."""
        speed = self.player_state.derived_stats.move_speed
        dt = dt_ms / 1000

        if self.is_player_frozen:
            return 0.0

        if self.is_player_committed:
            # Committed to the roll: input is ignored until it ends.
            dodge = self.player_state.character_class.dodge
            dodge_speed = speed * dodge.speed_multiplier
            self.player_x += math.cos(self.dodge_angle) * dodge_speed * dt
            self.player_y += math.sin(self.dodge_angle) * dodge_speed * dt
            self._clamp_player()
            return 0.0

        if self.is_player_bracing:
            # Behind the shield he walks, he doesn't fight — and he still
            # turns at full rate, because turning is how the shield aims.
            speed *= self.player_state.character_class.guard.move_multiplier

        vx, vy = self._movement_input()
        if not (vx or vy):
            return 0.0

        # With a right-stick aim set (twin-stick), the launcher owns facing;
        # otherwise movement aims (keyboard / single-stick).
        if getattr(self, 'ext_aim', None) is None:
            self.facing_angle = math.atan2(vy, vx)
        length = math.hypot(vx, vy)
        before = (self.player_x, self.player_y)
        self.player_x += vx / length * speed * dt
        self.player_y += vy / length * speed * dt
        self._clamp_player()
        # The ground he actually covered, so walking into the arena wall
        # stops the stride instead of marching on the spot.
        return dist(*before, self.player_x, self.player_y)

    @property
    def walk_tilt(self):
        """Degrees the body is rocked this frame. Held at nothing while
        the turn animation runs — a body cannot lean and swap sides in
        the same frame without looking broken, and it keeps `tilted()`'s
        cache down to the eight views instead of every frame of every
        squash."""
        return 0.0 if self.player_turner.turning else self.waddle.tilt

    @property
    def walk_bob(self):
        return self.waddle.bob

    def try_attack(self, angle):
        if self.is_player_committed:
            return  # no attacking mid-roll (a blink lands free to act)
        if self.is_player_bracing:
            return  # the shield arm is the sword arm (a ward is not)
        if self.is_player_frozen:
            return  # frozen solid
        attack = self.player_state.character_class.attack
        stats = self.player_state.derived_stats
        cooldown_ms = 1000 / (stats.attack_speed * attack.speed_multiplier)
        if self.time_ms - self.last_attack_ms < cooldown_ms:
            return

        # Swing where you clicked and the body turns with it — otherwise
        # a mouse attack behind you comes out of the back of the sprite.
        self.facing_angle = angle

        if attack.style == 'fireball':
            # Mana is checked before the cooldown is consumed, so a failed
            # cast doesn't lock the attack button.
            if not self.player_state.spend_mana(attack.mana_cost):
                self.show_floating_text('Out of mana', 0x5DADE2)
                return
            self.last_attack_ms = self.time_ms
            self.cast_fireball(angle, stats.spell_power, attack.range)
            return

        self.last_attack_ms = self.time_ms
        self.melee_attack(angle, attack)

    def melee_attack(self, angle, attack):
        """Shared melee logic: hit enemies in range AND inside the swing
        arc. A class with more than one swing per attack plays them in
        turn, each landing its share of the one attack's damage — a
        flurry, not a multiplier."""
        stats = self.player_state.derived_stats
        half_arc = math.radians(attack.half_arc_degrees)
        weapon = self.sword_surf if attack.style == 'slash' else self.dagger_surf
        damage = stats.attack_damage * attack.damage_multiplier / attack.swings

        # Once per attack however many strokes it is made of: two
        # notifications would let a boss react twice to one press.
        self.notify_enemies_of_attack(False)
        # For as long as any of those strokes is travelling, the body
        # must not also be holding the weapon (see _player_surface).
        # Extended, never assigned: the flagellant can attack out of his
        # own parry window, and an assignment there would cut short a
        # window the parry had already opened and hand him back a knife
        # that is still in the air.
        self.swing_until = max(self.swing_until,
                               self.time_ms + SWING_MS
                               + SWING_INTERVAL_MS * (attack.swings - 1))

        # Melee SFX: whoosh on the stroke, impact only if something
        # connects. Knight slash → Swing + Sword; thief stab → Swing + Knife.
        if attack.style == 'slash':
            sound, hit_sound = 'swing', 'sword'
        elif attack.style == 'stab':
            sound, hit_sound = 'swing', 'knife'
        else:
            sound, hit_sound = None, None
        for i in range(attack.swings):
            # Alternating the direction is what makes a pair read as a
            # flurry rather than one swing played twice — the second comes
            # back the way the first went. WeaponSweep takes a signed
            # half-arc, so a negative one runs the sweep in reverse.
            arc = half_arc if i % 2 == 0 else -half_arc
            self._swing(i * SWING_INTERVAL_MS, weapon, angle, arc,
                        attack.range, damage, sound=sound,
                        hit_sound=hit_sound)

    def _swing(self, delay_ms, weapon, angle, half_arc, reach, damage,
               sound=None, hit_sound=None):
        """One stroke: the weapon through the arc, its trail on the
        ground, and the damage landing mid-swing rather than on the button
        press — which is what gives an enemy's reactive dodge a real
        window to escape into."""
        def play():
            # Claim the body for this stroke's own full duration. The
            # window melee_attack reserved is a lower bound: a delayed
            # stroke starts on the first frame *past* its delay, so it
            # ends up to a frame later than planned, and for that frame
            # the body would be holding a knife that is also in the air.
            self.swing_until = max(self.swing_until, self.time_ms + SWING_MS)
            if sound:
                sfx.play(sound)
            self.add_effect(WeaponSweep(self.player_pos, weapon, angle,
                                        half_arc, grip_radius=12,
                                        duration_ms=SWING_MS,
                                        lift=PLAYER_HAND_LIFT))
            self.add_effect(ArcTrail(self.player_x, self.player_y, reach,
                                     angle, abs(half_arc), 0xFFFFFF, 0.2, 220))
            self.schedule(0.09 * SECOND,
                          lambda: self._land_hits(angle, abs(half_arc),
                                                  reach, damage,
                                                  hit_sound=hit_sound))

        if delay_ms <= 0:
            play()          # the first stroke lands this frame, not the next
        else:
            self.schedule(delay_ms, play)

    def _land_hits(self, angle, half_arc, reach, damage, hit_sound=None):
        connected = False
        for enemy in self.enemies:
            if enemy.dead:
                continue
            d = dist(self.player_x, self.player_y, enemy.x, enemy.y)
            to_enemy = angle_between(self.player_x, self.player_y, enemy.x, enemy.y)
            in_arc = abs(wrap_angle(to_enemy - angle)) <= half_arc
            if d <= reach + 16 and in_arc:
                self.apply_hit(enemy, damage)
                connected = True
        if connected and hit_sound:
            sfx.play(hit_sound)

    def notify_enemies_of_attack(self, ranged):
        """Let enemies react (dodge) the moment an attack starts."""
        for boss in self.enemies:
            boss.on_player_attack(self.player_x, self.player_y, ranged)

    def apply_hit(self, enemy, damage):
        died = enemy.take_damage(damage)
        if died:
            self.boss_index += 1  # advance the boss rush
            levels = self.player_state.gain_xp(enemy.xp_reward)
            if levels > 0:
                self.show_floating_text('LEVEL UP!', 0xF1C40F)

    def cast_fireball(self, angle, damage, attack_range):
        """The fire leaves the staff head, not the middle of his chest.
        The ember is drawn burning up there in every view of him, so a
        spell starting anywhere else would make the art a liar — and
        because the head sits off to one side, his shots come from where
        he is holding the thing rather than from his centre line."""
        sfx.play('fire_spell')
        self.notify_enemies_of_attack(True)
        x, y = self._staff_tip()
        self.projectiles.append(_Projectile(x, y, angle, damage, attack_range))

    def _staff_tip(self):
        """Where the staff's head is on the plane. It rides the far arm —
        a quarter turn off his heading, the opposite side from the
        knight's shield — which is exactly where all five views draw it,
        so this sweeps round with him as he turns.

        Exact facing toward or away from the camera, and a few pixels out
        in profile: a body seen edge-on draws its far arm at its own
        centre rather than at the depth it really occupies, so no world
        offset can agree with the art from every angle. The error is a
        third of a sprite width for one frame of a projectile that
        crosses that much every two — it is the side the art can afford
        to be wrong on."""
        away = self.facing_angle - math.pi / 2
        return (self.player_x + math.cos(away) * STAFF_TIP_REACH,
                self.player_y + math.sin(away) * STAFF_TIP_REACH)

    def _update_projectiles(self, dt_ms):
        dt = dt_ms / 1000
        for proj in self.projectiles:
            proj.x += proj.vx * dt
            proj.y += proj.vy * dt
            proj.traveled += FIREBALL_SPEED * dt

            for enemy in self.enemies:
                if enemy.dead or dist(proj.x, proj.y, enemy.x, enemy.y) > enemy.radius + 8:
                    continue
                self.apply_hit(enemy, proj.damage)
                self.add_effect(Explosion(proj.x, proj.y, 0.5625 * UNIT, lift=FIREBALL_LIFT))
                sfx.play('fire_hit')
                proj.active = False
                break

            # Fizzle out at max range if it hasn't hit anything.
            if proj.active and proj.traveled >= proj.max_dist:
                self.add_effect(Explosion(proj.x, proj.y, 0.25 * UNIT, lift=FIREBALL_LIFT))
                proj.active = False
        self.projectiles = [p for p in self.projectiles if p.active]

    def damage_player(self, amount, source=None):
        """Shared damage path for all enemy attacks: i-frames, the guard,
        then the hit cooldown. `source` is the boss that landed the blow,
        which is what lets a directional guard ask where it came from and
        a parry stagger whoever threw it. Returns True if the damage was
        actually applied."""
        if self.is_player_dodging:
            return False  # rolled through it — i-frames
        if self.time_ms - self.last_contact_damage_ms < CONTACT_DAMAGE_COOLDOWN_MS:
            return False
        if self.is_player_guarding and self._guard_stops(source):
            # The blow still landed, on the guard — so it spends the hit
            # window like any other. Without that, a boss standing in
            # contact would strike sparks off the shield every frame.
            self.last_contact_damage_ms = self.time_ms
            return False
        self.last_contact_damage_ms = self.time_ms

        died = self.player_state.take_damage(amount)

        self.hit_flash_until = self.time_ms + 0.1 * SECOND
        self.shake_until = self.time_ms + 0.08 * SECOND

        if died:
            self.respawn()
        return True

    def freeze_player(self, duration_ms):
        """Freeze the player in place: no moving, dodging, or attacking."""
        self.frozen_until = self.time_ms + duration_ms
        self.show_floating_text('Frozen!', 0x99DDFF)

    def respawn(self):
        self.add_effect(FloatingText(self.player_x, self.player_y - 1.25 * UNIT,
                                     'YOU DIED', 24, 0xE74C3C,
                                     duration_ms=1.5 * SECOND))
        # Diablo-style softcore death: respawn at the center, fully
        # restored, keeping XP and level.
        self.player_state.restore()
        # Whatever was up died with the body — including the ward, which
        # otherwise follows the new one around still glowing, and the
        # shield, which should not be seen lowering onto a fresh one.
        self.guard_until = -math.inf
        self.guard_held = False
        self.effects = [e for e in self.effects if not isinstance(e, Barrier)]
        self.player_x, self.player_y = WORLD_W / 2, WORLD_H / 2
        # The view goes with him rather than panning back across the map:
        # he is not in control for that moment, which is exactly when a
        # camera must not be seen travelling.
        camera.snap_to(self.player_x, self.player_y)
        # Face the camera again on the spot — spinning back into view
        # would read as a move the player didn't make.
        self.facing_angle = math.pi / 2
        self.player_turner.face_now(self.facing_angle)

    def show_floating_text(self, message, color):
        self.add_effect(FloatingText(self.player_x, self.player_y - 1.25 * UNIT,
                                     message, 20, color))

    def spawn_boss(self):
        x, y = self._spawn_point()

        # The boss-rush roster, fought in order and then looped.
        roster = [
            lambda: DevilBoss(self, x, y),
            lambda: IceDragonBoss(self, x, y),
        ]
        boss = roster[self.boss_index % len(roster)]()
        self.enemies.append(boss)

        if self.god_mode:
            boss.override_health(1)

        self.add_effect(BossAnnounce(boss.display_name))

    def _spawn_point(self):
        """Somewhere on BOSS_SPAWN_RING around the player, inside the
        world. The fight comes to whoever is having it: a fixed list of
        arena coordinates was fine when the arena was the screen, but on
        a map this size it would as often as not put the next boss
        somewhere the player has to go and find."""
        margin = 2 * UNIT
        for _ in range(10):
            angle = random.uniform(0, TURN)
            d = random.uniform(*BOSS_SPAWN_RING)
            x = self.player_x + math.cos(angle) * d
            y = self.player_y + math.sin(angle) * d
            if (margin <= x <= WORLD_W - margin
                    and margin <= y <= WORLD_H - margin):
                return x, y
        # Backed into a corner with every roll landing outside the world:
        # come in from the middle of it, which is inside the world from
        # anywhere in it.
        angle = angle_between(self.player_x, self.player_y,
                              WORLD_W / 2, WORLD_H / 2)
        d = BOSS_SPAWN_RING[1]
        return (self.player_x + math.cos(angle) * d,
                self.player_y + math.sin(angle) * d)

    # --- drawing ----------------------------------------------------------

    @staticmethod
    def _create_floor_patch():
        """One tile of the ground plane's repeating pattern — the diamond
        tiling in the camera's ratio, with the forest floor strewn over
        it — big enough to cover the screen on its own.

        The whole arena used to be baked into a single screen-sized
        surface, because the camera never moved. It moves now and the
        world is well past two screens across, so what is baked is the
        smallest thing that repeats and the view scrolls across a grid of
        it (see _draw_floor).

        It is drawn as the *infinite* pattern and cropped: the patch is a
        whole number of periods each way, so a diamond clipped off the
        right edge has an identical twin arriving at the left and the
        seam closes. Everything scattered on top has to keep that
        promise itself, which is what `_wrapped` is for."""
        patch = pygame.Surface((FLOOR_PATCH_W, FLOOR_PATCH_H))
        patch.fill(rgb(ARENA_DARK))

        tw, th = int(FLOOR_TILE_W), FLOOR_TILE_H
        hw, hh = tw // 2, th // 2
        for j in range(-1, FLOOR_PATCH_H // hh + 2):
            cy = j * hh
            for i in range(-1, FLOOR_PATCH_W // tw + 2):
                cx = i * tw + (hw if j % 2 else 0)
                points = [(cx, cy - hh), (cx + hw, cy), (cx, cy + hh), (cx - hw, cy)]
                color = ARENA_LIGHT if (i + j) % 2 == 0 else ARENA_DARK
                pygame.draw.polygon(patch, rgb(color), points)
                pygame.draw.polygon(patch, rgb(ARENA_SEAM), points, 1)
        GameScene._sow_litter(patch)
        return patch

    @staticmethod
    def _sow_litter(patch):
        """Moss, roots, dead leaves and stones over the tiling — this is
        what turns a floor into ground.

        Drawn with shapes rather than per-pixel noise, and not because it
        is prettier: this patch is over a megapixel, and a Python loop
        that visited every pixel of it would be felt on every entry to
        the scene and would stall the pygbag boot outright. A few hundred
        ellipses and specks cost milliseconds.

        Everything lies *on* the plane, so every round thing is drawn as
        an ellipse at the camera's own ratio. A circular moss patch would
        stand up out of the ground like a coin balanced on its edge — the
        same reason ArcTrail and every ground decal are flattened."""
        rng = random.Random(FLOOR_LITTER_SEED)
        w, h = FLOOR_PATCH_W, FLOOR_PATCH_H

        def blob(x, y, rx, color, alpha):
            """A soft round patch on the ground, built once per size and
            blitted wherever it is needed — including its wrapped twins,
            so nothing is ever clipped by the edge of the patch."""
            ry = max(1, round(rx * CAMERA_TILT))
            surf = pygame.Surface((rx * 2, ry * 2), pygame.SRCALPHA)
            steps = max(3, rx // 6)
            for i in range(steps, 0, -1):
                t = i / steps
                pygame.draw.ellipse(
                    surf, rgb(color) + (int(alpha * (1 - t) ** 1.6 + alpha * 0.25),),
                    (round(rx * (1 - t)), round(ry * (1 - t)),
                     round(rx * 2 * t), round(ry * 2 * t)))
            for px, py in _wrapped(x, y, rx, w, h):
                patch.blit(surf, (px - rx, py - ry), special_flags=platform.ALPHA_BLIT)

        def speck(x, y, length, color):
            for px, py in _wrapped(x, y, length + 1, w, h):
                patch.fill(rgb(color), (px, py, length, 1))

        # The shade of a canopy nobody drew, first and largest: broad
        # soft darkenings that break the tiling up before anything else
        # goes down. Without them the ground is evenly lit everywhere,
        # which no forest floor is.
        for _ in range(26):
            blob(rng.randrange(w), rng.randrange(h),
                 rng.randint(70, 190), FLOOR_DAPPLE, rng.randint(60, 120))
        # Moss, in the damp of those hollows.
        for _ in range(120):
            blob(rng.randrange(w), rng.randrange(h), rng.randint(9, 30),
                 FLOOR_MOSS_LIT if rng.random() < 0.3 else FLOOR_MOSS,
                 rng.randint(40, 105))
        # Roots crawling over the surface, and the twigs they shed. They
        # run mostly across rather than up and down the screen: the depth
        # axis is foreshortened, so a root lying north-south covers less
        # ground on screen than the same root lying east-west.
        for _ in range(260):
            x, y = rng.randrange(w), rng.randrange(h)
            run = rng.randint(6, 30)
            drop = rng.choice((-1, 0, 0, 1))
            for i in range(run):
                speck(x + i, y + (i * drop) // 4, 1,
                      FLOOR_ROOT if rng.random() < 0.75 else FLOOR_LEAF)
        # Leaf litter and grit, the fine texture underfoot. Two thirds of
        # it is a single pixel — at 1x that is exactly what a dead leaf
        # on the ground is.
        for _ in range(4200):
            speck(rng.randrange(w), rng.randrange(h), rng.choice((1, 1, 2)),
                  FLOOR_LEAF_DEAD if rng.random() < 0.25 else FLOOR_LEAF)
        for _ in range(900):
            speck(rng.randrange(w), rng.randrange(h), 1, FLOOR_STONE)

    def _draw_floor(self, target):
        """The ground under everything, wherever the view is looking. The
        patch tiles, so the floor is it laid out on a grid anchored to
        the scroll itself — at most two by two of them, since the patch
        is at least a screen across."""
        ox, oy = camera.scroll()
        y = -(oy % FLOOR_PATCH_H)
        while y < HEIGHT:
            x = -(ox % FLOOR_PATCH_W)
            while x < WIDTH:
                target.blit(self.floor, (x, y))
                x += FLOOR_PATCH_W
            y += FLOOR_PATCH_H
        self._dim_out_of_bounds(target)
        # The vignette is fixed to the *frame*, not to the ground, so it
        # goes on after the floor has been laid rather than into it.
        target.blit(self.vignette, (0, 0), special_flags=pygame.BLEND_RGB_MULT)

    @staticmethod
    def _dim_out_of_bounds(target):
        """Dim everything the player can't walk on, so the arena edge is
        legible without drawing a wall.

        Four bands around the arena's footprint rather than one masked
        overlay: that footprint slides around the screen now, and up to
        four rect fills is cheaper than rebuilding a screen-sized mask
        every frame — most of the time the arena covers the frame and
        every band is empty."""
        arena = camera.screen_bounds().clip(target.get_rect())
        if not arena.width or not arena.height:
            target.fill(ARENA_OOB_MULT, None, pygame.BLEND_RGB_MULT)
            return
        for band in (pygame.Rect(0, 0, WIDTH, arena.top),
                     pygame.Rect(0, arena.bottom, WIDTH, HEIGHT - arena.bottom),
                     pygame.Rect(0, arena.top, arena.left, arena.height),
                     pygame.Rect(arena.right, arena.top,
                                 WIDTH - arena.right, arena.height)):
            if band.width > 0 and band.height > 0:
                target.fill(ARENA_OOB_MULT, band, pygame.BLEND_RGB_MULT)

    @staticmethod
    def _vignette():
        """Radial edge darkening, as a multiply map: each pixel is what
        the floor under it gets scaled by. Black at alpha `a` over the
        floor and a multiply by 255 - a are the same arithmetic, and this
        is blitted every frame now that the floor beneath it moves —
        one blend pass beats a per-pixel alpha composite.

        Computed tiny and smooth-scaled up: a per-pixel pass at full res
        would stall the pygbag boot."""
        sw, sh = 160, 90
        small = pygame.Surface((sw, sh))
        cx, cy = sw / 2, sh / 2
        far = math.hypot(cx, cy)
        for y in range(sh):
            for x in range(sw):
                t = math.hypot(x - cx, y - cy) / far
                # Reaches further in and darker than it did over the old
                # arena floor: under a canopy the light does not so much
                # fall off at the edge of the frame as never arrive
                # there. Held short of crushing the corners to black —
                # the treeline still has to be legible in them.
                a = int(175 * max(0.0, t - 0.40) ** 1.5)
                v = 255 - min(190, a)
                small.set_at((x, y), (v, v, v))
        return platform.smoothscale(small, (WIDTH, HEIGHT))

    def _player_surface(self, shield_out=False):
        # A class that carries its gear in its art hands a piece of it
        # over to the scene while that piece is being moved: the sword
        # mid-swing, the shield while the guard is up. The body it drops
        # to is missing exactly that one thing, so nothing is ever drawn
        # twice — and the two states cannot overlap (try_attack refuses
        # while bracing, try_guard refuses mid-swing, and a swing sends
        # the shield straight back to his arm), so it is never missing
        # both.
        views = None
        if self.player_swing_views and self.time_ms < self.swing_until:
            views = self.player_swing_views
        elif self.player_guard_views and shield_out:
            views = self.player_guard_views
        surf = self.player_turner.surface(views)
        if self.time_ms < self.hit_flash_until:
            surf = tint_fill(surf, 0xFF5544)
        elif self.is_player_frozen:
            surf = tint_mult(surf, 0x99DDFF)
        # The turn squash and the walk's lean go on after the tints
        # (whose caches key off stable surface ids) and before the alpha
        # copy, which has to be the last thing that touches the surface —
        # it makes a fresh surface every frame, and nothing cached may be
        # keyed off one of those.
        surf = squash_x(surf, self.player_turner.squash)
        surf = tilted(surf, self.walk_tilt)
        if self.is_player_dodging:
            surf = surf.copy()
            surf.set_alpha(128)  # ghosting = i-frames
        return surf

    def _draw_player(self, target):
        # The raised shield is held out in front of the body, so when he
        # faces away from the camera it belongs *behind* him — the same
        # back-to-front rule the scene sorts bodies by.
        shield = self._shield_placement()
        # One test decides both halves of "he is holding it away from
        # us": the shield goes behind the body, and shows its boards
        # rather than its painted face.
        facing_away = math.sin(self.facing_angle) < 0
        if shield and facing_away:
            self._draw_shield(target, shield, facing_away)
        camera.blit_body(target, self._player_surface(shield is not None),
                         self.player_x, self.player_y, self.walk_bob,
                         leaning=bool(self.walk_tilt))
        if shield and not facing_away:
            self._draw_shield(target, shield, facing_away)

    def _shield_placement(self):
        """Where the shield is this frame — (x, y, lift) — or None while
        it is back on his arm and the body art is drawing it.

        It travels: from hanging on his near arm up and across to arm's
        length at chest height, and back down again when the guard ends.
        Both ends of that journey are real places — the near-arm end is
        exactly where the body art carries it — so the shield the scene
        moves and the shield in his art are visibly the same object
        rather than one fading in as the other fades out."""
        if self.player_state.character_class.guard.style != 'shield':
            return None
        if self.time_ms < self.swing_until:
            # A swing owns the body: the shield is back on his arm, in
            # the art, and the sword is the thing being moved.
            return None

        since_end = self.time_ms - self.guard_until
        if since_end >= SHIELD_RAISE_MS:
            return None
        # Eased on the way *travelled*, in whichever direction it is
        # going — easing the height instead would leave the shield
        # hanging at full stretch for the first third of coming down.
        if since_end >= 0:
            raised = 1 - ease_out_cubic(since_end / SHIELD_RAISE_MS)
        else:
            raised = ease_out_cubic(
                min(1.0, (self.time_ms - self.guard_started_ms) / SHIELD_RAISE_MS))

        # Rest is a quarter turn off his heading (his near arm); raised is
        # straight out in front. Lerping between the two swings it across
        # the body, which is what an arm actually does.
        rest = self.facing_angle + math.pi / 2
        rest_x = self.player_x + math.cos(rest) * SHIELD_REST_REACH
        rest_y = self.player_y + math.sin(rest) * SHIELD_REST_REACH
        up_x = self.player_x + math.cos(self.facing_angle) * SHIELD_OFFSET
        up_y = self.player_y + math.sin(self.facing_angle) * SHIELD_OFFSET
        x = rest_x + (up_x - rest_x) * raised
        y = rest_y + (up_y - rest_y) * raised
        lift = SHIELD_REST_LIFT + (PLAYER_HAND_LIFT - SHIELD_REST_LIFT) * raised
        # Rides the bounce with him — a shield that stayed put while the
        # body under it bobbed would read as hanging in the air.
        lift += self.walk_bob
        if 0 <= self.guard_until - self.time_ms < GUARD_FATIGUE_MS:
            x += random.randint(-1, 1)  # the arm going, just before it breaks
        return x, y, lift

    def _draw_shield(self, target, placement, facing_away):
        # Never rotated: a shield face is turned toward what it stops,
        # not pointed along an angle like a sword, and its light has to
        # keep coming from the upper left in every direction he faces.
        # It turns by swapping face for boards instead.
        x, y, lift = placement
        surf = self.shield_back_surf if facing_away else self.shield_surf
        camera.blit_flat(target, surf, x, y, lift)

    def _draw_guard_arc(self, target):
        """The stance, painted on the floor in front of him.

        The knight carries a shield in his art at all times now, so a
        shield being *there* can no longer mean "blocking" — the raised
        guard has to read as something else. A lit sector is the honest
        choice: it says exactly which blows this stance stops, in the
        same ground-decal language the breath cones and swing arcs
        already speak."""
        if not self.is_player_bracing:
            return
        guard = self.player_state.character_class.guard
        surf = _guard_arc_surface(math.radians(guard.half_arc_degrees),
                                  self.facing_angle, GUARD_COLORS['shield'])
        alpha = 0.24
        if self.guard_until - self.time_ms < GUARD_FATIGUE_MS:
            # The arm going: the sector stutters before the guard breaks.
            alpha = 0.24 if int(self.time_ms / 70) % 2 else 0.08
        surf.set_alpha(int(255 * alpha))
        camera.blit_flat(target, surf, self.player_x, self.player_y)

    def _draw_projectile(self, proj):
        # Fireballs fly at chest height rather than skidding along the floor.
        return lambda target: camera.blit_flat(target, self.fireball_surf,
                                               proj.x, proj.y, FIREBALL_LIFT)

    def draw(self, screen):
        world = self.world
        self._draw_floor(world)
        props = self._visible_props()

        # Ground decals first: swing arcs, breath cones and the block's
        # covered sector are painted ON the plane, so bodies stand in
        # them rather than on top of them.
        for effect in self.effects:
            if effect.ground:
                effect.draw(world)
        self._draw_guard_arc(world)

        camera.blit_shadow(world, self.player_x, self.player_y, PLAYER_RADIUS * 0.85)
        for boss in self.enemies:
            boss.draw_shadow(world)
        for view in props:
            camera.blit_shadow(world, view.x, view.y, view.shadow,
                               PROP_SHADOW_ALPHA)

        # Painter's algorithm down the camera's depth axis: whoever is
        # further "into" the screen is drawn first and gets overlapped.
        # The scenery sorts into exactly the same list, which is the
        # whole of what makes the forest something bodies walk *among*
        # rather than a backdrop painted behind them.
        bodies = self._body_rects()
        order = [(self.player_y, self._draw_player)]
        order += [(boss.y, boss.draw) for boss in self.enemies]
        order += [(p.y, self._draw_projectile(p)) for p in self.projectiles]
        order += [(view.y, lambda target, v=view: self._draw_prop(target, v, bodies))
                  for view in props]
        order.sort(key=lambda item: item[0])
        for _, draw_fn in order:
            draw_fn(world)

        for effect in self.effects:
            if not effect.ground:
                effect.draw(world)

        # Camera shake on taking damage.
        ox = oy = 0
        if self.time_ms < self.shake_until:
            ox = random.randint(-3, 3)      # screen px; shake is a screen effect
            oy = random.randint(-3, 3)
        screen.fill((0, 0, 0))
        screen.blit(world, (ox, oy))

        draw_hud(screen, self.player_state)
