"""The flagellant (the "thief" class) and his misericordes.

A heavy sackcloth cowl over a face that never resolves, and a
bandaged chest with the blood already soaking through — the one who
takes his penance quietly and moves fast.

**He carries a knife in each hand in every view.** The five bare maps
below are kept as `THIEF_SWING_VIEWS`: he drops to them for the length of
an attack, because that is exactly when the scene has both knives out
sweeping the arc, one after the other. Naming them for the swing rather
than duplicating them is deliberate — the knives are the only difference
between the two sets, so there is nothing to keep in step.
"""

from ..facing import DirectionalSprite
from ..pixelart import PixelSprite
from .palette import (BONE, BONE_DEEP, CRIMSON, CRIMSON_DEEP, HOLLOW, SEPIA,
                      SEPIA_DEEP, SEPIA_LIT, SEPIA_MID, VOID)

# 32x32 flagellant, front view: a heavy sackcloth cowl drooping over a
# face that never resolves, a ragged shoulder cape, and a bandaged
# chest with the blood already soaking through. The "thief" — the one
# who takes penance quietly and moves fast.
THIEF_PALETTE = {
    'd': VOID,          # outline
    'H': SEPIA,         # sackcloth
    'm': SEPIA_MID,     # sackcloth falloff
    'h': SEPIA_DEEP,    # sackcloth shade
    'l': SEPIA_LIT,     # sackcloth rim light
    'K': HOLLOW,        # under the cowl
    'E': BONE_DEEP,     # the dull glint of eyes that don't catch light
    'B': 0xA89878,      # bandages — dirty linen, not fresh
    'b': 0x7A6C52,      # bandage shade / rope belt
    'R': CRIMSON,       # blood soaking through
    'p': 0x14100A,      # deepest hem shadow
    # The knives he carries, in the misericorde's own tones so the
    # pair in his hands and the one the scene swings are one weapon.
    'X': 0xE8DEC2,      # bone edge
    'S': 0x8E8574,      # rusted blade
    's': 0x4A443A,      # blade shade
    'G': 0xC4B394,      # bone guard
}

THIEF_SWING_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '.............dhhhhd.............',
        '...........dhHHHHHHhd...........',
        '.........dlHHHHHHHmmmhd.........',
        '.......dlHHHHHHHHHHmmmhhd.......',
        '......dlHHHHHHHHHHHmmmmhhd......',
        '.....dlHHHHKKKKKKKKKKmmmhhd.....',
        '.....dlHHHKKKKKKKKKKKKmmhhd.....',
        '....dlHHKKKKKKKKKKKKKKKKmmhhd...',
        '....dlHHKKKEEKKKKKKEEKKKmmhhd...',
        '....dlHHKKKKKKKKKKKKKKKKmmhhd...',
        '....dlHHHKKKKKKKKKKKKKKmmmhhd...',
        '....dlHHHHHKKKKKKKKKKmmmmhhd....',
        '....dlHHHHHHHKKKKKKmmmmmmhhd....',
        '....dlHHHHHHHHHHHHmmmmmmmhhd....',
        '.....dlHHHHHHHHHHHmmmmmmhhd.....',
        '..dlHHHHHHHHHHHHHmmmmmmmmmhhhd..',
        '.dlHHHHHHHHHHHHHHmmmmmmmmmmhhhd.',
        '.dlHHHhHHHHhHHHmmmhmmmmhmmmhhhd.',
        '.dhhhhhhhhhhhhhhhhhhhhhhhhhhhhd.',
        '.....dlBBBBBBBBBBBBBBBBBBhd.....',
        '.....dlbbBBbbBBRRBBbbBBbbhd.....',
        '.....dlbbbbbbbbbbbbbbbbbbhd.....',
        '.....dlHHHHHHHHHHHmmmmmmhhd.....',
        '....dlHHHHHHHHHHHHmmmmmmmhhd....',
        '....dlHhHHHHHHHHhmmmmmmmmhhd....',
        '...dlHhHHHHHHHHHhmmmmmmmmhhhd...',
        '...dlHhHHHHHHHHHhmmmmmmmmhhhd...',
        '...dhhhhhhhhhhhhhhhhhhhhhhhhd...',
        '....dhHhd..dhHhd..dhmhd.dhhd....',
        '.....dhd....dhd....dhd..dhd.....',
        '.....dpd.....dpd....dpd.........',
    ),
)

# Back: the cowl closes into unbroken sackcloth with one seam down it,
# and the bandages that read as a wound dressing from the front read as
# a scourged back from here — the crimson runs in lash diagonals rather
# than a single soak. This is the flagellant's whole point.
THIEF_SWING_BACK_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '.............dhhhhd.............',
        '...........dhHHHHHHhd...........',
        '.........dlHHHHHHHmmmhd.........',
        '.......dlHHHHHHHHHHmmmhhd.......',
        '......dlHHHHHHHHHHHmmmmhhd......',
        '.....dlHHHHHHHHHHHHHHmmmhhd.....',
        '.....dlHHHHHHHHHHHHHHHmmhhd.....',
        '....dlHHHHHHHHHHHHHHHHHHmmhhd...',
        '....dlHHHHHHHHHhHHHHHHHHmmhhd...',
        '....dlHHHHHHHHHhHHHHHHHHmmhhd...',
        '....dlHHHHHHHHHhHHHHHHHmmmhhd...',
        '....dlHHHHHHHHHhHHHHHmmmmhhd....',
        '....dlHHHHHHHhHHHHHmmmmmmhhd....',
        '....dlHHHHHHHhHHHHmmmmmmmhhd....',
        '.....dlHHHHHhHHHHHmmmmmmhhd.....',
        '..dlHHHHHHHHHHHHHmmmmmmmmmhhhd..',
        '.dlHHHHHHHHHHHHHHmmmmmmmmmmhhhd.',
        '.dlHHHhHHHHhHHHmmmhmmmmhmmmhhhd.',
        '.dhhhhhhhhhhhhhhhhhhhhhhhhhhhhd.',
        '.....dlBBBRBBBBBBBBBRBBBBhd.....',
        '.....dlbbBBRbbBBbbBBbRBbbhd.....',
        '.....dlbbbbbRbbbbbbbbbRbbhd.....',
        '.....dlHHHHHHHHbbHmmmmmmhhd.....',
        '....dlHHHHHHHHHHHHmmmmmmmhhd....',
        '....dlHhHHHHHHHHhmmmmmmmmhhd....',
        '...dlHhHHHHHHHHHhmmmmmmmmhhhd...',
        '...dlHhHHHHHHHHHhmmmmmmmmhhhd...',
        '...dhhhhhhhhhhhhhhhhhhhhhhhhd...',
        '....dhHhd..dhHhd..dhmhd.dhhd....',
        '.....dhd....dhd....dhd..dhd.....',
        '.....dpd.....dpd....dpd.........',
    ),
)

# Side: the cowl's droop becomes a hooked profile with the hollow opening
# forward, and the shoulder cape trails behind the leading shoulder. The
# blood on the bandages sits at the front, where the wound is.
THIEF_SWING_SIDE_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '..............dhhhd.............',
        '............dhHHHHHhd...........',
        '..........dlHHHHHHHmhd..........',
        '.........dlHHHHHHHHHmhhd........',
        '........dlHHHHHHHHHHHmhhd.......',
        '........dlHHHHHHHKKKKKKKd.......',
        '........dlHHHHHHKKKKKKKKd.......',
        '........dlHHHHHKKKKKKKKKd.......',
        '........dlHHHHHKKKEEKKKKd.......',
        '........dlHHHHHKKKKKKKKKd.......',
        '........dlHHHHHHKKKKKKKKd.......',
        '........dlHHHHHHHKKKKKKKd.......',
        '........dlHHHHHHHHHKKKKKd.......',
        '........dlHHHHHHHHHHHmmmhd......',
        '........dlHHHHHHHHHmmmmmhd......',
        '.....dlHHHHHHHHHHHHHmmmmmhhd....',
        '....dlHHHHHHHHHHHHHmmmmmmhhd....',
        '....dlHHhHHHHHhHHHmmmhmmmmhd....',
        '....dhhhhhhhhhhhhhhhhhhhhhhd....',
        '......dlBBBBBBBBBBBBBBBBhd......',
        '......dlbbBBbbBBBBRRBBbbhd......',
        '......dlbbbbbbbbbbbbbbbbhd......',
        '......dlHHHHHHHHHHmmmmmmhd......',
        '.....dlHHHHHHHHHHHHmmmmmmhd.....',
        '.....dlHhHHHHHHHHHmmmmmmhhd.....',
        '.....dlHhHHHHHHHHHmmmmmmhhd.....',
        '.....dlHhHHHHHHHHHmmmmmmhhd.....',
        '.....dhhhhhhhhhhhhhhhhhhhhd.....',
        '......dhHhd.....dhmhd...........',
        '.......dhd.......dhd............',
        '.......dpd.......dpd............',
    ),
)

# Three-quarters toward the camera: the cowl's mouth swings round so the
# trailing eye is a single dull pixel, and the blood on the bandages
# drifts to the leading side with it.
THIEF_SWING_FRONT_SIDE_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '..............dhhhhd............',
        '............dhHHHHHHhd..........',
        '..........dlHHHHHHHmmmhd........',
        '........dlHHHHHHHHHHmmmhhd......',
        '.......dlHHHHHHHHHHHmmmmhhd.....',
        '......dlHHHHKKKKKKKKKmmmhhd.....',
        '......dlHHHKKKKKKKKKKKmmhhd.....',
        '.....dlHHKKKKKKKKKKKKKKmmhhd....',
        '.....dlHHKKEKKKKKKKEEKKmmhhd....',
        '.....dlHHKKKKKKKKKKKKKKmmhhd....',
        '.....dlHHHKKKKKKKKKKKKmmmhhd....',
        '.....dlHHHHHKKKKKKKKmmmmhhd.....',
        '.....dlHHHHHHHKKKKmmmmmmhhd.....',
        '.....dlHHHHHHHHHHHmmmmmmhhd.....',
        '......dlHHHHHHHHHmmmmmmhhd......',
        '...dlHHHHHHHHHHHHmmmmmmmmmhhd...',
        '..dlHHHHHHHHHHHHHmmmmmmmmmmhhd..',
        '..dlHHHhHHHHhHHmmmhmmmmhmmmhhd..',
        '..dhhhhhhhhhhhhhhhhhhhhhhhhhhd..',
        '......dlBBBBBBBBBBBBBBBBhd......',
        '......dlbbBBbbBBRRBBbbBBhd......',
        '......dlbbbbbbbbbbbbbbbbhd......',
        '......dlHHHHHHHHHmmmmmmmhd......',
        '.....dlHHHHHHHHHHHmmmmmmmhd.....',
        '.....dlHhHHHHHHHHmmmmmmmmhd.....',
        '....dlHhHHHHHHHHHmmmmmmmmhhd....',
        '....dlHhHHHHHHHHHmmmmmmmmhhd....',
        '....dhhhhhhhhhhhhhhhhhhhhhhd....',
        '.....dhHhd..dhHhd..dhmhd.dhhd...',
        '......dhd....dhd....dhd..dhd....',
        '......dpd.....dpd....dpd........',
    ),
)

# Three-quarters away: sackcloth closes over the cowl with the seam left
# of centre, and the lash diagonals run with it — the scourged back stays
# readable even at this angle, which is the whole reason it is there.
THIEF_SWING_BACK_SIDE_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '..............dhhhhd............',
        '............dhHHHHHHhd..........',
        '..........dlHHHHHHHmmmhd........',
        '........dlHHHHHHHHHHmmmhhd......',
        '.......dlHHHHHHHHHHHmmmmhhd.....',
        '......dlHHHHHHHHHHHHHmmmhhd.....',
        '......dlHHHHHHHHHHHHHHmmhhd.....',
        '.....dlHHHHHHHHHHHHHHHHmmhhd....',
        '.....dlHHHHHHHhHHHHHHHHmmhhd....',
        '.....dlHHHHHHHhHHHHHHHHmmhhd....',
        '.....dlHHHHHHHhHHHHHHHmmmhhd....',
        '.....dlHHHHHHhHHHHHHmmmmhhd.....',
        '.....dlHHHHHhHHHHHmmmmmmhhd.....',
        '.....dlHHHHhHHHHHHmmmmmmhhd.....',
        '......dlHHHhHHHHHmmmmmmhhd......',
        '...dlHHHHHHHHHHHHmmmmmmmmmhhd...',
        '..dlHHHHHHHHHHHHHmmmmmmmmmmhhd..',
        '..dlHHHhHHHHhHHmmmhmmmmhmmmhhd..',
        '..dhhhhhhhhhhhhhhhhhhhhhhhhhhd..',
        '......dlBBBRBBBBBBBBRBBBhd......',
        '......dlbbBBRbbBBbbBBRbbhd......',
        '......dlbbbbbRbbbbbbbbRbhd......',
        '......dlHHHHHHHbbmmmmmmmhd......',
        '.....dlHHHHHHHHHHHmmmmmmmhd.....',
        '.....dlHhHHHHHHHHmmmmmmmmhd.....',
        '....dlHhHHHHHHHHHmmmmmmmmhhd....',
        '....dlHhHHHHHHHHHmmmmmmmmhhd....',
        '....dhhhhhhhhhhhhhhhhhhhhhhd....',
        '.....dhHhd..dhHhd..dhmhd.dhhd...',
        '......dhd....dhd....dhd..dhd....',
        '......dpd.....dpd....dpd........',
    ),
)

# --- knives in hand ---------------------------------------------------
#
# The five views everyone sees: the bare maps above with a knife stamped
# into each hand. He drops back to the bare ones for the length of a
# swing, because that is when the scene is busy swinging the knives
# themselves — see CLASS_SWING_SPRITES.

# Front: a knife in each hand, held low and out to the sides where
# they break the sackcloth silhouette instead of disappearing into
# it. The crimson wrap under each guard is what separates blade
# from hand at 1x — without it the pair reads as two candles.
THIEF_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '.............dhhhhd.............',
        '...........dhHHHHHHhd...........',
        '.........dlHHHHHHHmmmhd.........',
        '.......dlHHHHHHHHHHmmmhhd.......',
        '......dlHHHHHHHHHHHmmmmhhd......',
        '.....dlHHHHKKKKKKKKKKmmmhhd.....',
        '.....dlHHHKKKKKKKKKKKKmmhhd.....',
        '....dlHHKKKKKKKKKKKKKKKKmmhhd...',
        '....dlHHKKKEEKKKKKKEEKKKmmhhd...',
        '....dlHHKKKKKKKKKKKKKKKKmmhhd...',
        '....dlHHHKKKKKKKKKKKKKKmmmhhd...',
        '...dXdHHHHHKKKKKKKKKKmmmmhhd....',
        '...dXdHHHHHHHKKKKKKmmmmmmhhdd...',
        '..dXSdHHHHHHHHHHHHmmmmmmmhhdXd..',
        '..dXSdlHHHHHHHHHHHmmmmmmhhddXd..',
        '..dXSdHHHHHHHHHHHmmmmmmmmmdXSd..',
        '.ddXsdHHHHHHHHHHHmmmmmmmmmdXSdd.',
        '.ddGGdhHHHHhHHHmmmhmmmmhmmdXSdd.',
        '.ddRRdhhhhhhhhhhhhhhhhhhhhdXsdd.',
        '..dhhdlBBBBBBBBBBBBBBBBBBhdGGd..',
        '...dddlbbBBbbBBRRBBbbBBbbhdRRd..',
        '.....dlbbbbbbbbbbbbbbbbbbhdhhd..',
        '.....dlHHHHHHHHHHHmmmmmmhhddd...',
        '....dlHHHHHHHHHHHHmmmmmmmhhd....',
        '....dlHhHHHHHHHHhmmmmmmmmhhd....',
        '...dlHhHHHHHHHHHhmmmmmmmmhhhd...',
        '...dlHhHHHHHHHHHhmmmmmmmmhhhd...',
        '...dhhhhhhhhhhhhhhhhhhhhhhhhd...',
        '....dhHhd..dhHhd..dhmhd.dhhd....',
        '.....dhd....dhd....dhd..dhd.....',
        '.....dpd.....dpd....dpd.........',
    ),
)

# Back: both knives have swapped sides with the turn.
THIEF_BACK_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '.............dhhhhd.............',
        '...........dhHHHHHHhd...........',
        '.........dlHHHHHHHmmmhd.........',
        '.......dlHHHHHHHHHHmmmhhd.......',
        '......dlHHHHHHHHHHHmmmmhhd......',
        '.....dlHHHHHHHHHHHHHHmmmhhd.....',
        '.....dlHHHHHHHHHHHHHHHmmhhd.....',
        '....dlHHHHHHHHHHHHHHHHHHmmhhd...',
        '....dlHHHHHHHHHhHHHHHHHHmmhhd...',
        '....dlHHHHHHHHHhHHHHHHHHmmhhd...',
        '....dlHHHHHHHHHhHHHHHHHmmmhhd...',
        '....dlHHHHHHHHHhHHHHHmmmmhhdXd..',
        '....dlHHHHHHHhHHHHHmmmmmmhhdXd..',
        '...dXdHHHHHHHhHHHHmmmmmmmhdXSd..',
        '...dXdlHHHHHhHHHHHmmmmmmhhdXSd..',
        '..dXSdHHHHHHHHHHHmmmmmmmmmdXSd..',
        '.ddXSdHHHHHHHHHHHmmmmmmmmmdXsdd.',
        '.ddXSdhHHHHhHHHmmmhmmmmhmmdGGdd.',
        '.ddXsdhhhhhhhhhhhhhhhhhhhhdRRdd.',
        '..dGGdlBBBRBBBBBBBBBRBBBBhdhhd..',
        '..dRRdlbbBBRbbBBbbBBbRBbbhddd...',
        '..dhhdlbbbbbRbbbbbbbbbRbbhd.....',
        '...dddlHHHHHHHHbbHmmmmmmhhd.....',
        '....dlHHHHHHHHHHHHmmmmmmmhhd....',
        '....dlHhHHHHHHHHhmmmmmmmmhhd....',
        '...dlHhHHHHHHHHHhmmmmmmmmhhhd...',
        '...dlHhHHHHHHHHHhmmmmmmmmhhhd...',
        '...dhhhhhhhhhhhhhhhhhhhhhhhhd...',
        '....dhHhd..dhHhd..dhmhd.dhhd....',
        '.....dhd....dhd....dhd..dhd.....',
        '.....dpd.....dpd....dpd.........',
    ),
)

# Side: the near knife crosses the torso and the far one clears his
# trailing shoulder — a pair reads from profile without either
# having to lead.
THIEF_SIDE_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '..............dhhhd.............',
        '............dhHHHHHhd...........',
        '..........dlHHHHHHHmhd..........',
        '.........dlHHHHHHHHHmhhd........',
        '........dlHHHHHHHHHHHmhhd.......',
        '........dlHHHHHHHKKKKKKKd.......',
        '........dlHHHHHHKKKKKKKKd.......',
        '........dlHHHHHKKKKKKKKKd.......',
        '........dlHHHHHKKKEEKKKKd.......',
        '........dlHHHHHKKKKKKKKKd.......',
        '........dlHHHHHHKKKKKKKKdd......',
        '........dlHHHHHHHKKKKKKKdd......',
        '........dlHHHHHHHHHKKKKKdd......',
        '........dlHHHHHHHHHHHmmmhd......',
        '........dlHdHHHHHHHmmmmmhd......',
        '.....dlHHHdXdHHHHHHHmmmmmhhd....',
        '....dlHHHHdXdHHHHHHmmmmmmhhd....',
        '....dlHHhdXSdHhHHHmmmhmmmmhd....',
        '....dhhhhdXSdhhhhhhhhhhhhhhd....',
        '......dlBdXSdBBBBBBBBBBBhd......',
        '......dlbdXsdbBBBBRRBBbbhd......',
        '......dlbdGGdbbbbbbbbbbbhd......',
        '......dlHdRRdHHHHHmmmmmmhd......',
        '.....dlHHdhhdHHHHHHmmmmmmhd.....',
        '.....dlHhHddHHHHHHmmmmmmhhd.....',
        '.....dlHhHHHHHHHHHmmmmmmhhd.....',
        '.....dlHhHHHHHHHHHmmmmmmhhd.....',
        '.....dhhhhhhhhhhhhhhhhhhhhd.....',
        '......dhHhd.....dhmhd...........',
        '.......dhd.......dhd............',
        '.......dpd.......dpd............',
    ),
)

# Three-quarters toward the camera: the near knife has come round
# with the body, the far one is starting to go behind it.
THIEF_FRONT_SIDE_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '..............dhhhhd............',
        '............dhHHHHHHhd..........',
        '..........dlHHHHHHHmmmhd........',
        '........dlHHHHHHHHHHmmmhhd......',
        '.......dlHHHHHHHHHHHmmmmhhd.....',
        '......dlHHHHKKKKKKKKKmmmhhd.....',
        '......dlHHHKKKKKKKKKKKmmhhd.....',
        '.....dlHHKKKKKKKKKKKKKKmmhhd....',
        '.....dlHHKKEKKKKKKKEEKKmmhhd....',
        '.....dlHHKKKKKKKKKKKKKKmmhhdd...',
        '.....dlHHHKKKKKKKKKKKKmmmhhdXd..',
        '....ddlHHHHHKKKKKKKKmmmmhhddXd..',
        '...dXdlHHHHHHHKKKKmmmmmmhhdXSd..',
        '...dXdlHHHHHHHHHHHmmmmmmhhdXSd..',
        '..dXSddlHHHHHHHHHmmmmmmhhddXSd..',
        '..dXSdHHHHHHHHHHHmmmmmmmmmhhdd..',
        '..dXSdHHHHHHHHHHHmmmmmmmmmmhhd..',
        '..dXsdHhHHHHhHHmmmhmmmmhmmmhhd..',
        '..dGGdhhhhhhhhhhhhhhhhhhhhhhhd..',
        '..dRRddlBBBBBBBBBBBBBBBBhd.dd...',
        '..dhhddlbbBBbbBBRRBBbbBBhd......',
        '...dd.dlbbbbbbbbbbbbbbbbhd......',
        '......dlHHHHHHHHHmmmmmmmhd......',
        '.....dlHHHHHHHHHHHmmmmmmmhd.....',
        '.....dlHhHHHHHHHHmmmmmmmmhd.....',
        '....dlHhHHHHHHHHHmmmmmmmmhhd....',
        '....dlHhHHHHHHHHHmmmmmmmmhhd....',
        '....dhhhhhhhhhhhhhhhhhhhhhhd....',
        '.....dhHhd..dhHhd..dhmhd.dhhd...',
        '......dhd....dhd....dhd..dhd....',
        '......dpd.....dpd....dpd........',
    ),
)

# Three-quarters away: the same pair, one step further round.
THIEF_BACK_SIDE_SPRITE = PixelSprite(
    palette=THIEF_PALETTE,
    rows=(
        '................................',
        '..............dhhhhd............',
        '............dhHHHHHHhd..........',
        '..........dlHHHHHHHmmmhd........',
        '........dlHHHHHHHHHHmmmhhd......',
        '.......dlHHHHHHHHHHHmmmmhhd.....',
        '......dlHHHHHHHHHHHHHmmmhhd.....',
        '......dlHHHHHHHHHHHHHHmmhhd.....',
        '.....dlHHHHHHHHHHHHHHHHmmhhd....',
        '.....dlHHHHHHHhHHHHHHHHmmhhd....',
        '....ddlHHHHHHHhHHHHHHHHmmhhd....',
        '...dXdlHHHHHHHhHHHHHHHmmmhhd....',
        '...dXdlHHHHHHhHHHHHHmmmmhhd.d...',
        '..dXSdlHHHHHhHHHHHmmmmmmhhddXd..',
        '..dXSdlHHHHhHHHHHHmmmmmmhhddXd..',
        '..dXSddlHHHhHHHHHmmmmmmhhddXSd..',
        '..ddlHHHHHHHHHHHHmmmmmmmmmdXSd..',
        '..dlHHHHHHHHHHHHHmmmmmmmmmdXSd..',
        '..dlHHHhHHHHhHHmmmhmmmmhmmdXsd..',
        '..dhhhhhhhhhhhhhhhhhhhhhhhdGGd..',
        '...dd.dlBBBRBBBBBBBBRBBBhddRRd..',
        '......dlbbBBRbbBBbbBBRbbhddhhd..',
        '......dlbbbbbRbbbbbbbbRbhd.dd...',
        '......dlHHHHHHHbbmmmmmmmhd......',
        '.....dlHHHHHHHHHHHmmmmmmmhd.....',
        '.....dlHhHHHHHHHHmmmmmmmmhd.....',
        '....dlHhHHHHHHHHHmmmmmmmmhhd....',
        '....dlHhHHHHHHHHHmmmmmmmmhhd....',
        '....dhhhhhhhhhhhhhhhhhhhhhhd....',
        '.....dhHhd..dhHhd..dhmhd.dhhd...',
        '......dhd....dhd....dhd..dhd....',
        '......dpd.....dpd....dpd........',
    ),
)
THIEF_VIEWS = DirectionalSprite(front=THIEF_SPRITE, back=THIEF_BACK_SPRITE,
                                side=THIEF_SIDE_SPRITE,
                                front_side=THIEF_FRONT_SIDE_SPRITE,
                                back_side=THIEF_BACK_SIDE_SPRITE)

# Both hands empty, for the length of a double swing.
THIEF_SWING_VIEWS = DirectionalSprite(
    front=THIEF_SWING_SPRITE, back=THIEF_SWING_BACK_SPRITE,
    side=THIEF_SWING_SIDE_SPRITE,
    front_side=THIEF_SWING_FRONT_SIDE_SPRITE,
    back_side=THIEF_SWING_BACK_SIDE_SPRITE)

# 32x32 misericorde pointing straight up: a short rusted-iron blade
# with a bone edge, a plain bone guard, and a grip wrapped in crimson
# cloth. The flagellant's fast, short-reach weapon.
DAGGER_SPRITE = PixelSprite(
    palette={
        'X': 0xE8DEC2,      # bone edge
        'S': 0x8E8574,      # rusted blade
        's': 0x4A443A,      # blade shade
        'G': BONE,          # bone guard/pommel
        'g': BONE_DEEP,     # bone shade
        'B': CRIMSON_DEEP,  # crimson cloth wrap
        'b': 0x2A0A0D,      # wrap shadow
    },
    rows=(
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '...............X................',
        '..............XSs...............',
        '..............XSs...............',
        '..............XSss..............',
        '..............XSss..............',
        '..............XSss..............',
        '..............XSss..............',
        '..............XSss..............',
        '..............XSss..............',
        '..............XSss..............',
        '............GGGGGGGG............',
        '.............ggGGgg.............',
        '..............BBBb..............',
        '..............bBBB..............',
        '..............BBBb..............',
        '..............bBBB..............',
        '.............GGGGGG.............',
        '..............gGGg..............',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
    ),
)
