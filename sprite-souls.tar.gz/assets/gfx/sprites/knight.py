"""The penitent knight (the "knight" class), its sword and its shield.

A tall bone capirote — the pointed Holy Week hood — over a face of
pure shadow, a cloak parted on a bone tabard, and a crimson sash.

**He carries the sword and the shield in every view.** They are part of
the body maps rather than sprites the scene lays on top, so he is armed
standing still, walking, blocking and dying — which is what the separate
held-weapon sprites could never manage. Two things follow from that:

- The shield rides his NEAR arm, so as he turns away from the camera it
  sweeps across the body left -> centre -> right while the sword sweeps
  the other way. That sweep has to stay monotonic across the five maps
  or a turn makes them hop sides instead of swinging round.
- The three right-facing views are mirrored for their left-facing
  halves, so crossing straight toward or straight away from the camera
  swaps which hand holds what. That is the standing cost of eight views
  from five maps, and it is the same trade every mirrored sprite in this
  cast already makes.

A weapon painted into a body cannot also be somewhere else, so whenever
a piece of gear has to move, the body lets go of it for exactly that
long. Hence two more five-map sets below, each the armed body minus one
thing: KNIGHT_BLOCK_VIEWS (no shield) while SHIELD_SPRITE is held up in
front of him, and KNIGHT_SWING_VIEWS (no sword) while SWORD_SPRITE
sweeps the arc. The two states are mutually exclusive by design — he
cannot swing with the guard up — so no view is ever missing both.
"""

from ..facing import DirectionalSprite
from ..pixelart import PixelSprite
from .palette import (BONE, BONE_DEEP, BONE_LIT, BONE_SPEC, CRIMSON,
                      CRIMSON_DEEP, EMBER, GOLD, GOLD_DEEP, GOLD_SPEC, HOLLOW,
                      SEPIA, SEPIA_DEEP, VOID)

KNIGHT_PALETTE = {
    'd': VOID,          # outline
    'X': BONE_SPEC,     # capirote specular (lit from upper-left)
    'B': BONE_LIT,      # capirote bone
    'b': BONE,          # bone mid
    'n': BONE_DEEP,     # bone falloff on the shadowed side
    'K': HOLLOW,        # the void inside the hood
    'e': EMBER,         # ember eyes
    'T': 0xB8A98A,      # tabard
    't': 0x8A7C60,      # tabard shade
    'C': 0x2F3835,      # cloak
    'c': 0x1A211F,      # cloak shade
    'l': 0x4C5A55,      # cloak rim light
    'R': CRIMSON,       # sash, and the cross on the shield
    'r': CRIMSON_DEEP,  # sash shade
    'G': GOLD,          # trim, sword guard and pommel
    'g': GOLD_DEEP,     # gold shade
    # One cold iron ramp shared by the blade and the shield's field, so
    # the two pieces of war gear read as the same metal.
    'S': 0xB9AE93,      # iron, lit
    's': 0x8A8172,      # iron, mid
    'k': 0x5C564B,      # iron, falloff on the shadowed side
}

# Front: a tall bone capirote (the pointed Holy Week hood) over a face of
# pure shadow with two ember eyes, a dark cloak parted over a bone
# tabard, a crimson sash, and a robe that falls to a ragged hem instead
# of showing legs. The capirote is shaded across four bone tones so the
# cone reads as round under a light from the upper left — that falloff is
# the whole trick, everywhere.
#
# Facing the camera his shield arm is on the viewer's left and the sword
# on the right, both rising into the empty space either side of the
# hood: the cone stays the silhouette, and the war gear breaks its
# outline rather than cluttering its inside.
KNIGHT_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '..............dBd...............',
        '..............dBBd..............',
        '.............dXBbd..............',
        '.............dXBbnd.............',
        '.............dXBbnd.............',
        '............dXBBbbnd............',
        '............dXBBbbnd............',
        '...........dXBBBbbnnd.....d.....',
        '...........dXBBBbbnnd....dXd....',
        '..........dXBBBBbbbnnd...dXd....',
        '..........dXBBBBbbbnnd...dXSd...',
        '.........dXBBBBBbbbbnnd..dXSd...',
        '.........dXBBBBBbbbbnnd..dXSd...',
        '........dXBKKKKKKKKKKbnd.dXSd...',
        '........dXBKKeeKKKKeeKnd.dXSd...',
        '........dXBKKKKKKKKKKbnd.dXSd...',
        '........dXBBKKKKKKKBBbnd.dXSd...',
        '....dddddddBBBBbbbbbnnnnddXSd...',
        '...dBBBBBbbdCTTTTTTCCCCccdXSd...',
        '..dBSSRRSsskdTTTTTTCCCCCdGGGGd..',
        '..dBSSRRSsskdTTTTTTCCCCCdgGGgd..',
        '..dBRRGGRRrkdTTTTTTGCCCCCdnnd...',
        '..dBSSRRSsskdTTTTTTGCCCCCdttd...',
        '..dBSSRRSsskdRRRRRRRRRRRdGGGGd..',
        '...dSSRRSskdrrGGGGrrrrrrrdggd...',
        '....dSRRSkdCGTTTTTTGCCCCCccd....',
        '...dldSRkdCCGTTTTTTGCCCCCCccd...',
        '...dlCdddCCCGtTTTTtGCCCCCCccd...',
        '...dlCCCCCCCGTTTTTTGCCCCCCccd...',
        '...dlCCCCCCCgGGGGGGgCCCCCCccd...',
        '....dcCd..dcCCcd..dcCCcd..dcCd..',
        '.....dcd....dcd.....dcd....dcd..',
    ),
)

# Back: the hood has no opening from here, so the cone runs on down past
# a single shaded seam. The tabard is gone — it hangs at the front only —
# and the sash is knotted at the spine with its tails falling over the
# whole, unparted cloak.
#
# Both arms have swapped sides with the turn. The shield shows its back:
# no cross and no lit rim, just boards and the bone enarme strap he grips
# it by — the side of a shield the light never reaches.
KNIGHT_BACK_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '..............dBd...............',
        '..............dBBd..............',
        '.............dXBbd..............',
        '.............dXBbnd.............',
        '.............dXBbnd.............',
        '............dXBBbbnd............',
        '............dXBBbbnd............',
        '.....d.....dXBBBbbnnd...........',
        '....dXd....dXBBBbbnnd...........',
        '....dXd...dXBBBBbbbnnd..........',
        '....dXSd..dXBBBBbbbnnd..........',
        '....dXSd.dXBBBBBbbbbnnd.........',
        '....dXSd.dXBBBBBbbbbnnd.........',
        '....dXSddXBBBBBnbbbbbbnd........',
        '....dXSddXBBBBBnbbbbbbnd........',
        '....dXSddXBBBBBnbbbbbbnd........',
        '....dXSddXBBBBBnbbbbbbnd........',
        '....dXSdXBBBBBnbbbbbnddddddd....',
        '....dXSdCCCBBBBBBbbbdkkkkkkkd...',
        '...dGGGGdCCBBBBBBbbdkssssssskd..',
        '...dgGGgdCCCBBBBbbbdkssssssskd..',
        '...ddnndCCCCCBBbbCCdkBBBBBBBkd..',
        '....dttdCCCCGCCCCCCdknnnnnnnkd..',
        '...dGGGGdRRRRRRRRRRdkssssssskd..',
        '....dggdrrrrrrRRRRrrdsssssskd...',
        '....dlCCCCCCCCrRRrCCCdsssskd....',
        '...dlCCCCCCCCCrRRrCCCCdsskdcd...',
        '...dlCCCCCCCCCrRrrCCCCCdddccd...',
        '...dlCCCCCCCCCCrrCCCCCCCCCccd...',
        '...dlCCCCCCCgGGGGGGgCCCCCCccd...',
        '....dcCd..dcCCcd..dcCCcd..dcCd..',
        '.....dcd....dcd.....dcd....dcd..',
    ),
)

# Side: two thirds the width of the front view, the capirote leaning
# into the walk, one ember eye down inside the hood's opening, and the
# tabard showing only as the strip of bone along the leading edge.
#
# In profile the shield arm is the near one, so the shield sits across
# the torso — the halfway point of its sweep — while the sword arm has
# gone behind him and only the blade clears his trailing shoulder.
KNIGHT_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '.................dBd............',
        '................dXBbd...........',
        '................dXBbd...........',
        '...............dXBBbd...........',
        '...............dXBBbd...........',
        '........d.....dXBBBbnd..........',
        '.......dXd....dXBBBbnd..........',
        '.......dXd...dXBBBBbnd..........',
        '.......dXSd..dXBBBBbnd..........',
        '.......dXSd.dXBBBBBbnnd.........',
        '.......dXSd.dXBBBBBbnnd.........',
        '.......dXSddXBBBBBBbnnd.........',
        '.......dXSddXBBBBBBbnnd.........',
        '.......dXSdXBBBBBBKKKd..........',
        '.......dXSdXBBBBBBKeKd..........',
        '.......dXSdXBBBBBBKKKd..........',
        '.......dXSdXBBBBBBBKKd..........',
        '......dGGdXBBBBBBBbbbbd.........',
        '......dgGdlCCCCCCCCCCCTccd......',
        '.......ddlCCCCCdddddCCTTccd.....',
        '.......ddlCCCCdBBBbbdGTTccd.....',
        '......dGdlCCCdBSRRSskdTTccd.....',
        '.......ddlCCCdBSRRSskdTTccd.....',
        '........dlRRRdBRGGRrkdRRRcd.....',
        '........dlrrrdBSRRSskdrrrcd.....',
        '........dlCCCdBSRRSskdTTccd.....',
        '........dlCCCCdSRRSkdGTTccd.....',
        '........dlCCCCCdRRkdCGtTccd.....',
        '........dlCCCCCCdkdCCGTTccd.....',
        '........dlCCCCCCdddgGGGGccd.....',
        '.........dcCCcd...dcCCcd........',
        '..........dcd......dcd..........',
    ),
)

# Three-quarters toward the camera: between the front and side
# silhouettes in width, the capirote leaning off-centre, and the hood's
# opening swung far enough round that the trailing eye is a single pixel
# to the leading eye's two. That eye asymmetry is what actually sells a
# 45-degree turn at this size — the outline barely changes.
#
# The shield has started its swing across the body and the sword arm has
# gone back far enough that the cloak eats its pommel: the step between
# the front view and the profile, in both directions at once.
KNIGHT_FRONT_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '...............dBd..............',
        '...............dBBd.............',
        '..............dXBbd.............',
        '..............dXBbnd............',
        '..............dXBbnd............',
        '.............dXBBbbnd...........',
        '.............dXBBbbnd......d....',
        '............dXBBBbbnnd....dXd...',
        '............dXBBBbbnnd....dXd...',
        '...........dXBBBBbbbnnd...dXSd..',
        '...........dXBBBBbbbnnd...dXSd..',
        '..........dXBBBBBbbbbnnd..dXSd..',
        '..........dXBBBBBbbbbnnd..dXSd..',
        '.........dXBBKKKKKKKKKbnd.dXSd..',
        '.........dXBBKeKKKKeeKbnd.dXSd..',
        '.........dXBBKKKKKKKKKbnd.dXSd..',
        '.........dXBBBKKKKKKKBbnd.dXSd..',
        '........dXBBBBBbbbbbnnnnd.dXSd..',
        '.......dddddCTTTTTTCCCCccdGGGGd.',
        '......dBBBbbdTTTTTTCCCCCCccdGgd.',
        '.....dBSRRSskdTTTTTTCCCCCCccdd..',
        '.....dBSRRSskdTTTTTTGCCCCCccdd..',
        '.....dBRGGRrkdTTTTTTGCCCCccdGGd.',
        '.....dBSRRSskdRRRRRRRRRRRRcdgd..',
        '.....dBSRRSskdrGGGGrrrrrrrcd....',
        '......dSRRSkdGTTTTTTGCCCCccd....',
        '.....dldRRkdCGTTTTTTGCCCCCccd...',
        '.....dlCdkdCCGtTTTTtGCCCCCccd...',
        '.....dlCdddCCGTTTTTTGCCCCCccd...',
        '.....dlCCCCCCgGGGGGGgCCCCCccd...',
        '.....dcCd..dcCCcd..dcCCcd..dcd..',
        '......dcd....dcd.....dcd...dcd..',
    ),
)

# Three-quarters away: the hood is closed, so its seam does the work the
# eyes do on the front three-quarter view — it sits left of centre, which
# is where the spine of a body turned away-and-right lands. A sliver of
# the bone tabard still shows past the leading edge.
#
# Far enough round that the shield is showing its strapped back and the
# sword has come out from behind him on the other side: the mirror of the
# front three-quarter, one step further through the turn.
KNIGHT_BACK_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '...............dBd..............',
        '...............dBBd.............',
        '..............dXBbd.............',
        '..............dXBbnd............',
        '..............dXBbnd............',
        '.............dXBBbbnd...........',
        '.....d.......dXBBbbnd...........',
        '....dXd.....dXBBBbbnnd..........',
        '....dXd.....dXBBBbbnnd..........',
        '....dXSd...dXBBBBbbbnnd.........',
        '....dXSd...dXBBBBbbbnnd.........',
        '....dXSd..dXBBBBBbbbbnnd........',
        '....dXSd..dXBBBBBbbbbnnd........',
        '....dXSd.dXBBBBnbbbbbbbnd.......',
        '....dXSd.dXBBBBnbbbbbbbnd.......',
        '....dXSd.dXBBBBnbbbbbbbnd.......',
        '....dXSd.dXBBBBnbbbbbbbnd.......',
        '....dXSddXBBBBnbbbbbbnnnnd......',
        '...dGGGGdlCBBBBbbbbbCddddd......',
        '...dgGdlCCCBBBBbbbbCdkkkkkdd....',
        '....ddlCCCCCBBBbbbCdksssssbdd...',
        '....ddlCCCCCCCBbbCCdksssssbdd...',
        '...dGGdlCCCCCGCCCCCdkBBBBBkd....',
        '....dgdlRRRRRRRRRRRdknnnnnkd....',
        '......dlrrrrrRRRRrrdksssssbd....',
        '......dlCCCCCrRRrCCCdssssbdd....',
        '.....dlCCCCCCCrRRrCCCdsskdccd...',
        '.....dlCCCCCCCCrRrCCCCdkdTccd...',
        '.....dlCCCCCCCCCrrCCCCdddTccd...',
        '.....dlCCCCCCgGGGGGGgCCCCCccd...',
        '.....dcCd..dcCCcd..dcCCcd..dcd..',
        '......dcd....dcd.....dcd...dcd..',
    ),
)

KNIGHT_VIEWS = DirectionalSprite(front=KNIGHT_SPRITE, back=KNIGHT_BACK_SPRITE,
                                 side=KNIGHT_SIDE_SPRITE,
                                 front_side=KNIGHT_FRONT_SIDE_SPRITE,
                                 back_side=KNIGHT_BACK_SIDE_SPRITE)

# --- blocking ---------------------------------------------------------
#
# The same five views with the SHIELD arm empty, drawn while the guard
# is up. Same reasoning as the swing set below: a shield held out in
# front of him cannot also be strapped to his arm, so the body lets go
# of it for as long as the scene is drawing it raised.

KNIGHT_BLOCK_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '..............dBd...............',
        '..............dBBd..............',
        '.............dXBbd..............',
        '.............dXBbnd.............',
        '.............dXBbnd.............',
        '............dXBBbbnd............',
        '............dXBBbbnd............',
        '...........dXBBBbbnnd.....d.....',
        '...........dXBBBbbnnd....dXd....',
        '..........dXBBBBbbbnnd...dXd....',
        '..........dXBBBBbbbnnd...dXSd...',
        '.........dXBBBBBbbbbnnd..dXSd...',
        '.........dXBBBBBbbbbnnd..dXSd...',
        '........dXBKKKKKKKKKKbnd.dXSd...',
        '........dXBKKeeKKKKeeKnd.dXSd...',
        '........dXBKKKKKKKKKKbnd.dXSd...',
        '........dXBBKKKKKKKBBbnd.dXSd...',
        '.......dXBBBBBBbbbbbnnnnddXSd...',
        '......dlCCCCCTTTTTTCCCCccdXSd...',
        '....dlCCCCCCCTTTTTTCCCCCdGGGGd..',
        '...dlCCCCCCCCTTTTTTCCCCCdgGGgd..',
        '...dlCCCCCCCGTTTTTTGCCCCCdnnd...',
        '....dlCCCCCCGTTTTTTGCCCCCdttd...',
        '....dlRRRRRRRRRRRRRRRRRRdGGGGd..',
        '....dlrrrrrrrrGGGGrrrrrrrdggd...',
        '....dlCCCCCCGTTTTTTGCCCCCccd....',
        '...dlCCCCCCCGTTTTTTGCCCCCCccd...',
        '...dlCCCCCCCGtTTTTtGCCCCCCccd...',
        '...dlCCCCCCCGTTTTTTGCCCCCCccd...',
        '...dlCCCCCCCgGGGGGGgCCCCCCccd...',
        '....dcCd..dcCCcd..dcCCcd..dcCd..',
        '.....dcd....dcd.....dcd....dcd..',
    ),
)

KNIGHT_BLOCK_BACK_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '..............dBd...............',
        '..............dBBd..............',
        '.............dXBbd..............',
        '.............dXBbnd.............',
        '.............dXBbnd.............',
        '............dXBBbbnd............',
        '............dXBBbbnd............',
        '.....d.....dXBBBbbnnd...........',
        '....dXd....dXBBBbbnnd...........',
        '....dXd...dXBBBBbbbnnd..........',
        '....dXSd..dXBBBBbbbnnd..........',
        '....dXSd.dXBBBBBbbbbnnd.........',
        '....dXSd.dXBBBBBbbbbnnd.........',
        '....dXSddXBBBBBnbbbbbbnd........',
        '....dXSddXBBBBBnbbbbbbnd........',
        '....dXSddXBBBBBnbbbbbbnd........',
        '....dXSddXBBBBBnbbbbbbnd........',
        '....dXSdXBBBBBnbbbbbnnnnd.......',
        '....dXSdCCCBBBBBBbbbbCCccd......',
        '...dGGGGdCCBBBBBBbbbbCCCCccd....',
        '...dgGGgdCCCBBBBbbbbCCCCCCccd...',
        '...ddnndCCCCCBBbbCCCCCCCCCccd...',
        '....dttdCCCCGCCCCCCGCCCCCccd....',
        '...dGGGGdRRRRRRRRRRRRRRRRRcd....',
        '....dggdrrrrrrRRRRrrrrrrrrcd....',
        '....dlCCCCCCCCrRRrCCCCCCCccd....',
        '...dlCCCCCCCCCrRRrCCCCCCCCccd...',
        '...dlCCCCCCCCCrRrrCCCCCCCCccd...',
        '...dlCCCCCCCCCCrrCCCCCCCCCccd...',
        '...dlCCCCCCCgGGGGGGgCCCCCCccd...',
        '....dcCd..dcCCcd..dcCCcd..dcCd..',
        '.....dcd....dcd.....dcd....dcd..',
    ),
)

KNIGHT_BLOCK_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '.................dBd............',
        '................dXBbd...........',
        '................dXBbd...........',
        '...............dXBBbd...........',
        '...............dXBBbd...........',
        '........d.....dXBBBbnd..........',
        '.......dXd....dXBBBbnd..........',
        '.......dXd...dXBBBBbnd..........',
        '.......dXSd..dXBBBBbnd..........',
        '.......dXSd.dXBBBBBbnnd.........',
        '.......dXSd.dXBBBBBbnnd.........',
        '.......dXSddXBBBBBBbnnd.........',
        '.......dXSddXBBBBBBbnnd.........',
        '.......dXSdXBBBBBBKKKd..........',
        '.......dXSdXBBBBBBKeKd..........',
        '.......dXSdXBBBBBBKKKd..........',
        '.......dXSdXBBBBBBBKKd..........',
        '......dGGdXBBBBBBBbbbbd.........',
        '......dgGdlCCCCCCCCCCCTccd......',
        '.......ddlCCCCCCCCCCCCTTccd.....',
        '.......ddlCCCCCCCCCCCGTTccd.....',
        '......dGdlCCCCCCCCCCCGTTccd.....',
        '.......ddlCCCCCCCCCCCGTTccd.....',
        '........dlRRRRRRRRRRRRRRRcd.....',
        '........dlrrrrrrrrrrGGrrrcd.....',
        '........dlCCCCCCCCCCCGTTccd.....',
        '........dlCCCCCCCCCCCGTTccd.....',
        '........dlCCCCCCCCCCCGtTccd.....',
        '........dlCCCCCCCCCCCGTTccd.....',
        '........dlCCCCCCCCCgGGGGccd.....',
        '.........dcCCcd...dcCCcd........',
        '..........dcd......dcd..........',
    ),
)

KNIGHT_BLOCK_FRONT_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '...............dBd..............',
        '...............dBBd.............',
        '..............dXBbd.............',
        '..............dXBbnd............',
        '..............dXBbnd............',
        '.............dXBBbbnd...........',
        '.............dXBBbbnd......d....',
        '............dXBBBbbnnd....dXd...',
        '............dXBBBbbnnd....dXd...',
        '...........dXBBBBbbbnnd...dXSd..',
        '...........dXBBBBbbbnnd...dXSd..',
        '..........dXBBBBBbbbbnnd..dXSd..',
        '..........dXBBBBBbbbbnnd..dXSd..',
        '.........dXBBKKKKKKKKKbnd.dXSd..',
        '.........dXBBKeKKKKeeKbnd.dXSd..',
        '.........dXBBKKKKKKKKKbnd.dXSd..',
        '.........dXBBBKKKKKKKBbnd.dXSd..',
        '........dXBBBBBbbbbbnnnnd.dXSd..',
        '........dlCCCTTTTTTCCCCccdGGGGd.',
        '......dlCCCCCTTTTTTCCCCCCccdGgd.',
        '.....dlCCCCCCCTTTTTTCCCCCCccdd..',
        '.....dlCCCCCCGTTTTTTGCCCCCccdd..',
        '......dlCCCCCGTTTTTTGCCCCccdGGd.',
        '......dlRRRRRRRRRRRRRRRRRRcdgd..',
        '......dlrrrrrrrGGGGrrrrrrrcd....',
        '......dlCCCCCGTTTTTTGCCCCccd....',
        '.....dlCCCCCCGTTTTTTGCCCCCccd...',
        '.....dlCCCCCCGtTTTTtGCCCCCccd...',
        '.....dlCCCCCCGTTTTTTGCCCCCccd...',
        '.....dlCCCCCCgGGGGGGgCCCCCccd...',
        '.....dcCd..dcCCcd..dcCCcd..dcd..',
        '......dcd....dcd.....dcd...dcd..',
    ),
)

KNIGHT_BLOCK_BACK_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '...............dBd..............',
        '...............dBBd.............',
        '..............dXBbd.............',
        '..............dXBbnd............',
        '..............dXBbnd............',
        '.............dXBBbbnd...........',
        '.....d.......dXBBbbnd...........',
        '....dXd.....dXBBBbbnnd..........',
        '....dXd.....dXBBBbbnnd..........',
        '....dXSd...dXBBBBbbbnnd.........',
        '....dXSd...dXBBBBbbbnnd.........',
        '....dXSd..dXBBBBBbbbbnnd........',
        '....dXSd..dXBBBBBbbbbnnd........',
        '....dXSd.dXBBBBnbbbbbbbnd.......',
        '....dXSd.dXBBBBnbbbbbbbnd.......',
        '....dXSd.dXBBBBnbbbbbbbnd.......',
        '....dXSd.dXBBBBnbbbbbbbnd.......',
        '....dXSddXBBBBnbbbbbbnnnnd......',
        '...dGGGGdlCBBBBbbbbbCCCTcd......',
        '...dgGdlCCCBBBBbbbbCCCCCTTcd....',
        '....ddlCCCCCBBBbbbCCCCCCCTTcd...',
        '....ddlCCCCCCCBbbCCCCCCCGTTcd...',
        '...dGGdlCCCCCGCCCCCCCCGTTccd....',
        '....dgdlRRRRRRRRRRRRRRRRRRcd....',
        '......dlrrrrrRRRRrrrrrrrrrcd....',
        '......dlCCCCCrRRrCCCCCGTTccd....',
        '.....dlCCCCCCCrRRrCCCCCGTTccd...',
        '.....dlCCCCCCCCrRrCCCCCGTTccd...',
        '.....dlCCCCCCCCCrrCCCCCGTTccd...',
        '.....dlCCCCCCgGGGGGGgCCCCCccd...',
        '.....dcCd..dcCCcd..dcCCcd..dcd..',
        '......dcd....dcd.....dcd...dcd..',
    ),
)
KNIGHT_BLOCK_VIEWS = DirectionalSprite(
    front=KNIGHT_BLOCK_SPRITE, back=KNIGHT_BLOCK_BACK_SPRITE,
    side=KNIGHT_BLOCK_SIDE_SPRITE,
    front_side=KNIGHT_BLOCK_FRONT_SIDE_SPRITE,
    back_side=KNIGHT_BLOCK_BACK_SIDE_SPRITE)

# The shield as a thing that can be moved: a small heater shield faced
# in the sword's own dark iron, ramped three tones across from the
# upper left, with a bone-bright rim down the lit edge and a crimson
# cross over a single gold stud. The same shield the body art carries,
# drawn at the size it reads at when it is up in front of him.
#
# Unlike the sword it is never rotated — a shield face is turned toward
# what it stops, not pointed along an angle — so its light keeps coming
# from the upper left in every direction the knight faces. It has two
# faces instead: raised toward the camera you see the cross, raised away
# from it you see the boards, exactly as the body art has it. Sharing
# one palette is what keeps them the same object.
SHIELD_PALETTE = {
    'd': VOID,          # outline
    'B': BONE_LIT,      # bone rim on the lit edge, and the enarme strap
    'b': BONE_DEEP,     # bone in shadow
    'I': 0xB9AE93,      # iron face, lit (the sword's blade tone)
    'i': 0x8A8172,      # iron mid
    'k': 0x5C564B,      # iron falloff on the shadowed side
    'R': CRIMSON,       # painted cross
    'r': CRIMSON_DEEP,  # cross in shadow
    'G': GOLD,          # the boss stud — the one gold note
    'g': GOLD_DEEP,
}

SHIELD_SPRITE = PixelSprite(
    palette=SHIELD_PALETTE,
    rows=(
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '...........dddddddddd...........',
        '..........dBBBBBBBbbbd..........',
        '.........dBIIiiRRikkkbd.........',
        '.........dBIIiiRRikkkbd.........',
        '.........dBIIiiRRikkkbd.........',
        '.........dBRRRRGGRRrrbd.........',
        '.........dBrrRRGgRrrrbd.........',
        '.........dBIiiiRRkkkkbd.........',
        '.........dBIiiiRRkkkkbd.........',
        '.........dBiiiiRRkkkkbd.........',
        '..........dIiiiRRkkkbd..........',
        '..........diiiiRRkkkbd..........',
        '...........diiiRRkkkd...........',
        '............diiRRkkd............',
        '.............dirrkd.............',
        '..............dikd..............',
        '...............dd...............',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
    ),
)

# The same shield from behind, for when he raises it away from the
# camera: the same silhouette to the pixel, but plain boards and the bone
# enarme strap he grips it by instead of the painted face. Without it the
# cross would flash into view at the exact moment the body hands the
# shield over, which is the one moment the handoff must not be visible.
SHIELD_BACK_SPRITE = PixelSprite(
    palette=SHIELD_PALETTE,
    rows=(
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '...........dddddddddd...........',
        '..........dkkkkkkkkkkd..........',
        '.........dkiiiiiiiiiikd.........',
        '.........dkiiiiiiiiiikd.........',
        '.........dkiiiiiiiiiikd.........',
        '.........dkBBBBBBBBBBkd.........',
        '.........dkbbbbbbbbbbkd.........',
        '.........dkiiiiiiiiiikd.........',
        '.........dkiiiiiiiiiikd.........',
        '.........dkiiiiiiiiiikd.........',
        '..........diiiiiiiiikd..........',
        '..........diiiiiiiikkd..........',
        '...........diiiiikkkd...........',
        '............diiikkkd............',
        '.............diikkd.............',
        '..............dikd..............',
        '...............dd...............',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
        '................................',
    ),
)

# --- swinging ---------------------------------------------------------
#
# The same five views with the sword hand EMPTY, drawn for exactly as
# long as a swing lasts. The sword is a real object: while it is being
# swung through the arc it is not also standing at his side, and the only
# way to say that with baked-in gear is to take it out of the body for
# the duration. Everything else — the shield, the sash, the hem, the row
# his feet stand on — is identical to the armed view above it, so the
# swap lands on the frame the swing starts and reads as the arm moving
# rather than as the body changing.
#
# The shield used to have a matching "raised" variant here too. It does
# not need one: a block is a stance rather than a motion, and the scene
# says it with the sector it lights up on the floor.

KNIGHT_SWING_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '..............dBd...............',
        '..............dBBd..............',
        '.............dXBbd..............',
        '.............dXBbnd.............',
        '.............dXBbnd.............',
        '............dXBBbbnd............',
        '............dXBBbbnd............',
        '...........dXBBBbbnnd...........',
        '...........dXBBBbbnnd...........',
        '..........dXBBBBbbbnnd..........',
        '..........dXBBBBbbbnnd..........',
        '.........dXBBBBBbbbbnnd.........',
        '.........dXBBBBBbbbbnnd.........',
        '........dXBKKKKKKKKKKbnd........',
        '........dXBKKeeKKKKeeKnd........',
        '........dXBKKKKKKKKKKbnd........',
        '........dXBBKKKKKKKBBbnd........',
        '....dddddddBBBBbbbbbnnnnd.......',
        '...dBBBBBbbdCTTTTTTCCCCccd......',
        '..dBSSRRSsskdTTTTTTCCCCCCccd....',
        '..dBSSRRSsskdTTTTTTCCCCCCCccd...',
        '..dBRRGGRRrkdTTTTTTGCCCCCCccd...',
        '..dBSSRRSsskdTTTTTTGCCCCCccd....',
        '..dBSSRRSsskdRRRRRRRRRRRRRcd....',
        '...dSSRRSskdrrGGGGrrrrrrrrcd....',
        '....dSRRSkdCGTTTTTTGCCCCCccd....',
        '...dldSRkdCCGTTTTTTGCCCCCCccd...',
        '...dlCdddCCCGtTTTTtGCCCCCCccd...',
        '...dlCCCCCCCGTTTTTTGCCCCCCccd...',
        '...dlCCCCCCCgGGGGGGgCCCCCCccd...',
        '....dcCd..dcCCcd..dcCCcd..dcCd..',
        '.....dcd....dcd.....dcd....dcd..',
    ),
)

KNIGHT_SWING_BACK_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '..............dBd...............',
        '..............dBBd..............',
        '.............dXBbd..............',
        '.............dXBbnd.............',
        '.............dXBbnd.............',
        '............dXBBbbnd............',
        '............dXBBbbnd............',
        '...........dXBBBbbnnd...........',
        '...........dXBBBbbnnd...........',
        '..........dXBBBBbbbnnd..........',
        '..........dXBBBBbbbnnd..........',
        '.........dXBBBBBbbbbnnd.........',
        '.........dXBBBBBbbbbnnd.........',
        '........dXBBBBBnbbbbbbnd........',
        '........dXBBBBBnbbbbbbnd........',
        '........dXBBBBBnbbbbbbnd........',
        '........dXBBBBBnbbbbbbnd........',
        '.......dXBBBBBnbbbbbnddddddd....',
        '......dlCCCBBBBBBbbbdkkkkkkkd...',
        '....dlCCCCCBBBBBBbbdkssssssskd..',
        '...dlCCCCCCCBBBBbbbdkssssssskd..',
        '...dlCCCCCCCCBBbbCCdkBBBBBBBkd..',
        '....dlCCCCCCGCCCCCCdknnnnnnnkd..',
        '....dlRRRRRRRRRRRRRdkssssssskd..',
        '....dlrrrrrrrrRRRRrrdsssssskd...',
        '....dlCCCCCCCCrRRrCCCdsssskd....',
        '...dlCCCCCCCCCrRRrCCCCdsskdcd...',
        '...dlCCCCCCCCCrRrrCCCCCdddccd...',
        '...dlCCCCCCCCCCrrCCCCCCCCCccd...',
        '...dlCCCCCCCgGGGGGGgCCCCCCccd...',
        '....dcCd..dcCCcd..dcCCcd..dcCd..',
        '.....dcd....dcd.....dcd....dcd..',
    ),
)

KNIGHT_SWING_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '.................dBd............',
        '................dXBbd...........',
        '................dXBbd...........',
        '...............dXBBbd...........',
        '...............dXBBbd...........',
        '..............dXBBBbnd..........',
        '..............dXBBBbnd..........',
        '.............dXBBBBbnd..........',
        '.............dXBBBBbnd..........',
        '............dXBBBBBbnnd.........',
        '............dXBBBBBbnnd.........',
        '...........dXBBBBBBbnnd.........',
        '...........dXBBBBBBbnnd.........',
        '..........dXBBBBBBKKKd..........',
        '..........dXBBBBBBKeKd..........',
        '..........dXBBBBBBKKKd..........',
        '..........dXBBBBBBBKKd..........',
        '.........dXBBBBBBBbbbbd.........',
        '.........dlCCCCCCCCCCCTccd......',
        '........dlCCCCCdddddCCTTccd.....',
        '........dlCCCCdBBBbbdGTTccd.....',
        '........dlCCCdBSRRSskdTTccd.....',
        '........dlCCCdBSRRSskdTTccd.....',
        '........dlRRRdBRGGRrkdRRRcd.....',
        '........dlrrrdBSRRSskdrrrcd.....',
        '........dlCCCdBSRRSskdTTccd.....',
        '........dlCCCCdSRRSkdGTTccd.....',
        '........dlCCCCCdRRkdCGtTccd.....',
        '........dlCCCCCCdkdCCGTTccd.....',
        '........dlCCCCCCdddgGGGGccd.....',
        '.........dcCCcd...dcCCcd........',
        '..........dcd......dcd..........',
    ),
)

KNIGHT_SWING_FRONT_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '...............dBd..............',
        '...............dBBd.............',
        '..............dXBbd.............',
        '..............dXBbnd............',
        '..............dXBbnd............',
        '.............dXBBbbnd...........',
        '.............dXBBbbnd...........',
        '............dXBBBbbnnd..........',
        '............dXBBBbbnnd..........',
        '...........dXBBBBbbbnnd.........',
        '...........dXBBBBbbbnnd.........',
        '..........dXBBBBBbbbbnnd........',
        '..........dXBBBBBbbbbnnd........',
        '.........dXBBKKKKKKKKKbnd.......',
        '.........dXBBKeKKKKeeKbnd.......',
        '.........dXBBKKKKKKKKKbnd.......',
        '.........dXBBBKKKKKKKBbnd.......',
        '........dXBBBBBbbbbbnnnnd.......',
        '.......dddddCTTTTTTCCCCccd......',
        '......dBBBbbdTTTTTTCCCCCCccd....',
        '.....dBSRRSskdTTTTTTCCCCCCccd...',
        '.....dBSRRSskdTTTTTTGCCCCCccd...',
        '.....dBRGGRrkdTTTTTTGCCCCccd....',
        '.....dBSRRSskdRRRRRRRRRRRRcd....',
        '.....dBSRRSskdrGGGGrrrrrrrcd....',
        '......dSRRSkdGTTTTTTGCCCCccd....',
        '.....dldRRkdCGTTTTTTGCCCCCccd...',
        '.....dlCdkdCCGtTTTTtGCCCCCccd...',
        '.....dlCdddCCGTTTTTTGCCCCCccd...',
        '.....dlCCCCCCgGGGGGGgCCCCCccd...',
        '.....dcCd..dcCCcd..dcCCcd..dcd..',
        '......dcd....dcd.....dcd...dcd..',
    ),
)

KNIGHT_SWING_BACK_SIDE_SPRITE = PixelSprite(
    palette=KNIGHT_PALETTE,
    rows=(
        '...............dBd..............',
        '...............dBBd.............',
        '..............dXBbd.............',
        '..............dXBbnd............',
        '..............dXBbnd............',
        '.............dXBBbbnd...........',
        '.............dXBBbbnd...........',
        '............dXBBBbbnnd..........',
        '............dXBBBbbnnd..........',
        '...........dXBBBBbbbnnd.........',
        '...........dXBBBBbbbnnd.........',
        '..........dXBBBBBbbbbnnd........',
        '..........dXBBBBBbbbbnnd........',
        '.........dXBBBBnbbbbbbbnd.......',
        '.........dXBBBBnbbbbbbbnd.......',
        '.........dXBBBBnbbbbbbbnd.......',
        '.........dXBBBBnbbbbbbbnd.......',
        '........dXBBBBnbbbbbbnnnnd......',
        '........dlCBBBBbbbbbCddddd......',
        '......dlCCCBBBBbbbbCdkkkkkdd....',
        '.....dlCCCCCBBBbbbCdksssssbdd...',
        '.....dlCCCCCCCBbbCCdksssssbdd...',
        '......dlCCCCCGCCCCCdkBBBBBkd....',
        '......dlRRRRRRRRRRRdknnnnnkd....',
        '......dlrrrrrRRRRrrdksssssbd....',
        '......dlCCCCCrRRrCCCdssssbdd....',
        '.....dlCCCCCCCrRRrCCCdsskdccd...',
        '.....dlCCCCCCCCrRrCCCCdkdTccd...',
        '.....dlCCCCCCCCCrrCCCCdddTccd...',
        '.....dlCCCCCCgGGGGGGgCCCCCccd...',
        '.....dcCd..dcCCcd..dcCCcd..dcd..',
        '......dcd....dcd.....dcd...dcd..',
    ),
)

KNIGHT_SWING_VIEWS = DirectionalSprite(
    front=KNIGHT_SWING_SPRITE, back=KNIGHT_SWING_BACK_SPRITE,
    side=KNIGHT_SWING_SIDE_SPRITE,
    front_side=KNIGHT_SWING_FRONT_SIDE_SPRITE,
    back_side=KNIGHT_SWING_BACK_SIDE_SPRITE)

# 32x32 penitential sword pointing straight up: a dark iron blade with
# a bone-bright edge and a black fuller, a broad gold cruciform guard,
# a crimson ribbon knotted to it, and a gold pommel. The same weapon he
# carries in the five views above, drawn at the size it reads at when it
# is out of his hand and travelling — the scene sweeps this through the
# arc while the body holds KNIGHT_SWING_VIEWS.
SWORD_SPRITE = PixelSprite(
    palette={
        'X': 0xF2ECD6,      # bone-bright edge
        'S': 0xB9AE93,      # blade
        's': 0x6B6455,      # blade shade
        'F': 0x2E2A2A,      # black fuller
        'G': GOLD,          # gold guard/pommel
        'g': GOLD_DEEP,     # gold shade
        'B': SEPIA,         # leather grip
        'b': SEPIA_DEEP,    # grip wrap shadow
        'R': CRIMSON,       # knotted ribbon
        'r': CRIMSON_DEEP,  # ribbon shade
        'P': GOLD_SPEC,     # pommel specular
    },
    rows=(
        '...............X................',
        '...............Xs...............',
        '..............XSs...............',
        '..............XSs...............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSFs..............',
        '..............XSss..............',
        '.........GGGGGGGGGGGGGG.........',
        '........GgggggGGGGgggggG........',
        '..........GggggggggggG..........',
        '.........RR...BBBb..............',
        '.........Rr...bBBB..............',
        '.........rR...BBBb..............',
        '..........R...bBBB..............',
        '..........r...BBBb..............',
        '..............bBBB..............',
        '............GGGGGGGG............',
        '.............gGPPGg.............',
        '................................',
    ),
)
