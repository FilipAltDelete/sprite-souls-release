"""The scenery on the plane, and what it does to anything walking into
it. A forest of circles: every prop is a position, a kind and a radius,
and `ObstacleField.resolve()` pushes a body out of any it overlaps.

pygame-free like the rest of core/ — a tree here is three floats and a
name. What a 'pine' *looks* like is `gfx/sprites/forest.py`, and
`GameScene.PROP_ART` is where the two meet; the kind name is the only
thing they share. Adding a kind means all three.

Two rules hold the whole thing up, and both are about not taking the map
away from the player:

- **Nothing is ever closer to anything else than the widest body in the
  game.** `MIN_GAP` is the clear space left between two circles' edges,
  and it is a whole unit wider than the dragon at ground scale. A forest
  that can grow a gap narrower than the thing walking through it grows
  corridors that a boss sticks in and rooms the player cannot leave, and
  neither failure looks like a bug — it looks like the game hanging.
  It is also what makes one resolution pass enough: no body can be
  standing inside two props at once, so pushing it out of one cannot
  push it into another.
- **The same gap is owed to the world's edge, and the treeline collides
  with nothing at all.** Both are the same rule — `gfx/camera.py` is
  emphatic that the player walks all the way to the boundary even after
  the view has stopped following, and a trunk that pins them a stride
  short of it takes that away just as surely as a camera would. So
  blocking props keep `MIN_GAP` clear of the edge, and the wood *beyond*
  the edge is drawn but never collided with: it stands where nobody can
  reach it, and a collision circle out there could only ever reach back
  in and shove someone standing on the boundary.

The push-out is a single pass in arbitrary order, so a body wedged
between two props resolves against one and then the other rather than
solving both at once. At walking speed that is invisible; what it
guarantees is only that nothing is ever left *inside* the prop it was
last checked against, which is the property that matters.
"""

import math
import random
from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple

from .units import UNIT


@dataclass(frozen=True)
class PropKind:
    """What one sort of scenery is, to the simulation. `radius` is the
    circle it stops bodies with — zero means it is walked through, which
    is what undergrowth is for."""
    name: str
    radius: float
    weight: float           # relative frequency in the scatter


# The scatter's vocabulary. Trees are the bulk of it; the rest is there
# so a clearing is not just trees at wider spacing.
PROP_KINDS: Tuple[PropKind, ...] = (
    PropKind('pine', 0.6 * UNIT, 5.0),
    PropKind('dead_tree', 0.55 * UNIT, 1.5),
    PropKind('boulder', 0.7 * UNIT, 1.5),
    PropKind('stump', 0.45 * UNIT, 1.0),
    # Weighted well above anything it stands between, because it is the
    # only thing here that can be sown thickly: undergrowth owes no gap
    # to anything, so it is what fills the ground the trees have to leave
    # clear of each other.
    PropKind('fern', 0.0, 6.0),
)

# The clear space left between two blocking circles. The widest body in
# the game is the wyrm at ground scale, one UNIT of radius, so two of
# these units of gap is a corridor it fits through twice over. Tightening
# this is how you get a boss that walks into a gap it cannot leave.
MIN_GAP = 3 * UNIT

# How much forest is outside the playable world. It is never walked in —
# it is what the map's edge recedes into, so the boundary reads as the
# wood getting too thick to enter rather than as an invisible wall.
BORDER_DEPTH = 7 * UNIT

# How big a prop grew, as a multiple of its art. Quantised to these four
# and no more, for the same reason the walk cycle quantises its lean
# (gfx/walk.py): the scaled surface is cached per size, and a continuous
# range would mean a fresh scale of a fir for every fir on the map. Four
# sizes and a mirror is eight distinguishable trees out of one drawing,
# which is the difference between a wood and an orchard.
PROP_SCALES = (0.8, 1.0, 1.0, 1.2)

# The biggest circle the scatter can produce.
_MAX_EXTENT = max(k.radius for k in PROP_KINDS) * max(PROP_SCALES)

# How coarse the lookup grid is, and it is DERIVED rather than picked.
# Every query looks at the cell it lands in and its eight neighbours,
# which is guaranteed to find everything within one whole cell of the
# query point and nothing at all beyond it. So the cell has to be wider
# than the furthest two things can be apart and still concern each other:
# two of the largest prop plus MIN_GAP, which is the sowing test and the
# wider of the two by far (colliding only ever asks for one prop plus one
# body). Pick this by hand and set it a little small and nothing breaks
# loudly — the forest simply grows pairs of trees closer together than
# MIN_GAP, here and there, where the test could not see across a cell.
_CELL = 2 * _MAX_EXTENT + MIN_GAP + UNIT


@dataclass(frozen=True)
class Prop:
    kind: str
    x: float
    y: float
    # What it stops bodies with, already multiplied by `scale` — a bigger
    # tree is a bigger tree to walk into, not just to look at. Zero for
    # undergrowth, and zero for the whole treeline outside the world: see
    # the second rule in the module docstring.
    radius: float
    scale: float
    # Mirrored when drawn. Two of everything for free, and it is the
    # cheapest way to stop a stand of firs reading as one sprite pasted
    # down five times.
    flipped: bool


class ObstacleField:
    """A scattered forest, and the collision against it.

    Props are bucketed into a coarse grid once, at build time, because
    they never move — every query after that touches nine cells however
    many hundred trees are on the map."""

    def __init__(self, props: Sequence[Prop]):
        self.props: List[Prop] = sorted(props, key=lambda p: p.y)
        self._cells: Dict[Tuple[int, int], List[Prop]] = {}
        for prop in self.props:
            if prop.radius <= 0:
                continue                    # walked through; never queried
            self._cells.setdefault(
                (int(prop.x // _CELL), int(prop.y // _CELL)), []).append(prop)

    def resolve(self, x: float, y: float, radius: float) -> Tuple[float, float]:
        """Push a body of `radius` out of anything it is standing inside,
        and hand back where it ends up. The one entry point: the player
        goes through it in `_clamp_player`, every boss in
        `physics_update`, and nothing else needs to know the forest is
        there at all."""
        cx, cy = int(x // _CELL), int(y // _CELL)
        for gx in (cx - 1, cx, cx + 1):
            for gy in (cy - 1, cy, cy + 1):
                for prop in self._cells.get((gx, gy), ()):
                    min_d = prop.radius + radius
                    dx, dy = x - prop.x, y - prop.y
                    d_sq = dx * dx + dy * dy
                    if d_sq >= min_d * min_d:
                        continue
                    if d_sq > 0:
                        d = math.sqrt(d_sq)
                        x = prop.x + dx / d * min_d
                        y = prop.y + dy / d * min_d
                    else:
                        # Dead centre, with no normal to push along. Any
                        # direction will do; it cannot happen from
                        # walking, only from something placed on the spot.
                        x = prop.x + min_d
        return x, y


def scatter(world_w: float, world_h: float,
            clearings: Sequence[Tuple[float, float, float]] = (),
            density: float = 1.0) -> ObstacleField:
    """Grow a forest over the world and a deeper one around it.

    Rejection sampling rather than a grid with jitter: a lattice reads as
    a plantation the moment the player walks a straight line through it,
    and the whole point of scattering at run time is that no two runs
    share a map.

    `clearings` are (x, y, radius) circles nothing blocking may stand in
    — the spawn point is one, because respawning inside a tree would
    resolve by shoving the player out of it before they had touched a
    key."""
    props: List[Prop] = []
    # The accepted circles, bucketed the same way the field is, so
    # checking a candidate against the ones already down stays local.
    # Each is (x, y, clearance, blocks).
    grid: Dict[Tuple[int, int], List[Tuple[float, float, float, bool]]] = {}
    # What undergrowth is kept clear of, having no collision circle of
    # its own: enough that a fern is beside a trunk, never inside it.
    LEAF_CLEARANCE = 0.35 * UNIT

    def fits(x: float, y: float, radius: float, blocks: bool,
             gap: float) -> bool:
        near = radius if blocks else LEAF_CLEARANCE
        for cx, cy, cr, c_blocks in _neighbours(grid, x, y):
            # The gap is what a *body* has to squeeze between, so it is
            # owed only where both circles would stop one. Charging it
            # against undergrowth as well would thin the wood out for the
            # sake of ferns nobody collides with.
            need = near + cr + (gap if blocks and c_blocks else 0.0)
            if (x - cx) ** 2 + (y - cy) ** 2 < need * need:
                return False
        return True

    def place(x: float, y: float, kind: PropKind, scale: float,
              collides: bool) -> None:
        # How much room a prop takes up is a property of its art and
        # always applies; whether it *stops* anything is a property of
        # where it is standing. The treeline is spaced like a wood and
        # collides like a painting.
        extent = kind.radius * scale
        props.append(Prop(kind.name, x, y, extent if collides else 0.0,
                          scale, random.random() < 0.5))
        grid.setdefault((int(x // _CELL), int(y // _CELL)), []).append(
            (x, y, extent or LEAF_CLEARANCE, extent > 0))

    def sow(x0: float, y0: float, x1: float, y1: float, attempts: int,
            kinds: Sequence[PropKind], gap: float = MIN_GAP,
            edge: float = 0.0, collides: bool = True) -> None:
        weights = [k.weight for k in kinds]
        for _ in range(attempts):
            kind = random.choices(kinds, weights)[0]
            scale = random.choice(PROP_SCALES)
            r = kind.radius * scale
            # Inset by the prop's own radius, so its circle never leaves
            # the region it was sown in — which is what keeps the
            # treeline from standing over the boundary — and by `edge` on
            # top of that for anything that blocks, which is the lane
            # owed to the world's own edge. Undergrowth is charged
            # neither, so the lane is not a mown strip.
            inset = r + (edge if r > 0 else 0.0)
            if x0 + inset >= x1 - inset or y0 + inset >= y1 - inset:
                continue
            x = random.uniform(x0 + inset, x1 - inset)
            y = random.uniform(y0 + inset, y1 - inset)
            if any((x - cx) ** 2 + (y - cy) ** 2 < (cr + r) ** 2
                   for cx, cy, cr in clearings):
                continue
            if fits(x, y, r, r > 0, gap):
                place(x, y, kind, scale, collides)

    # Attempts, not a target count: rejection sampling saturates, so this
    # number buys diminishing density rather than a forest that grows
    # without limit. It is set where the wood stops getting visibly
    # thicker — most of these throws land on ground already taken.
    sow(0, 0, world_w, world_h, int(9000 * density), PROP_KINDS, edge=MIN_GAP)

    # The treeline: four bands outside the world, sown thick and
    # colliding with nothing. Nothing walks out there, so no gap is owed
    # and the wood closes right up into the dark.
    standing = tuple(k for k in PROP_KINDS if k.radius > 0)
    d = BORDER_DEPTH
    for band in ((-d, -d, world_w + d, 0.0),
                 (-d, world_h, world_w + d, world_h + d),
                 (-d, 0.0, 0.0, world_h),
                 (world_w, 0.0, world_w + d, world_h)):
        sow(*band, int(700 * density), standing, gap=0.0, collides=False)

    return ObstacleField(props)


def _neighbours(grid, x: float, y: float):
    cx, cy = int(x // _CELL), int(y // _CELL)
    for gx in (cx - 1, cx, cx + 1):
        for gy in (cy - 1, cy, cy + 1):
            yield from grid.get((gx, gy), ())
