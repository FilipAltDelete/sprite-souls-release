"""Minimal scene manager: named scene instances, one active at a time.
Instances are reused across switches (like Phaser), so per-scene state
such as the class-select god-mode checkbox persists between visits."""


class Scene:
    def __init__(self, manager):
        self.manager = manager

    def enter(self, **data):
        """Called on every switch to this scene (Phaser's create)."""

    def handle_event(self, event):
        pass

    def update(self, dt_ms):
        pass

    def draw(self, screen):
        pass


class SceneManager:
    def __init__(self):
        self.scenes = {}
        self.current = None
        self.running = True

    def add(self, name, scene):
        self.scenes[name] = scene

    def start(self, name, **data):
        self.current = self.scenes[name]
        self.current.enter(**data)

    def quit(self):
        self.running = False
