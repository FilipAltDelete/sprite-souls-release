"""Initial screen: pick a class before entering the arena.
Mouse (hover + click) or keyboard (arrows + Enter). G toggles god mode
(bosses spawn with 1 HP — a playtesting aid); the checkbox state
persists across visits because the scene instance is reused."""

import pygame

from core.classes import CLASSES, CLASS_ORDER
from gfx.pixelart import create_pixel_surface, rgb
from gfx.sprites import CLASS_SPRITES
from gfx.text import draw_text, get_font, wrap_lines
from settings import HEIGHT, WIDTH

from .manager import Scene

# The layout was authored at 1280x720. Every absolute size below is scaled by S
# so it fits lower resolutions (e.g. 320x240 on a MiSTer CRT). S == 1 at 1280
# wide, so PC/web render byte-for-byte as before.
S = WIDTH / 1280.0

CARD_WIDTH = int(230 * S)
# Tall enough for both per-class mechanic lines (dodge and guard) to sit
# above the attributes without crowding them.
CARD_HEIGHT = int(336 * S)
CARD_SPACING = int(270 * S)
PORTRAIT_SCALE = max(1, round(3 * S))

BG_COLOR = 0x0D0B0E
CARD_FILL = 0x171320
CARD_FILL_SELECTED = 0x1F1A2B
CARD_BORDER = 0x3A3F4D


def _fs(px):
    """Font sizes are passed through raw; gfx.text scales every string for the
    display resolution globally, so scaling here too would shrink twice."""
    return px


class ClassSelectScene(Scene):
    def __init__(self, manager):
        super().__init__(manager)
        self.order = CLASS_ORDER
        self.selected_index = 0
        # Persists across visits to this screen (scene instances are reused).
        self.god_mode = False
        # The cards show each class head-on; the other two views only
        # matter once the body can turn, in the arena.
        self.portraits = {cid: create_pixel_surface(CLASS_SPRITES[cid].front, PORTRAIT_SCALE)
                          for cid in self.order}
        center_y = int(HEIGHT * 0.55)
        self.card_rects = []
        for index in range(len(self.order)):
            x = WIDTH // 2 + (index - 1) * CARD_SPACING
            rect = pygame.Rect(0, 0, CARD_WIDTH, CARD_HEIGHT)
            rect.center = (x, center_y)
            self.card_rects.append(rect)
        self.center_y = center_y
        gm_y = int(HEIGHT * 0.87)
        box = max(12, int(20 * S))
        self.god_box = pygame.Rect(0, 0, box, box)
        self.god_box.center = (int(WIDTH // 2 - 90 * S), gm_y)
        self.god_label_pos = (int(WIDTH // 2 - 72 * S), gm_y)

    def enter(self, **data):
        self.select(self.selected_index)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_LEFT, pygame.K_a):
                self.select(self.selected_index - 1)
            elif event.key in (pygame.K_RIGHT, pygame.K_d):
                self.select(self.selected_index + 1)
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.confirm()
            elif event.key == pygame.K_g:
                self.god_mode = not self.god_mode
        elif event.type == pygame.MOUSEMOTION:
            for i, rect in enumerate(self.card_rects):
                if rect.collidepoint(event.pos):
                    self.select(i)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.god_box.inflate(8, 8).collidepoint(event.pos) or \
                    self._god_label_rect().collidepoint(event.pos):
                self.god_mode = not self.god_mode
                return
            for i, rect in enumerate(self.card_rects):
                if rect.collidepoint(event.pos):
                    self.select(i)
                    self.confirm()
                    return

    def select(self, index):
        self.selected_index = index % len(self.order)

    def confirm(self):
        # game_mode lets a launcher pick which map/mode to enter (e.g. the light
        # 1v1 arena on MiSTer); defaults to the full boss-rush.
        self.manager.start('game', class_id=self.order[self.selected_index],
                           god_mode=self.god_mode,
                           mode=getattr(self, 'game_mode', 'bossmode'))

    def _god_label_rect(self):
        font = get_font(_fs(14))
        w, h = font.size('God mode (bosses have 1 HP)')
        return pygame.Rect(self.god_label_pos[0], self.god_label_pos[1] - h // 2, w, h)

    def draw(self, screen):
        # Low-res displays (MiSTer 240p) can't fit every class's full text in a
        # card without it overlapping, so there the cards are just portrait +
        # name and the selected class's details are laid out below the row.
        if S < 0.6:
            self._draw_compact(screen)
        else:
            self._draw_full(screen)

    def _draw_compact(self, screen):
        screen.fill(rgb(BG_COLOR))
        draw_text(screen, 'Sprite Souls 3', 30, 0xECF0F1,
                  WIDTH / 2, HEIGHT * 0.09, anchor='center', outline=3)

        n = len(self.order)
        row_y = HEIGHT * 0.30
        spacing = WIDTH / (n + 1)
        for i, class_id in enumerate(self.order):
            cls = CLASSES[class_id]
            cx = int(spacing * (i + 1))
            selected = i == self.selected_index
            portrait = self.portraits[class_id]
            pr = portrait.get_rect(center=(cx, int(row_y)))
            if selected:
                pygame.draw.rect(screen, rgb(cls.color), pr.inflate(10, 14), 2)
            screen.blit(portrait, pr)
            # Clear of the selection box's bottom edge (inflate(,14) -> +7px).
            draw_text(screen, cls.name, 16, cls.color if selected else 0xBDC3C7,
                      cx, pr.bottom + 13, anchor='center', outline=0)

        cls = CLASSES[self.order[self.selected_index]]
        y = HEIGHT * 0.55
        for line in wrap_lines(cls.description, 12, int(WIDTH * 0.9)):
            r = draw_text(screen, line, 12, 0xBDC3C7, WIDTH / 2, y, anchor='center', outline=0)
            y += r.height + 1
        y += 3
        r = draw_text(screen, f'Shift: {cls.dodge.name}    E: {cls.guard.name}',
                      12, cls.color, WIDTH / 2, y, anchor='center', outline=0)
        y += r.height + 2
        a = cls.base_attributes
        draw_text(screen, f'STR {a.strength}  DEX {a.dexterity}  '
                  f'INT {a.intelligence}  VIT {a.vitality}',
                  12, 0xECF0F1, WIDTH / 2, y, anchor='center', outline=0)

        hint = 'D-pad select    A start' + ('    god mode ON' if self.god_mode else '')
        draw_text(screen, hint, 12, 0x7F8C8D, WIDTH / 2, HEIGHT * 0.93,
                  anchor='center', outline=0)

    def _draw_full(self, screen):
        screen.fill(rgb(BG_COLOR))
        cy = self.center_y

        draw_text(screen, 'Sprite Souls 3', _fs(32), 0xECF0F1,
                  WIDTH / 2, HEIGHT * 0.16, anchor='center', outline=3)

        for i, class_id in enumerate(self.order):
            cls = CLASSES[class_id]
            rect = self.card_rects[i]
            selected = i == self.selected_index

            pygame.draw.rect(screen, rgb(CARD_FILL_SELECTED if selected else CARD_FILL), rect)
            pygame.draw.rect(screen, rgb(cls.color if selected else CARD_BORDER),
                             rect, max(1, round((3 if selected else 2) * S)))

            portrait = self.portraits[class_id]
            screen.blit(portrait, portrait.get_rect(center=(rect.centerx, int(cy - 75 * S))))

            draw_text(screen, cls.name, _fs(22), cls.color,
                      rect.centerx, cy + 5 * S, anchor='center')

            line_y = cy + 45 * S
            for line in wrap_lines(cls.description, _fs(12), CARD_WIDTH - int(30 * S)):
                r = draw_text(screen, line, _fs(12), 0xBDC3C7,
                              rect.centerx, line_y, anchor='center', outline=0)
                line_y += r.height

            # Each class dodges and guards differently, and there is
            # nowhere else to find that out except by dying to it.
            draw_text(screen, f'Shift: {cls.dodge.name}', _fs(12), cls.color,
                      rect.centerx, line_y + 4 * S, anchor='center', outline=0)
            draw_text(screen, f'E: {cls.guard.name}', _fs(12), cls.color,
                      rect.centerx, line_y + 22 * S, anchor='center', outline=0)

            a = cls.base_attributes
            draw_text(screen, f'STR {a.strength}  DEX {a.dexterity}', _fs(13), 0xECF0F1,
                      rect.centerx, cy + 128 * S, anchor='center', outline=0)
            draw_text(screen, f'INT {a.intelligence}  VIT {a.vitality}', _fs(13), 0xECF0F1,
                      rect.centerx, cy + 148 * S, anchor='center', outline=0)

        # God-mode checkbox.
        pygame.draw.rect(screen, rgb(CARD_FILL), self.god_box)
        pygame.draw.rect(screen, rgb(0x7F8C8D), self.god_box, max(1, round(2 * S)))
        if self.god_mode:
            pygame.draw.rect(screen, rgb(0xF1C40F), self.god_box.inflate(-int(8 * S), -int(8 * S)))
        draw_text(screen, 'God mode (bosses have 1 HP)', _fs(14), 0xBDC3C7,
                  self.god_label_pos[0], self.god_label_pos[1],
                  anchor='midleft', outline=0)

        draw_text(screen, '<- -> select   |   Enter or click to start   |   G god mode',
                  _fs(14), 0x7F8C8D, WIDTH / 2, HEIGHT * 0.94, anchor='center', outline=0)
