"""Boss 2: the ice dragon. A slow-turning heavyweight with an
ice-breath cone (pale-blue telegraph; hits freeze the player), a tail
sweep covering the arc BEHIND it, and a fast frontal claw swipe. Body
contact is harmless; it does not dodge. Its weakness is its turn rate:
strafe faster than it turns, but respect the tail.

Periodically it takes flight: the sprite grows, it swoops at high
speed over the player (body collision off), and radial rings of ice
shards burst outward on a cyan telegraph. While airborne it is out of
reach — no player attack lands until it descends into recover."""

import math
import random

from core.mathutil import angle_between, dist, lerp, rotate_to, wrap_angle
from core.units import PX, SECOND, UNIT
from gfx import camera
from gfx.pixelart import create_pixel_surface, scaled
from gfx.sprites import (DRAGON_CLAW_SPRITE, DRAGON_TAIL_SPRITE,
                         ICE_DRAGON_VIEWS, ICE_SHARD_SPRITE)
from scenes.effects import ArcTrail, LerpParticle, WeaponSweep

import pygame

from .boss import AreaHit, Boss

# Distances and speeds are world units (speeds per second); see core/units.
AGGRO_RANGE = 11.25 * UNIT
CHASE_SPEED = 2.5 * UNIT
# Radians per second — deliberately slow, so the player can circle behind
# it. Left in radians rather than fractions of core.units.TURN: 2.4 is
# not a clean fraction of a revolution, and rounding it to one would be a
# balance change dressed up as a unit conversion.
TURN_RATE = 2.4
# Vulnerable pause after an attack.
RECOVER_MS = 0.5 * SECOND
ATTACK_COOLDOWN_MS = 1.2 * SECOND

# Ice breath: forward cone that freezes the player solid on hit.
BREATH_WINDUP_MS = 0.55 * SECOND
BREATH_MS = 0.9 * SECOND
ICE_RANGE = 8.75 * UNIT
ICE_HALF_ARC = math.radians(45)
ICE_DAMAGE = 8
FREEZE_MS = 1 * SECOND

# Tail sweep: hits the arc BEHIND the dragon (facing + 180 degrees).
TAIL_WINDUP_MS = 0.4 * SECOND
TAIL_SWIPE_MS = 0.25 * SECOND
TAIL_RANGE = 3.4375 * UNIT
TAIL_HALF_ARC = math.radians(70)
TAIL_DAMAGE = 14
# Player counts as "behind" beyond this angle off the facing direction.
BEHIND_ANGLE = math.radians(100)

# Claw swipe: fast short-range melee across the frontal arc.
CLAW_WINDUP_MS = 0.35 * SECOND
CLAW_SWIPE_MS = 0.2 * SECOND
CLAW_RANGE = 2.8125 * UNIT
CLAW_HALF_ARC = math.radians(55)
CLAW_DAMAGE = 12

# Flight phase: the dragon takes off (sprite grows, shadow drops away),
# swoops at the player far faster than it can walk, and pulses radial
# rings of ice shards (cyan telegraph) the player has to dodge.
FLY_COOLDOWN_MS = 9 * SECOND
TAKEOFF_MS = 0.6 * SECOND
FLY_MS = 5.2 * SECOND
LAND_MS = 0.45 * SECOND
FLY_SPEED = 5.9375 * UNIT
FLY_TURN_RATE = 4.0            # rad/s, as TURN_RATE above
GROUND_SCALE = 2
FLY_SCALE = 2.6
BURST_INTERVAL_MS = 1.1 * SECOND
BURST_TELEGRAPH_MS = 0.3 * SECOND
BURST_SHARD_COUNT = 12
# Altitude at the top of a swoop. A SCREEN height, not a world distance —
# it is what sells flight as altitude rather than as a bigger sprite.
FLIGHT_LIFT = 78 * PX
# Heights on the dragon's body that attacks originate from. Screen
# heights too (it stands 2 UNIT tall at ground scale).
MOUTH_LIFT = 34 * PX
TAIL_LIFT = 12 * PX
SHARD_SPEED = 7.1875 * UNIT
SHARD_DAMAGE = 7
SHARD_HIT_RADIUS = 0.625 * UNIT
SHARD_MAX_DIST = 13.125 * UNIT


class _FlyingShard:
    __slots__ = ('x', 'y', 'vx', 'vy', 'traveled', 'alpha')

    def __init__(self, x, y, vx, vy):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.traveled = 0.0
        self.alpha = 1.0


class IceDragonBoss(Boss):
    display_name = 'Ice Dragon'

    def __init__(self, scene, x, y):
        super().__init__(scene, x, y, ICE_DRAGON_VIEWS,
                         scale=GROUND_SCALE, max_health=160, xp_reward=150)
        self.ai_state = 'idle'
        self.state_timer_ms = 0.0
        self.attack_cooldown_ms = 0.0
        # `facing_angle` comes from Boss — here it is the AI's heading as
        # well as the drawn one, so TURN_RATE is now visible: the body
        # swings round to the new side instead of just the hitboxes.
        self.breath_angle = 0.0
        self.tail_angle = 0.0
        self.claw_angle = 0.0
        self.shard_spawn_ms = 0.0
        self.fly_cooldown_ms = 6000.0
        self.burst_timer_ms = 0.0
        self.flight_height = 0.0  # 0 = grounded, 1 = fully airborne
        self.flying_shards = []
        self.shard_surf = create_pixel_surface(ICE_SHARD_SPRITE)
        self.tail_surf = create_pixel_surface(DRAGON_TAIL_SPRITE)
        self.claw_surf = create_pixel_surface(DRAGON_CLAW_SPRITE)

    @property
    def is_dodging(self):
        """Airborne = out of reach: no player attack can land until it does."""
        return self.ai_state in ('takeoff', 'fly', 'land')

    def update_ai(self, player_x, player_y, dt_ms):
        self.state_timer_ms -= dt_ms
        self.attack_cooldown_ms = max(0.0, self.attack_cooldown_ms - dt_ms)
        self.fly_cooldown_ms = max(0.0, self.fly_cooldown_ms - dt_ms)
        self.tint = None
        self._update_flying_shards(dt_ms)

        d = dist(self.x, self.y, player_x, player_y)
        to_player = angle_between(self.x, self.y, player_x, player_y)

        state = self.ai_state
        if state == 'idle':
            self.set_velocity(0, 0)
            if d <= AGGRO_RANGE:
                self.ai_state = 'chase'

        elif state == 'chase':
            # The dragon turns slowly — this is what makes its back reachable.
            self.facing_angle = rotate_to(self.facing_angle, to_player,
                                          TURN_RATE * (dt_ms / 1000))
            if d > 110:
                self.set_velocity(math.cos(self.facing_angle) * CHASE_SPEED,
                                  math.sin(self.facing_angle) * CHASE_SPEED)
            else:
                self.set_velocity(0, 0)  # close enough: turn in place

            if self.attack_cooldown_ms <= 0:
                if self.fly_cooldown_ms <= 0:
                    self.ai_state = 'takeoff'
                    self.state_timer_ms = TAKEOFF_MS
                    self._start_flight()
                    return
                off_facing = abs(wrap_angle(to_player - self.facing_angle))
                if off_facing >= BEHIND_ANGLE and d <= TAIL_RANGE + 40:
                    self.ai_state = 'tailwindup'
                    self.state_timer_ms = TAIL_WINDUP_MS
                elif off_facing <= math.radians(45):
                    # Player in front: pick randomly among the attacks in range.
                    options = []
                    if d <= ICE_RANGE + 20:
                        options.append('breathwindup')
                    if d <= CLAW_RANGE + 30:
                        options.append('clawwindup')
                    if options:
                        choice = random.choice(options)
                        self.ai_state = choice
                        self.state_timer_ms = (BREATH_WINDUP_MS if choice == 'breathwindup'
                                               else CLAW_WINDUP_MS)

        elif state == 'breathwindup':
            # Pale-blue flash: ice breath is coming.
            self.set_velocity(0, 0)
            if math.floor(self.state_timer_ms / 90) % 2 == 0:
                self.tint = 0x99DDFF
            if self.state_timer_ms <= 0:
                self.tint = None
                self.ai_state = 'breath'
                self.state_timer_ms = BREATH_MS
                # Direction locks here — stepping out of the cone dodges it.
                self.breath_angle = self.facing_angle
                self.shard_spawn_ms = 0.0

        elif state == 'breath':
            self.set_velocity(0, 0)
            self._spawn_ice_shards(dt_ms)
            if self.state_timer_ms <= 0:
                self._enter_recover()

        elif state == 'tailwindup':
            # White-blue flash: tail sweep behind it is coming.
            self.set_velocity(0, 0)
            if math.floor(self.state_timer_ms / 90) % 2 == 0:
                self.tint = 0xDFE9F2
            if self.state_timer_ms <= 0:
                self.tint = None
                self.ai_state = 'tailswipe'
                self.state_timer_ms = TAIL_SWIPE_MS
                # The tail covers the arc directly behind the dragon.
                self.tail_angle = self.facing_angle + math.pi
                self._play_tail_sweep()

        elif state == 'tailswipe':
            self.set_velocity(0, 0)
            if self.state_timer_ms <= 0:
                self._enter_recover()

        elif state == 'clawwindup':
            # Deep-blue flash: a fast frontal claw swipe is coming.
            self.set_velocity(0, 0)
            if math.floor(self.state_timer_ms / 90) % 2 == 0:
                self.tint = 0x5577FF
            if self.state_timer_ms <= 0:
                self.tint = None
                self.ai_state = 'clawswipe'
                self.state_timer_ms = CLAW_SWIPE_MS
                self.claw_angle = self.facing_angle
                self._play_claw_swipe()

        elif state == 'clawswipe':
            self.set_velocity(0, 0)
            if self.state_timer_ms <= 0:
                self._enter_recover()

        elif state == 'takeoff':
            self.set_velocity(0, 0)
            self._set_flight_height(1 - max(0.0, self.state_timer_ms) / TAKEOFF_MS)
            if self.state_timer_ms <= 0:
                self.ai_state = 'fly'
                self.state_timer_ms = FLY_MS
                self.burst_timer_ms = BURST_INTERVAL_MS

        elif state == 'fly':
            # Airborne: swoop at the player far faster than it can walk.
            self.facing_angle = rotate_to(self.facing_angle, to_player,
                                          FLY_TURN_RATE * (dt_ms / 1000))
            self.set_velocity(math.cos(self.facing_angle) * FLY_SPEED,
                              math.sin(self.facing_angle) * FLY_SPEED)
            self._set_flight_height(1)

            # Cyan flash: a radial shard ring is about to burst.
            self.burst_timer_ms -= dt_ms
            if self.burst_timer_ms <= BURST_TELEGRAPH_MS:
                if math.floor(self.burst_timer_ms / 90) % 2 == 0:
                    self.tint = 0x66FFEE
            if self.burst_timer_ms <= 0:
                self.tint = None
                self._fire_shard_ring()
                self.burst_timer_ms = BURST_INTERVAL_MS

            if self.state_timer_ms <= 0:
                self.tint = None
                self.ai_state = 'land'
                self.state_timer_ms = LAND_MS

        elif state == 'land':
            self.set_velocity(0, 0)
            self._set_flight_height(max(0.0, self.state_timer_ms) / LAND_MS)
            if self.state_timer_ms <= 0:
                self._end_flight()

        elif state == 'recover':
            # Vulnerable pause — the player's punish window.
            self.set_velocity(0, 0)
            if self.state_timer_ms <= 0:
                self.ai_state = 'chase'

    def on_stun(self):
        """Parried: drop the breath or the sweep it was winding up and
        come round in `recover`, on a fresh attack cooldown. Only ever
        reachable on the ground — airborne it counts as dodging, and
        nothing staggers what it cannot touch."""
        self._enter_recover()

    def poll_area_attack(self, player_x, player_y):
        d = dist(self.x, self.y, player_x, player_y)
        angle_to = angle_between(self.x, self.y, player_x, player_y)

        # Airborne shard rings: each shard is consumed on contact, even if
        # the player's i-frames veto the damage — dodging through is rewarded.
        for i in range(len(self.flying_shards) - 1, -1, -1):
            s = self.flying_shards[i]
            if dist(s.x, s.y, player_x, player_y) <= SHARD_HIT_RADIUS:
                del self.flying_shards[i]
                return AreaHit(damage=SHARD_DAMAGE)

        if self.ai_state == 'breath':
            if (d <= ICE_RANGE + 10
                    and abs(wrap_angle(angle_to - self.breath_angle)) <= ICE_HALF_ARC + 0.1):
                return AreaHit(damage=ICE_DAMAGE, freeze_ms=FREEZE_MS)

        if self.ai_state == 'tailswipe':
            if (d <= TAIL_RANGE + 16
                    and abs(wrap_angle(angle_to - self.tail_angle)) <= TAIL_HALF_ARC):
                return AreaHit(damage=TAIL_DAMAGE)

        if self.ai_state == 'clawswipe':
            if (d <= CLAW_RANGE + 16
                    and abs(wrap_angle(angle_to - self.claw_angle)) <= CLAW_HALF_ARC):
                return AreaHit(damage=CLAW_DAMAGE)

        return None

    def _play_claw_swipe(self):
        """Sweep the claw sprite through the frontal arc with a fading trail."""
        self.scene.add_effect(WeaponSweep(lambda: (self.x, self.y), self.claw_surf,
                                          self.claw_angle, CLAW_HALF_ARC,
                                          grip_radius=28, duration_ms=CLAW_SWIPE_MS,
                                          lift=MOUTH_LIFT))
        self.scene.add_effect(ArcTrail(self.x, self.y, CLAW_RANGE, self.claw_angle,
                                       CLAW_HALF_ARC, 0xCFE4F0, 0.25, 240))

    def _play_tail_sweep(self):
        """Sweep the tail sprite through the rear arc with a fading trail."""
        self.scene.add_effect(WeaponSweep(lambda: (self.x, self.y), self.tail_surf,
                                          self.tail_angle, TAIL_HALF_ARC,
                                          grip_radius=24, duration_ms=TAIL_SWIPE_MS,
                                          lift=TAIL_LIFT))
        self.scene.add_effect(ArcTrail(self.x, self.y, TAIL_RANGE, self.tail_angle,
                                       TAIL_HALF_ARC, 0x99DDFF, 0.25, 280))

    def _spawn_ice_shards(self, dt_ms):
        """Spray ice-shard particles across the breath cone."""
        self.shard_spawn_ms -= dt_ms
        while self.shard_spawn_ms <= 0:
            self.shard_spawn_ms += 40
            a = self.breath_angle + ICE_HALF_ARC * (random.random() * 2 - 1)
            reach = ICE_RANGE * (0.6 + random.random() * 0.4)
            self.scene.add_effect(LerpParticle(
                self.shard_surf,
                self.x + math.cos(a) * 26, self.y + math.sin(a) * 26,
                self.x + math.cos(a) * reach, self.y + math.sin(a) * reach,
                scale0=0.6 + random.random() * 0.5, scale1=1.3,
                duration_ms=340 + random.random() * 140,
                lift=MOUTH_LIFT + self.ground_lift,
            ))

    def _start_flight(self):
        self.set_velocity(0, 0)
        # Fly OVER the player instead of body-blocking them.
        self.collidable = False

    def _end_flight(self):
        self.scale = GROUND_SCALE
        self.flight_height = 0.0
        self.collidable = True
        self.fly_cooldown_ms = FLY_COOLDOWN_MS
        self._enter_recover()

    def _set_flight_height(self, p):
        """Altitude illusion: 0 = grounded, 1 = fully airborne."""
        self.flight_height = p
        self.scale = lerp(GROUND_SCALE, FLY_SCALE, p)

    def _fire_shard_ring(self):
        """Burst an evenly spaced ring of ice shards outward from the dragon."""
        offset = random.random() * math.pi * 2
        for i in range(BURST_SHARD_COUNT):
            a = offset + (math.pi * 2 * i) / BURST_SHARD_COUNT
            self.flying_shards.append(_FlyingShard(
                self.x + math.cos(a) * 20, self.y + math.sin(a) * 20,
                math.cos(a) * SHARD_SPEED, math.sin(a) * SHARD_SPEED,
            ))

    def _update_flying_shards(self, dt_ms):
        dt = dt_ms / 1000
        fade_start = SHARD_MAX_DIST * 0.7
        for i in range(len(self.flying_shards) - 1, -1, -1):
            s = self.flying_shards[i]
            s.x += s.vx * dt
            s.y += s.vy * dt
            s.traveled += SHARD_SPEED * dt
            if s.traveled > fade_start:
                s.alpha = 1 - (s.traveled - fade_start) / (SHARD_MAX_DIST - fade_start)
            if s.traveled >= SHARD_MAX_DIST:
                del self.flying_shards[i]

    def on_death(self):
        self.flying_shards = []

    @property
    def ground_lift(self):
        """Altitude in screen pixels. The base class draws the body this
        far above its shadow, which is what makes the swoop read as
        flight rather than as the dragon just getting bigger."""
        return self.flight_height * FLIGHT_LIFT

    def draw(self, target):
        super().draw(target)
        ring_surf = scaled(self.shard_surf, 0.9)
        for s in self.flying_shards:
            img = ring_surf
            if s.alpha < 1:
                img = ring_surf.copy()
                img.set_alpha(int(255 * max(0.0, s.alpha)))
            camera.blit_flat(target, img, s.x, s.y)

    def _enter_recover(self):
        self.ai_state = 'recover'
        self.state_timer_ms = RECOVER_MS
        self.attack_cooldown_ms = ATTACK_COOLDOWN_MS
