"""All game art, defined as text pixel maps — each character is a pixel,
'.' is transparent. Art is 32x32 (projectiles 16x16), rendered at 1x so
on-screen sizes and hitboxes are unchanged from the old 16x16-at-2x art.

Art direction is modelled on Blasphemous: penitential silhouettes
(capirote, mitre, deep cowl), a desaturated bone/sepia world lit from
above, near-black-but-never-pure-black outlines, and exactly one
saturated accent per sprite (crimson, or tarnished gold). Shared ramps
live in palette.py — new art should draw from it so the cast reads as
one world.

Every body is drawn five times — front, back, side, front-side and
back-side (all facing screen-right; the left-facing views are their
mirrors) — and bundled into a `DirectionalSprite`; gfx/facing.py picks
between them and animates the swap. The views share one palette dict per
character, so retuning a colour retunes every side of that body at once.
A side view is not the front view narrowed: it is a different
silhouette, roughly two thirds the width, and it must stay centred on
the same column or the body will appear to jump sideways as it turns.

One module per character, each holding that character's palette, its
five views and the art only that character uses (its weapon, its
projectiles). palette.py has the shared ramps; props.py has the art two
characters share; forest.py is the one module belonging to no character
at all — the scenery standing on the map. This package re-exports all of
it, so importers say `from gfx.sprites import DAGGER_SPRITE` and never
need to know which character owns what.

A weapon can be a separate sprite the scene moves (the thief's dagger
jabs, the devil's trident extends), painted into the body so the
character is armed standing still (the knight's sword and shield), or —
for the knight's sword — both: he carries it in his art, and for the
length of a swing the body drops to `CLASS_SWING_SPRITES` with an empty
hand while the scene sweeps `SWORD_SPRITE` through the arc. What is
never allowed is a weapon in two places at once.
"""

from .devil import (DEVIL_BACK_SIDE_SPRITE, DEVIL_BACK_SPRITE,
                    DEVIL_FRONT_SIDE_SPRITE, DEVIL_PALETTE,
                    DEVIL_SIDE_SPRITE, DEVIL_SPRITE, DEVIL_VIEWS,
                    TRIDENT_SPRITE)
from .forest import (BOULDER_SPRITE, DEAD_TREE_SPRITE, FERN_SPRITE,
                     FOREST_PALETTE, PINE_SPRITE, STUMP_SPRITE)
from .ice_dragon import (DRAGON_CLAW_SPRITE, DRAGON_TAIL_SPRITE,
                         ICE_DRAGON_BACK_SIDE_SPRITE,
                         ICE_DRAGON_BACK_SPRITE,
                         ICE_DRAGON_FRONT_SIDE_SPRITE, ICE_DRAGON_PALETTE,
                         ICE_DRAGON_SIDE_SPRITE, ICE_DRAGON_SPRITE,
                         ICE_DRAGON_VIEWS, ICE_SHARD_SPRITE)
from .knight import (KNIGHT_BACK_SIDE_SPRITE, KNIGHT_BACK_SPRITE,
                     KNIGHT_BLOCK_BACK_SIDE_SPRITE, KNIGHT_BLOCK_BACK_SPRITE,
                     KNIGHT_BLOCK_FRONT_SIDE_SPRITE, KNIGHT_BLOCK_SIDE_SPRITE,
                     KNIGHT_BLOCK_SPRITE, KNIGHT_BLOCK_VIEWS,
                     KNIGHT_FRONT_SIDE_SPRITE, KNIGHT_PALETTE,
                     KNIGHT_SIDE_SPRITE, KNIGHT_SPRITE,
                     KNIGHT_SWING_BACK_SIDE_SPRITE, KNIGHT_SWING_BACK_SPRITE,
                     KNIGHT_SWING_FRONT_SIDE_SPRITE, KNIGHT_SWING_SIDE_SPRITE,
                     KNIGHT_SWING_SPRITE, KNIGHT_SWING_VIEWS, KNIGHT_VIEWS,
                     SHIELD_BACK_SPRITE, SHIELD_PALETTE, SHIELD_SPRITE,
                     SWORD_SPRITE)
from .palette import (BONE, BONE_DEEP, BONE_LIT, BONE_SPEC, CRIMSON,
                      CRIMSON_DEEP, CRIMSON_LIT, EMBER, GOLD, GOLD_DEEP,
                      GOLD_SPEC, HOLLOW, SEPIA, SEPIA_DEEP, SEPIA_LIT,
                      SEPIA_MID, VOID, VOID_COLD)
from .props import FIREBALL_SPRITE
from .sorcerer import (SORCERER_BACK_SIDE_SPRITE, SORCERER_BACK_SPRITE,
                       SORCERER_FRONT_SIDE_SPRITE, SORCERER_PALETTE,
                       SORCERER_SIDE_SPRITE, SORCERER_SPRITE,
                       SORCERER_VIEWS)
from .thief import (DAGGER_SPRITE, THIEF_BACK_SIDE_SPRITE,
                    THIEF_BACK_SPRITE, THIEF_FRONT_SIDE_SPRITE,
                    THIEF_PALETTE, THIEF_SIDE_SPRITE, THIEF_SPRITE,
                    THIEF_SWING_BACK_SIDE_SPRITE, THIEF_SWING_BACK_SPRITE,
                    THIEF_SWING_FRONT_SIDE_SPRITE, THIEF_SWING_SIDE_SPRITE,
                    THIEF_SWING_SPRITE, THIEF_SWING_VIEWS, THIEF_VIEWS)

# Player art for each character class, all eight views of it.
CLASS_SPRITES = {
    'knight': KNIGHT_VIEWS,
    'sorcerer': SORCERER_VIEWS,
    'thief': THIEF_VIEWS,
}

# The body to draw for the length of a swing, for classes that carry
# their weapon in their art: the same views with the weapon hand empty,
# because the scene is busy sweeping that weapon through the arc. A class
# absent from here keeps its usual body throughout — which is right for
# anyone whose weapon was never painted on in the first place.
CLASS_SWING_SPRITES = {
    'knight': KNIGHT_SWING_VIEWS,
    'thief': THIEF_SWING_VIEWS,
}

# The same idea for the guard: the body with the shield arm empty, drawn
# while the scene holds that shield up in front of the character.
CLASS_GUARD_SPRITES = {
    'knight': KNIGHT_BLOCK_VIEWS,
}

__all__ = [
    'CLASS_SPRITES', 'CLASS_SWING_SPRITES', 'CLASS_GUARD_SPRITES',
    # shared ramps
    'VOID', 'VOID_COLD', 'HOLLOW',
    'BONE_DEEP', 'BONE', 'BONE_LIT', 'BONE_SPEC',
    'GOLD_DEEP', 'GOLD', 'GOLD_SPEC',
    'CRIMSON_DEEP', 'CRIMSON', 'CRIMSON_LIT',
    'SEPIA_DEEP', 'SEPIA_MID', 'SEPIA', 'SEPIA_LIT',
    'EMBER',
    # knight
    'KNIGHT_PALETTE', 'KNIGHT_SPRITE', 'KNIGHT_BACK_SPRITE',
    'KNIGHT_SIDE_SPRITE', 'KNIGHT_FRONT_SIDE_SPRITE',
    'KNIGHT_BACK_SIDE_SPRITE', 'KNIGHT_VIEWS',
    'SWORD_SPRITE', 'SHIELD_PALETTE', 'SHIELD_SPRITE', 'SHIELD_BACK_SPRITE',
    'KNIGHT_SWING_SPRITE', 'KNIGHT_SWING_BACK_SPRITE',
    'KNIGHT_SWING_SIDE_SPRITE', 'KNIGHT_SWING_FRONT_SIDE_SPRITE',
    'KNIGHT_SWING_BACK_SIDE_SPRITE', 'KNIGHT_SWING_VIEWS',
    'KNIGHT_BLOCK_SPRITE', 'KNIGHT_BLOCK_BACK_SPRITE',
    'KNIGHT_BLOCK_SIDE_SPRITE', 'KNIGHT_BLOCK_FRONT_SIDE_SPRITE',
    'KNIGHT_BLOCK_BACK_SIDE_SPRITE', 'KNIGHT_BLOCK_VIEWS',
    # sorcerer
    'SORCERER_PALETTE', 'SORCERER_SPRITE', 'SORCERER_BACK_SPRITE',
    'SORCERER_SIDE_SPRITE', 'SORCERER_FRONT_SIDE_SPRITE',
    'SORCERER_BACK_SIDE_SPRITE', 'SORCERER_VIEWS',
    # thief
    'THIEF_PALETTE', 'THIEF_SPRITE', 'THIEF_BACK_SPRITE',
    'THIEF_SIDE_SPRITE', 'THIEF_FRONT_SIDE_SPRITE',
    'THIEF_BACK_SIDE_SPRITE', 'THIEF_VIEWS', 'DAGGER_SPRITE',
    'THIEF_SWING_SPRITE', 'THIEF_SWING_BACK_SPRITE',
    'THIEF_SWING_SIDE_SPRITE', 'THIEF_SWING_FRONT_SIDE_SPRITE',
    'THIEF_SWING_BACK_SIDE_SPRITE', 'THIEF_SWING_VIEWS',
    # devil
    'DEVIL_PALETTE', 'DEVIL_SPRITE', 'DEVIL_BACK_SPRITE',
    'DEVIL_SIDE_SPRITE', 'DEVIL_FRONT_SIDE_SPRITE',
    'DEVIL_BACK_SIDE_SPRITE', 'DEVIL_VIEWS', 'TRIDENT_SPRITE',
    # ice dragon
    'ICE_DRAGON_PALETTE', 'ICE_DRAGON_SPRITE', 'ICE_DRAGON_BACK_SPRITE',
    'ICE_DRAGON_SIDE_SPRITE', 'ICE_DRAGON_FRONT_SIDE_SPRITE',
    'ICE_DRAGON_BACK_SIDE_SPRITE', 'ICE_DRAGON_VIEWS',
    'DRAGON_TAIL_SPRITE', 'DRAGON_CLAW_SPRITE', 'ICE_SHARD_SPRITE',
    # shared props
    'FIREBALL_SPRITE',
    # the forest itself
    'FOREST_PALETTE', 'PINE_SPRITE', 'DEAD_TREE_SPRITE', 'BOULDER_SPRITE',
    'STUMP_SPRITE', 'FERN_SPRITE',
]
