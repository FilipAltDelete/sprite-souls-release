"""Sound effects: load at startup, play by name.

Clips live next to this module, each as an .ogg *and* the .wav it was
encoded from — hence stems here rather than filenames. OGG is tried
first because the web build ships nothing else (pygbag refuses to pack
wav/mp3/aiff at all), and the .wav is the fallback for any platform
whose SDL_mixer was built without vorbis. Paths resolve for both a
normal checkout and a PyInstaller onefile bundle (sys._MEIPASS).
Missing or unloadable clips are skipped — the game stays quiet, not
broken. Load everything here at init time; do not open files mid-fight.
"""

from __future__ import annotations

import os
import sys

import pygame

# Logical name → filename stem under this package directory.
_CLIPS = {
    'swing': 'Swing',
    'knife': 'Knife slice_5',
    'sword': 'Sword',
    'fire_spell': 'Fire spell 9',
    'fire_hit': 'Fire spell 7',
}

# Preference order, best-supported-everywhere last.
_FORMATS = ('.ogg', '.wav')

_sounds: dict[str, pygame.mixer.Sound] = {}


def _dir() -> str:
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, 'sfx')
    return os.path.dirname(os.path.abspath(__file__))


def init() -> None:
    """Call once after pygame.init(). Idempotent."""
    if _sounds:
        return
    if os.environ.get("SS_HEADLESS"):   # authoritative server: no audio device
        return
    if pygame.mixer.get_init() is None:
        try:
            pygame.mixer.init()
        except pygame.error:
            return
    root = _dir()
    for name, stem in _CLIPS.items():
        for suffix in _FORMATS:
            path = os.path.join(root, stem + suffix)
            try:
                _sounds[name] = pygame.mixer.Sound(path)
                break
            except (pygame.error, FileNotFoundError):
                continue


def play(name: str) -> None:
    sound = _sounds.get(name)
    if sound is not None:
        sound.play()
