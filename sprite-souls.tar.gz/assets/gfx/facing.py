"""Directional bodies: eight views of each character, and the short
animation that carries a body from one to the next.

The simulation still knows nothing about any of this. A `Turner` is fed
the same world-space heading combat already uses (`facing_angle`), maps
it to one of eight views, and on a change squashes the sprite
horizontally and opens it out on the new side. Two frames of squash sell
"the model turned" far better than a hard cut does, and it costs one
extra scale per frame.

Which world direction is which view follows the camera: +y is *toward*
the viewer (see gfx/camera.py), so a heading of +pi/2 is the front view
and -pi/2 is the back. Only five pixel maps are drawn per character —
front, back, side, front-side and back-side. The three that face
screen-right are mirrored for their left counterparts, so eight views
cost five maps.

A turn always advances one 45-degree sector at a time, and both its
duration and how far it squashes scale with the angle actually covered.
That keeps a 180-degree spin the same length whether it is walked in
eight sectors or four, and it means a body with no diagonal art (which
falls back to its nearest cardinal) still turns with the deep 90-degree
squash rather than a shallow one that would not read.
"""

import math
from dataclasses import dataclass
from typing import Dict, Optional

import pygame

from core.mathutil import wrap_angle

from .pixelart import PixelSprite, create_pixel_surface, flipped

# How long a *quarter* turn takes; a turn covering less takes
# proportionally less. Long enough to read as a rotation, short enough
# that it never gets in the way of the player's sense of control — a
# body that took longer than this to come round would feel like lag.
TURN_MS_PER_QUARTER = 130.0
# The sprite never squashes to literally nothing: one column of pixels
# keeps a body from popping out of existence mid-turn.
MIN_SQUASH = 0.06
# One view's share of the compass.
SECTOR = math.pi / 4
# How far past a sector boundary the heading must travel before the view
# flips. Without it, a heading resting on a boundary strobes between two
# views. Scaled to the sector: half what it was when views were 90 apart.
HYSTERESIS = math.radians(7)

_CENTERS = {
    'right': 0.0,
    'front_right': math.pi / 4,
    'front': math.pi / 2,       # +y is toward the camera, so this faces us
    'front_left': 3 * math.pi / 4,
    'left': math.pi,
    'back_left': -3 * math.pi / 4,
    'back': -math.pi / 2,
    'back_right': -math.pi / 4,
}
# The compass in order of increasing heading — used to find runs of
# sectors that share one surface.
_ORDER = ('right', 'front_right', 'front', 'front_left',
          'left', 'back_left', 'back', 'back_right')


@dataclass(frozen=True)
class DirectionalSprite:
    """The pixel maps a body needs. `side`, `front_side` and `back_side`
    all face screen-right and are mirrored for the left half of the
    compass. The two diagonals are optional: leave them out and the body
    falls back to a four-view turn (see `create_views`)."""
    front: PixelSprite
    back: PixelSprite
    side: PixelSprite
    front_side: Optional[PixelSprite] = None   # three-quarters toward us
    back_side: Optional[PixelSprite] = None    # three-quarters away


_view_cache: Dict[tuple, Dict[str, pygame.Surface]] = {}


def create_views(sprite, pixel_size: int = 1) -> Dict[str, pygame.Surface]:
    """Render a DirectionalSprite into a surface per view.

    Missing art degrades rather than breaking: a body with no diagonal
    maps points its diagonal views at the neighbouring cardinal
    *surface*, and `Turner` skips any step whose art it is already
    showing — so it turns like a four-view body instead of squashing for
    a change nobody can see. A plain PixelSprite is accepted too and
    faces the same way from every angle, which is how new art can land
    front-first.
    """
    key = (id(sprite), pixel_size)
    cached = _view_cache.get(key)
    if cached is not None:
        return cached

    if isinstance(sprite, DirectionalSprite):
        views = {
            'front': create_pixel_surface(sprite.front, pixel_size),
            'back': create_pixel_surface(sprite.back, pixel_size),
            'right': create_pixel_surface(sprite.side, pixel_size),
        }
        views['left'] = flipped(views['right'])
        for diagonal, art, fallback in (('front', sprite.front_side, 'front'),
                                        ('back', sprite.back_side, 'back')):
            if art is None:
                views[f'{diagonal}_right'] = views[f'{diagonal}_left'] = views[fallback]
            else:
                views[f'{diagonal}_right'] = create_pixel_surface(art, pixel_size)
                views[f'{diagonal}_left'] = flipped(views[f'{diagonal}_right'])
    else:
        surf = create_pixel_surface(sprite, pixel_size)
        views = {name: surf for name in _CENTERS}

    _view_cache[key] = views
    return views


def direction_for_angle(angle: float, current: Optional[str] = None) -> str:
    """The sector a heading falls in. `current` gets a small head start
    so a heading resting on a boundary keeps the view it already had
    instead of flickering between the two it sits between."""
    best, best_off = current or 'front', math.inf
    for name, center in _CENTERS.items():
        off = abs(wrap_angle(angle - center))
        if name == current:
            off -= HYSTERESIS
        if off < best_off:
            best_off, best = off, name
    return best


def _direction_at(angle: float) -> str:
    return min(_CENTERS, key=lambda name: abs(wrap_angle(angle - _CENTERS[name])))


_centre_cache: Dict[int, Dict[str, float]] = {}


def _art_centres(views: Dict[str, pygame.Surface]) -> Dict[str, float]:
    """The middle of each *run* of sectors that share one surface.

    For a body with all five maps every run is one sector wide and this
    is just `_CENTERS`. For one missing its diagonals, the front surface
    spans three sectors, and a turn out of it covers the 90 degrees it
    really does — so it squashes deep and takes as long as it used to,
    instead of the 45 the sector grid alone would suggest.
    """
    cached = _centre_cache.get(id(views))
    if cached is not None:
        return cached

    n = len(_ORDER)
    centres = {}
    for i, name in enumerate(_ORDER):
        surf = views[name]
        lo = hi = 0
        while lo + hi + 1 < n and views[_ORDER[(i - lo - 1) % n]] is surf:
            lo += 1
        while lo + hi + 1 < n and views[_ORDER[(i + hi + 1) % n]] is surf:
            hi += 1
        centres[name] = wrap_angle(_CENTERS[name] + (hi - lo) * SECTOR / 2)
    _centre_cache[id(views)] = centres
    return centres


def _step_toward(shown: str, target: str, angle: float) -> str:
    """One sector from `shown` toward `target`. When the two are dead
    opposite the heading breaks the tie — picking a side arbitrarily
    would sometimes spin the body the long way round."""
    delta = wrap_angle(_CENTERS[target] - _CENTERS[shown])
    if abs(delta) <= SECTOR + 1e-6:
        return target
    if abs(abs(delta) - math.pi) < 1e-6:
        delta = wrap_angle(angle - _CENTERS[shown]) or 1.0
    return _direction_at(_CENTERS[shown] + math.copysign(SECTOR, delta))


class Turner:
    """Which view of a body is on screen, and the squash that carries it
    to the next one.

    Feed `update()` a world heading every frame; draw `surface()`
    horizontally scaled by `squash`.
    """

    def __init__(self, views: Dict[str, pygame.Surface], direction: str = 'front'):
        self.views = views
        self._centres = _art_centres(views)
        self.shown = direction
        self.target = direction
        self._pending = direction
        self._t = 1.0                          # turn progress; 1 = settled
        self._depth = MIN_SQUASH               # how narrow this turn gets
        self._duration = TURN_MS_PER_QUARTER

    @property
    def turning(self) -> bool:
        return self._t < 1.0

    def update(self, angle: float, dt_ms: float) -> None:
        self.target = direction_for_angle(angle, self.target)

        if self.turning:
            self._t += dt_ms / self._duration
            if self._t >= 0.5:
                # Halfway: the body is at its narrowest, so this is where
                # swapping the art costs the least.
                self.shown = self._pending
            if self._t < 1.0:
                return
            self._t = 1.0

        if self.target != self.shown:
            self._begin(angle)

    def _begin(self, angle: float) -> None:
        """Start the next leg of a turn, one sector at a time. Steps whose
        art is identical to what is already shown are taken silently — a
        body with no diagonal maps must not squash for a change nobody
        can see — and the leg that does move is measured between the art
        runs (see `_art_centres`), so it squashes as deep as the angle it
        actually covers."""
        while self.target != self.shown:
            pending = _step_toward(self.shown, self.target, angle)
            if self.views[pending] is self.views[self.shown]:
                self.shown = pending
                continue
            step = abs(wrap_angle(self._centres[pending] - self._centres[self.shown]))
            self._pending = pending
            self._depth = max(MIN_SQUASH, math.cos(step))
            self._duration = TURN_MS_PER_QUARTER * step / (math.pi / 2)
            self._t = 0.0
            return

    @property
    def squash(self) -> float:
        """Horizontal scale for this frame: 1 settled, `_depth` mid-turn."""
        if not self.turning:
            return 1.0
        return self._depth + (1 - self._depth) * abs(math.cos(math.pi * self._t))

    def surface(self, views: Optional[Dict[str, pygame.Surface]] = None) -> pygame.Surface:
        """The view on screen. Pass an alternate set of the *same* body —
        the knight's empty-handed swing art — to draw it instead without
        disturbing the turn: the view key is the one this Turner already
        settled on, only the art under it differs, so a swing can start
        and end mid-turn without interrupting it."""
        return (views or self.views)[self.shown]

    def face_now(self, angle: float) -> None:
        """Snap to a heading with no animation — spawning, respawning."""
        self.shown = self.target = self._pending = direction_for_angle(angle)
        self._t = 1.0
