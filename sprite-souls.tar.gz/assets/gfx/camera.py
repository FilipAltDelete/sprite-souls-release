"""The tilted camera — the Diablo-style "look down at the ground at an
angle" view.

Gameplay happens on a flat world plane with plain (x, y) coordinates and
circular hitboxes, exactly as before. Nothing in the simulation knows
the camera exists. Only *drawing* goes through `project()`, which
foreshortens the world's depth axis so the plane recedes up the screen.

The projection is deliberately **oblique** (screen_x == world_x) rather
than a true 45-degree isometric rotation. That choice matters:

- WASD stays honest — W really is "away from the camera".
- Every angle, cone, sweep and hit check keeps working in unrotated
  world space, so combat geometry needed no changes at all.
- A world circle on the ground still projects to a correct ellipse, so
  arcs and shadows land exactly where their hit checks are.

The isometric *read* comes from the diamond floor tiling and from
ground-plane circles becoming ellipses — not from rotating the world.

The world is larger than the view, so the camera also *scrolls* — see
"the framing" below. That is still only drawing: `project()` takes the
scroll off and `unproject()` puts it back, and because every other way
to put something on screen is built on those two, nothing else in the
codebase had to learn that the view can move.

Two ways to place a sprite, and picking the wrong one is the usual bug:
`blit_standing` for anything that stands up out of the plane (bodies —
feet at the ground point, body extending up the screen), `blit_flat` for
anything lying on or flying over it (projectiles, decals).
"""

import math
from typing import Dict, Tuple

import pygame

from . import platform
from core.units import PX, SECOND
from settings import CAMERA_TILT as TILT
from settings import HEIGHT, WIDTH, WORLD_H, WORLD_W

# --- the framing ------------------------------------------------------

# How much out-of-bounds floor stays in frame past the arena's edge once
# the view is pinned against it. Screen heights, not world distances:
# they are margins on the picture, not ground anybody stands on. The deep
# band at the top is what the plane recedes into (and what the HUD and a
# boss's name sit over); without them the world would simply stop at the
# edge of the screen and the boundary would be invisible.
MARGIN_TOP = 120 * PX
MARGIN_BOTTOM = 60 * PX
MARGIN_SIDE = 96 * PX

# Where world y=0 lands before any scrolling. It is the top margin, so
# that a view scrolled all the way back sits at scroll y = 0 — the number
# itself means nothing else now that the camera moves.
ORIGIN_Y = MARGIN_TOP

# How close to the edge of the view the followed point may get before the
# view starts moving: roughly a third of the way in from each side,
# leaving a dead zone of the middle two fifths. Measured on SCREEN rather
# than on the plane, because it is about how much the player can see
# ahead of themselves — and since the depth axis is foreshortened, the
# same fraction is a longer walk north-south than east-west.
DEADZONE = 0.30

# How fast the view closes on where it wants to be: it covers
# 1 - exp(-dt/FOLLOW_LAG) of the gap each frame. Short enough that
# walking out to the dead zone's edge reads as pushing the view rather
# than dragging it, long enough that a blink across half the arena pans
# instead of cutting.
FOLLOW_LAG = 0.09 * SECOND

# The plane's own footprint in this projection, before the scroll is
# taken off. `screen_bounds()` is where it actually is this frame;
# everything outside it is floor the player cannot reach.
BOUNDS = pygame.Rect(0, round(ORIGIN_Y), round(WORLD_W), round(WORLD_H * TILT))

# How far a standing sprite's feet sink into its ground shadow, so bodies
# read as planted on the plane rather than balanced on top of it.
FOOT_SINK = 3

# Where the view is, in screen pixels across and down the projected
# plane. Kept as floats because the follow closes a *fraction* of the gap
# each frame and the remainder has to accumulate...
_scroll_x = 0.0
_scroll_y = 0.0
# ...and applied as whole pixels, because the floor is a repeating patch
# blitted at integer positions while the bodies standing on it are placed
# by rounded projections. A camera on a half pixel slides those two
# against each other and the tiling visibly swims under everyone's feet.
_ox = 0
_oy = 0


def project(wx: float, wy: float) -> Tuple[float, float]:
    """World plane -> screen."""
    return wx - _ox, wy * TILT + ORIGIN_Y - _oy


def unproject(sx: float, sy: float) -> Tuple[float, float]:
    """Screen -> world plane. Used to aim the mouse at the ground."""
    return sx + _ox, (sy + _oy - ORIGIN_Y) / TILT


def scroll() -> Tuple[int, int]:
    """The applied scroll, in whole screen pixels — what the floor tiles
    itself against."""
    return _ox, _oy


def screen_bounds() -> pygame.Rect:
    """The arena's footprint on screen this frame."""
    return BOUNDS.move(-_ox, -_oy)


def follow(wx: float, wy: float, dt_ms: float) -> None:
    """Keep a world point inside the dead zone.

    The view only ever moves because the point pushed a wall of that
    zone, and only by as far as it was pushed — "the view starts
    scrolling a fifth of the way in from the edge" is this function and
    nothing else.

    What it deliberately does not do is move the point. Where the view is
    allowed to look is the camera's own business (`_clamp`), so once it
    is pinned against the edge of the world the player simply keeps
    walking — out of the dead zone, on into the corner of the screen and
    all the way to the world's edge. That is exactly why movement is
    clamped to the WORLD and never to the view: a camera that has run out
    of room must not take the last stretch of the arena with it."""
    global _scroll_x, _scroll_y
    sx, sy = wx - _scroll_x, wy * TILT + ORIGIN_Y - _scroll_y
    target_x, target_y = _clamp(_scroll_x + _push(sx, WIDTH),
                                _scroll_y + _push(sy, HEIGHT))
    # Exponential rather than a fixed fraction per frame, so the pan
    # takes the same time however the loop's dt lands.
    k = 1 - math.exp(-dt_ms / FOLLOW_LAG)
    _scroll_x += (target_x - _scroll_x) * k
    _scroll_y += (target_y - _scroll_y) * k
    _apply()


def snap_to(wx: float, wy: float) -> None:
    """Put the view where it would settle looking at this point, with no
    travel at all — entering the scene, and respawning, where a pan back
    across the arena would read as a move the player never made."""
    global _scroll_x, _scroll_y
    _scroll_x, _scroll_y = _clamp(wx - WIDTH / 2,
                                  wy * TILT + ORIGIN_Y - HEIGHT / 2)
    _apply()


def _push(s: float, extent: float) -> float:
    """How far the view has to move on one axis to bring a screen
    coordinate back inside the dead zone — zero while it is already
    inside, which is the point: the view holds perfectly still for
    everything that happens in the middle of the frame."""
    margin = extent * DEADZONE
    if s < margin:
        return s - margin
    if s > extent - margin:
        return s - (extent - margin)
    return 0.0


def _clamp(sx: float, sy: float) -> Tuple[float, float]:
    """Hold the view inside the world plus its margins, so it never pans
    off into blank space."""
    return (_clamp_axis(sx, -MARGIN_SIDE, WORLD_W + MARGIN_SIDE - WIDTH),
            _clamp_axis(sy, ORIGIN_Y - MARGIN_TOP,
                        ORIGIN_Y + WORLD_H * TILT + MARGIN_BOTTOM - HEIGHT))


def _clamp_axis(v: float, lo: float, hi: float) -> float:
    # A world narrower than the view on this axis has no scrolling left
    # to do: centre it and stay there, which is what the fixed camera
    # this grew out of did.
    if lo >= hi:
        return (lo + hi) / 2
    return min(max(v, lo), hi)


def _apply() -> None:
    global _ox, _oy
    _ox, _oy = round(_scroll_x), round(_scroll_y)


def project_angle(a: float) -> float:
    """A heading on the plane -> the direction it appears to point on
    screen. Anything drawn rotated (weapons) needs this; anything that
    only *reasons* about direction must keep using the world angle."""
    return math.atan2(math.sin(a) * TILT, math.cos(a))


def flatten(surf: pygame.Surface) -> pygame.Surface:
    """Squash a surface drawn in world units down onto the ground plane,
    turning world circles into correctly-foreshortened ellipses."""
    h = max(1, round(surf.get_height() * TILT))
    return pygame.transform.scale(surf, (surf.get_width(), h))


_shadow_cache: Dict[tuple, pygame.Surface] = {}


def ground_shadow(radius: float, alpha: int = 110) -> pygame.Surface:
    key = (round(radius), alpha)
    surf = _shadow_cache.get(key)
    if surf is None:
        w = max(2, round(radius * 2))
        h = max(2, round(radius * 2 * TILT))
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, (0, 0, 0, alpha), (0, 0, w, h))
        _shadow_cache[key] = surf
    return surf


def blit_shadow(target: pygame.Surface, wx: float, wy: float,
                radius: float, alpha: int = 110) -> None:
    """The contact shadow every body casts at its feet. Without these a
    tilted view just looks like sprites floating in soup."""
    surf = ground_shadow(radius, alpha)
    sx, sy = project(wx, wy)
    target.blit(surf, surf.get_rect(center=(round(sx), round(sy))),
                special_flags=platform.ALPHA_BLIT)


def blit_standing(target: pygame.Surface, surf: pygame.Surface,
                  wx: float, wy: float, lift: float = 0.0) -> pygame.Rect:
    """Draw a body upright on the plane: feet at its ground point, body
    extending up the screen. `lift` raises it off the ground in screen
    pixels (the dragon in flight)."""
    sx, sy = project(wx, wy)
    return target.blit(surf, surf.get_rect(
        midbottom=(round(sx), round(sy - lift + FOOT_SINK))),
        special_flags=platform.ALPHA_BLIT)


def blit_body(target: pygame.Surface, surf: pygame.Surface,
              wx: float, wy: float, lift: float = 0.0,
              leaning: bool = False) -> pygame.Rect:
    """Draw a standing body, upright or mid-stride.

    Upright it is placed by its feet, like anything else that stands.
    Leaning, `pixelart.tilted()` has rocked it about those feet and
    handed back a canvas built around them, so it is placed by that
    canvas's centre instead — a leaning body still stands where its feet
    are. The caller passes the same answer it used to build the surface;
    working it out from the surface size would be a lie waiting to
    happen."""
    if not leaning:
        return blit_standing(target, surf, wx, wy, lift)
    sx, sy = project(wx, wy)
    return target.blit(surf, surf.get_rect(
        center=(round(sx), round(sy - lift + FOOT_SINK))),
        special_flags=platform.ALPHA_BLIT)


def standing_top(wy: float, height: float, lift: float = 0.0) -> float:
    """Screen y of the top of a sprite placed by `blit_standing` — for
    hanging things above it (health bars)."""
    return project(0, wy)[1] - lift + FOOT_SINK - height


def blit_flat(target: pygame.Surface, surf: pygame.Surface,
              wx: float, wy: float, lift: float = 0.0) -> pygame.Rect:
    """Draw something centred on its ground point rather than standing on
    it — projectiles, decals, particles."""
    sx, sy = project(wx, wy)
    return target.blit(surf, surf.get_rect(center=(round(sx), round(sy - lift))),
                       special_flags=platform.ALPHA_BLIT)
