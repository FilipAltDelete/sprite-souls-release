"""The forest itself — the scenery standing on the plane.

The one module here that belongs to no character. Everything else in
this package is one module per body plus the gear only that body
carries; this is the exception, because a tree belongs to the map rather
than to anyone fighting on it. Anything else that furnishes the world
(rocks, ruins, bones) goes here too.

These are the props `core/obstacles.py` scatters and `GameScene` draws,
and the two files meet at the **kind name**: `core` decides that a
'pine' stops a 0.6-unit circle, this module decides what a pine looks
like, and `GameScene.PROP_ART` joins them. Adding a kind means all
three.

They are taller than they are wide and much taller than 32 — a body is
32x32 because its hitbox is derived from that, and nothing here derives
anything from its art. What each one *does* stand on is its bottom row:
props are placed by `camera.blit_standing`, so the foot of the trunk is
the last row and it is centred on the sprite's middle column, or the
tree will not stand where its collision circle is.

Art direction is the cast's: no pure black, warm near-black outlines,
light from the upper left, three or four tones ramped across a form
rather than a flat fill with a rim. The one saturated accent per sprite
is pale dead wood (`BONE_DEEP`) — bare heartwood where the bark has come
off, a dead limb in the skirt of a fir. Nothing in this world is green
and alive enough to earn a brighter one.
"""

from ..pixelart import PixelSprite
from .palette import BONE_DEEP, HOLLOW, SEPIA_DEEP, SEPIA_MID, VOID

FOREST_PALETTE = {
    'd': VOID,          # outline, warm near-black
    'k': HOLLOW,        # the dark under a bough — deeper than any outline
    # The needle ramp. Kept a step brighter than the loam it stands on
    # (see ARENA_* in scenes/game.py): a fir the exact value of the floor
    # is a silhouette with no form in it, and this cast is already dark.
    'N': 0x44562F,      # needle, lit
    'n': 0x2E3D22,      # needle, mid
    'm': 0x1C2615,      # needle, deep
    'T': SEPIA_MID,     # bark, lit
    't': SEPIA_DEEP,    # bark, mid
    'u': 0x1B1610,      # bark, shade
    'B': BONE_DEEP,     # bare heartwood / dead limbs — the accent
    'S': 0x53525C,      # stone, lit
    's': 0x3A3A42,      # stone, mid
    'v': 0x24242B,      # stone, deep
    'G': 0x33421F,      # moss on the lit shoulder of a rock
}

# 32x56 fir. The boughs read as strokes drooping *down and out* from the
# trunk rather than as stacked horizontal tiers — that diagonal is the
# whole silhouette: the same phase that darkens the underside of a bough
# also scallops the edge where its tip sticks out. Tiers drawn as
# horizontal bands read as a pile of pancakes at this size.
PINE_SPRITE = PixelSprite(
    palette=FOREST_PALETTE,
    rows=(
        '.............NNNNnm.............',
        '.............Nmkkkn.............',
        '.............mnmmkk.............',
        '.............nnnnkk.............',
        '.............NNnnmm.............',
        '............NNNNNNmm............',
        '............NNmkkknn............',
        '...........mmmnmmmkk............',
        '............nnnnnmkk............',
        '...........mNNNnnnmmm...........',
        '...........NNNNNNNmmm...........',
        '..........mNNNkkkknnn...........',
        '...........mmmmmmmkkkm..........',
        '..........mnnnmnnmkkk...........',
        '...........nNNnnnnmmk...........',
        '.........mNNNNNNNNnmmmm.........',
        '..........NNNNkkkkNnnm..........',
        '.........mNmmmmmmmkkkn..........',
        '..........mnnnmnnmmkkkm.........',
        '.........mnnNNnnnnnmkk..........',
        '........nnNNNnNNNNnnmmkk........',
        '.......mNNNNNNkkkkNNnmmmm.......',
        '........NNNmmkmmmmkkknnm........',
        '.......mNmmnnmmnnmmmkkkn........',
        '........mnnnNnnnnnnnkkkkm.......',
        '......mnnnNNnnNNNNnnmmkkk.......',
        '.......nNNNNNNkkkkNNnmmmk.......',
        '......mNNNNmkkmmmmkkknnmmm......',
        '.......NNmmnmmmnnmmmkkknn.......',
        '......mmmnnnnnnnnnnnkkkkk.......',
        '.....mmnnnNNnnNNNNnnnmkkkkkm....',
        '....mnnnNNNNNNkkkkNNNmmmBBk.....',
        '.....NNNNNNmkkmmmmkkknnmmmm.....',
        '....mNNNNmmnmmmnnmmmmkknnmmm....',
        '.....Nmmmnnnnnnnnnnnmkkkkkn.....',
        '...mmmmnnnNnnnNNNNnnnnkkkkkk....',
        '....nnnnNNNNNNkkkkNNNnmmkkkkm...',
        '...mnNNNNNNkkkmmmmkkkNnmmmmk....',
        '....NNNNNmmmmmmnnmmmmkknnmmm....',
        '...mNNmmmnnmnnnnnnnnmmkkkknnm...',
        '..NNmmBBnnnnnnNNNNnnnnmkkkkknn..',
        '.mmmnnnnBNnNNNkkkkNNNnnmkkkkkk..',
        '..nnnNNNNNNkkkmmmmkkkNNmmmmkkkm.',
        '.mnNNNNNNmkmmmmnnmmmmkknnmmmmk..',
        '..NNNNmmmnmmnnnnnnnnmmmkkknnmm..',
        'mNNNmmmnnnnnnnNNNNnnnnmkkkkknnmm',
        '.NmmnnnnNNnNNNkkkkNNNnnmkkkkkkn.',
        'mmnnnNNNNNNkkkmmmmkkkNNmmmmkkkk.',
        '.nnNNNNNNmkmmmmnnmmmmkknnmmmmkkm',
        'mNNNNNmmmnmmnnTttuunmmmkkknnmmm.',
        '..............Tttuu.............',
        '..............Tttuu.............',
        '..............Tttuu.............',
        '............TTTttuu.............',
        '............TTTttuuuu...........',
        '..........TTTTTttuuuu...........',
    ),
)

# 32x42 dead tree: a heavy bole that forks twice and breaks off short.
# The limbs stay three pixels thick for as long as they are meant to be
# seen — a two-pixel twig is a scratch at 1x and gone entirely under the
# out-of-bounds dimming.
DEAD_TREE_SPRITE = PixelSprite(
    palette=FOREST_PALETTE,
    rows=(
        '............TBu...........Ttu...',
        '............TBu...........Ttu...',
        '............Ttu....Ttu...TTu....',
        '...Ttu......TTtu...Ttu...Ttu....',
        '...TTuu.....TTtu..TTu...TTtu....',
        '....Ttu......Ttu..Ttu...Ttu.....',
        '....TTtu.....Ttu.TTtu..TTtu.....',
        '.....Ttuu....TtuuTtu..TBtu......',
        '......Ttu....TttTTtu.TTtu.......',
        '......Ttuu...TTtTtu.TTtu........',
        '.......Ttuu..TTTTtuTTtuu........',
        '.......BTtuu.TTTTuTTttu.........',
        '........TTtu.TTTtuTttu..........',
        '.........TttuTTTtuTtu...........',
        '.........TTtuuTtuTtuu...........',
        '..........TTtuuTTttu............',
        '...........TttTTttu.............',
        '...........TTtuutu..............',
        '............TTtuuu..............',
        '............TTttuu..............',
        '.............TTtuu..............',
        '.............TTttu..............',
        '.............TTttu..............',
        '.............TTttu..............',
        '.............TTttu..............',
        '.............TTttuu.............',
        '.............TTttuu.............',
        '.............TTttuu.............',
        '.............TBttuu.............',
        '.............TBttuu.............',
        '.............BTttuu.............',
        '.............TTttuu.............',
        '.............TTtttu.............',
        '.............TTtttuu............',
        '.............TTtttuu............',
        '.............TBBttuu............',
        '.............TTtttuu............',
        '.............TTtuuuu............',
        '.............tttuuuu............',
        '...........tttttuuuuuu..........',
        '.........tttttttuuuuuuuu........',
        '.........tttttttuuuuuuuu........',
    ),
)

# 32x17 boulder, sitting low and wide. The dark rim along its foot is
# what plants it — the contact shadow underneath does the rest.
BOULDER_SPRITE = PixelSprite(
    palette=FOREST_PALETTE,
    rows=(
        '..........SSSGGSSsssss..........',
        '........SGGGGSSSSsssssss........',
        '.......SGGSSSSSSsssssssss.......',
        '......SGGSSSSSSSsssssssssv......',
        '.....SGSSSSSSSvvvvssssssvvv.....',
        '....SSSSSSSSSSssssvvvsssvvvv....',
        '...SSSSSSSSSSSsssssssssvvvvvv...',
        '...SSSSSSSSSSssssssssssvvvvvv...',
        '...SSSSSSSSSSsssssssssvvvvvvv...',
        '...SSSSSSSSSsssssssssvvvvvvvv...',
        '..dSSSSSSSSssssssssssvvvvvvvvd..',
        '...SSSSSSSSsssssssssvvvvvvvvv...',
        '...SSSSSSSsssssssssvvvvvvvvvv...',
        '...SSSSSSssssssssssvvvvvvvvvv...',
        '...dSSSSSsssssssssvvvvvvvvvvd...',
        '....dSSSssssssssssvvvvvvvvvd....',
        '.....dddddddddddddddddddddd.....',
    ),
)

# 26x14 stump. The sawn face is an ellipse in the camera's own ratio, so
# it reads as lying flat rather than facing the viewer — the same reason
# every ground circle in the game is flattened.
STUMP_SPRITE = PixelSprite(
    palette=FOREST_PALETTE,
    rows=(
        '..........tttttt..........',
        '.......tttttttttttt.......',
        '....TtttttBBBBBBttttt.....',
        '....TttttBBBBBBBBtttt.....',
        '....TtttttBBBBBBttttt.....',
        '....TTTttttttttttttuu.....',
        '....TTTTTTtttttttuuuu.....',
        '....TTTTTTtttttttuuuu.....',
        '....TTTTTTtttttttuuuu.....',
        '....TTTTTTtttttttuuuu.....',
        '....dTTTTTttttttuuuud.....',
        '.....TTTTTttttttuuuu......',
        '.....TTTTTttttttuuuu......',
        '.....ddddddddddddddd......',
    ),
)

# 22x14 fern. The only prop with no collision circle at all — undergrowth
# is walked through, and it is what keeps the floor between the trunks
# from reading as empty ground.
FERN_SPRITE = PixelSprite(
    palette=FOREST_PALETTE,
    rows=(
        '.........N....N.......',
        '.........N....N.......',
        '.....N................',
        '........nN...Nm...N...',
        '......N.nN...Nm..N....',
        '.....nN.........Nm....',
        '......nN.nN..Nm.......',
        '..N......nn.nm.Nm...N.',
        '...N...nNnn.nm.Nm..N..',
        '...nN..nn.....nm.Nm...',
        '....nNn.nnn.nnm.Nm....',
        '......nnnnnnnmnnm.....',
        '.......nnnnnnnm.......',
        '......nnnnmm.mmm......',
    ),
)
