"""XP curve. No pygame imports."""

import math
from dataclasses import dataclass


def xp_for_next_level(level: int) -> int:
    """XP required to advance FROM the given level to the next one.
    Classic quadratic-ish curve; tune the constants to taste."""
    return math.floor(50 * level ** 1.6 + 50)


@dataclass
class XpGainResult:
    levels_gained: int
    new_level: int
    new_xp: int


def apply_xp_gain(level: int, xp: int, gained: int) -> XpGainResult:
    """Apply an XP gain, handling multiple level-ups in one grant."""
    new_level = level
    new_xp = xp + gained
    levels_gained = 0

    while new_xp >= xp_for_next_level(new_level):
        new_xp -= xp_for_next_level(new_level)
        new_level += 1
        levels_gained += 1

    return XpGainResult(levels_gained, new_level, new_xp)
