"""Base class for boss-rush bosses. Subclasses implement their own AI
state machine in update_ai() and expose damage through two channels
GameScene understands:

- `contact_damage`: non-None while a body-contact attack is active
  (checked by the player/boss collision).
- `poll_area_attack()`: polled every frame for area attacks (breath
  cones, tail sweeps); returns an AreaHit when the player is inside one.

Damage travels the other way through `stun()`: a parried boss stops
acting entirely for a moment (GameScene skips its AI and both damage
channels) while staying solid and fully hittable.
"""

import math
from dataclasses import dataclass
from typing import Optional

import pygame

from core.mathutil import dist
from core.units import SECOND, UNIT
from gfx import camera
from gfx.facing import Turner, create_views
from gfx.pixelart import rgb, scaled, squash_x, tilted, tint_fill, tint_mult
from gfx.walk import Waddle
from settings import WORLD_H, WORLD_W

HIT_FLASH_MS = 0.08 * SECOND
# What a staggered boss is tinted while it is out of the fight: drained
# of its own colour, and deliberately not any of the telegraph flashes —
# a stun is the one boss state that promises the player nothing is
# coming.
STUN_TINT = 0x9E9AA8


@dataclass
class AreaHit:
    damage: float
    # If set, the player is frozen in place for this long when hit.
    freeze_ms: float = 0.0


class Boss:
    display_name = 'Boss'

    def __init__(self, scene, x, y, sprite,
                 scale: float, max_health: float, xp_reward: int):
        self.scene = scene
        self.x = x
        self.y = y
        self.vx = 0.0
        self.vy = 0.0
        # Which way the body is pointing on the plane. Subclasses that
        # already steer by a heading (the wyrm) drive this directly;
        # the rest set it from whatever they are squaring up to. It
        # starts facing the camera so a boss spawns looking at you.
        self.facing_angle = math.pi / 2
        self.views = create_views(sprite)
        self.turner = Turner(self.views)
        self.base_surface = self.views['front']
        self.scale = scale
        # Its place in its stride. Scaled to the body, so a heavier thing
        # takes longer steps and rides higher on them — built from the
        # ground scale, which is the only one it ever walks at.
        self.waddle = Waddle(scale)
        self.max_health = max_health
        self.health = max_health
        self.xp_reward = xp_reward
        # Telegraph tint (multiply, like Phaser setTint); set per frame
        # by update_ai. None = no tint.
        self.tint: Optional[int] = None
        self.alpha = 1.0
        self.hit_flash_ms = 0.0
        self.stun_ms = 0.0
        self.dead = False
        # When False the player passes straight through the body (the
        # dragon in flight — Phaser's checkCollision.none).
        self.collidable = True
        self.casts_shadow = True

    @property
    def ground_lift(self) -> float:
        """Height above the world plane, in screen pixels. Non-zero only
        for bosses that leave the ground; the body is drawn this far up
        while its shadow stays behind at the real position."""
        return 0.0

    @property
    def radius(self) -> float:
        # Half a UNIT is half a 32x32 sprite, so the hitbox follows the
        # art automatically when a boss is scaled up.
        return 0.5 * UNIT * self.scale

    @property
    def display_height(self) -> float:
        return self.base_surface.get_height() * self.scale

    def set_velocity(self, vx: float, vy: float) -> None:
        self.vx = vx
        self.vy = vy

    def update_ai(self, player_x: float, player_y: float, dt_ms: float) -> None:
        """Called every frame by GameScene with the player's position."""
        raise NotImplementedError

    def override_health(self, value: float) -> None:
        """Override max and current health (e.g. god mode)."""
        self.max_health = value
        self.health = value

    @property
    def contact_damage(self) -> Optional[float]:
        """Damage dealt on body contact right now, or None if harmless."""
        return None

    @property
    def is_dodging(self) -> bool:
        """True while the boss has dodge i-frames (take_damage no-ops)."""
        return False

    @property
    def is_walking(self) -> bool:
        """Whether the ground this body is covering is being *walked* —
        feet down, one in front of the other — rather than crossed by a
        dash, a sidestep or a wingbeat. Only a walk gets the walk cycle,
        so a subclass with a committed lunge has to say so; `is_dodging`
        already covers a sidestep and the wyrm's flight."""
        return not self.is_dodging

    @property
    def is_stunned(self) -> bool:
        """True while staggered: GameScene runs no AI for it and lets
        neither damage channel fire, but the body stays solid and takes
        hits as normal — that punish window is the point."""
        return self.stun_ms > 0

    def stun(self, duration_ms: float) -> None:
        """Stagger the boss (the thief's parry). Extending an existing
        stun rather than adding to it keeps a caught flurry from chaining
        into a boss that never moves again."""
        self.stun_ms = max(self.stun_ms, duration_ms)
        self.set_velocity(0, 0)
        self.tint = None
        self.on_stun()

    def on_stun(self) -> None:
        """Cleanup hook: drop whatever attack was mid-swing. Without it a
        boss stunned during a windup resumes the same windup a second
        later, with its telegraph flash long since finished."""

    def on_player_attack(self, player_x: float, player_y: float, ranged: bool) -> None:
        """Notification that the player just started a swing or cast."""

    def poll_area_attack(self, player_x: float, player_y: float) -> Optional[AreaHit]:
        """Polled every frame: is the player being hit by an area attack?"""
        return None

    def take_damage(self, amount: float) -> bool:
        if self.is_dodging:
            return False  # i-frames

        self.health = max(0, self.health - amount)
        self.hit_flash_ms = HIT_FLASH_MS  # flash white on hit

        if self.health <= 0:
            self.dead = True
            self.on_death()
            return True  # died
        return False

    def on_death(self) -> None:
        """Cleanup hook for extra owned visuals (weapons, shards)."""

    def physics_update(self, dt_ms: float) -> None:
        """Integrate velocity, keep the boss inside the arena and out of
        the trees, and let the body catch up to whichever way it is now
        facing and to where it is in its stride."""
        self.hit_flash_ms = max(0.0, self.hit_flash_ms - dt_ms)
        self.stun_ms = max(0.0, self.stun_ms - dt_ms)
        self.turner.update(self.facing_angle, dt_ms)
        dt = dt_ms / 1000
        before = (self.x, self.y)
        self.x += self.vx * dt
        self.y += self.vy * dt
        r = self.radius
        self.x = min(max(self.x, r), WORLD_W - r)
        self.y = min(max(self.y, r), WORLD_H - r)
        # ...and out of the scenery, on the same terms the player is:
        # `collidable` already means "a solid body on the plane", so the
        # wyrm passes over the treetops in flight for free rather than
        # needing to be asked about separately.
        if self.collidable:
            self.x, self.y = self.scene.obstacles.resolve(self.x, self.y, r)
        # The ground it actually covered, and only if that was a walk —
        # so a boss shoved up against the arena edge stops striding
        # rather than marching on the spot.
        walked = dist(*before, self.x, self.y) if self.is_walking else 0.0
        self.waddle.advance(walked, dt_ms)

    @property
    def walk_tilt(self) -> float:
        """Degrees the body is rocked this frame. Nothing while it is
        turning (a body cannot lean and swap sides at once) and nothing
        while it is dodging or airborne — which is also what keeps the
        wyrm's growing takeoff sprite out of `tilted()`'s cache."""
        if self.turner.turning or self.is_dodging:
            return 0.0
        return self.waddle.tilt

    def body_surface(self) -> pygame.Surface:
        surf = scaled(self.turner.surface(), self.scale)
        if self.hit_flash_ms > 0:
            surf = tint_fill(surf, 0xFFFFFF)
        elif self.is_stunned:
            surf = tint_mult(surf, STUN_TINT)
        elif self.tint is not None:
            surf = tint_mult(surf, self.tint)
        # Squash and lean go on after the tints (whose caches key off
        # stable surface ids); the alpha copy below makes a fresh surface
        # every frame, so it has to stay at the end of the chain.
        surf = squash_x(surf, self.turner.squash)
        surf = tilted(surf, self.walk_tilt)
        if self.alpha < 1:
            surf = surf.copy()
            surf.set_alpha(int(255 * self.alpha))
        return surf

    def draw_shadow(self, target: pygame.Surface) -> None:
        """The contact shadow, drawn beneath every body. Stays at the
        boss's real position on the plane no matter how high the body is
        lifted — that gap is how altitude reads."""
        if not self.casts_shadow:
            return
        lift = self.ground_lift
        # Higher up = bigger and fainter, the way a real cast shadow goes.
        spread = 1 + lift / 90
        alpha = int(max(20, 110 - lift * 1.4))
        camera.blit_shadow(target, self.x, self.y, self.radius * spread, alpha)

    def draw(self, target: pygame.Surface) -> None:
        camera.blit_body(target, self.body_surface(), self.x, self.y,
                         self.ground_lift + self.waddle.bob,
                         leaning=bool(self.walk_tilt))
        self.draw_health_bar(target)

    def draw_health_bar(self, target: pygame.Surface) -> None:
        w = 44
        sx, _ = camera.project(self.x, self.y)
        y = round(camera.standing_top(self.y, self.display_height,
                                      self.ground_lift) - 8)
        x = round(sx - w / 2)
        back = pygame.Surface((w, 5), pygame.SRCALPHA)
        back.fill((0, 0, 0, 153))
        target.blit(back, (x, y))
        fill = max(0, int(w * self.health / self.max_health))
        if fill > 0:
            pygame.draw.rect(target, rgb(0xE74C3C), (x, y, fill, 5))
