"""The measuring stick. Every distance, speed, duration and turn rate in
the game is written as a multiple of something in here, so a number in a
config can be read without first working out which space it landed in.

Four quantities in this game are all bare floats, and they are NOT
interchangeable:

    world distance  On the ground plane: positions, ranges, radii, the
                    arena itself. Foreshortened along the depth axis when
                    it is *drawn* (gfx/camera.py), never in the sim.
    screen height   Pixels straight up the screen — how far a held
                    weapon, a projectile or a flying dragon sits ABOVE
                    the plane. The camera tilt does not touch it.
    time            Milliseconds, everywhere in the loop.
    rotation        Radians, and radians per second.

The smoking gun for why this file exists: `PLAYER_RADIUS = 16` is a world
distance and `PLAYER_HAND_LIFT = 16` is a screen height. Same literal,
different dimensions, eleven lines apart, and neither line said so.
Written as `0.5 * UNIT` and `16 * PX` they cannot be read as the same
thing again.

**Nothing here changes a number.** This is how the numbers are *spelled*.
`10 * UNIT` is 320.0, which is what AGGRO_RANGE already was. Awkward
multipliers (`3.125 * UNIT`) are deliberate: they are the honest reading
of a value that was tuned by feel, and rounding them off would be a
balance change wearing a refactor's clothes.

No pygame imports: this is core/, and a unit is data.
"""

import math

# --- world distance ---------------------------------------------------

# The yardstick. One UNIT is the width of a standing 32x32 sprite, which
# is also exactly the player's collision diameter. Chosen because it is
# the thing a player can actually see and judge: "it lunges from two and
# a half units out" is a sentence you can playtest against, "it lunges
# from 80" is not.
UNIT = 32.0

# The floor diamond — the grid the player can count across the arena. A
# world *square*: GameScene._create_floor_patch draws it `TILE` wide and
# `TILE * CAMERA_TILT` tall (to the nearest even pixel, so the pattern
# tiles as the view scrolls), which is what makes it read as lying flat.
# The coarse unit, for arena-scale distances.
TILE = 112.0                    # = 3.5 UNIT

# --- speed ------------------------------------------------------------

# A speed is world distance per second, so it needs no unit of its own:
# `6 * UNIT` as a speed means six unit-widths every second. dt arrives in
# milliseconds and is divided down at the call site, as it already is.

# --- time -------------------------------------------------------------

# The loop counts milliseconds, but durations are legible in seconds.
SECOND = 1000.0
MS = 1.0                        # for the few that really are ~50ms

# --- rotation ---------------------------------------------------------

# A full rotation. Turn rates read as fractions of one: `0.38 * TURN` is
# "just over a third of a full turn per second", where 2.4 rad/s is not.
# Arc half-widths stay in math.radians(degrees) — an arc is an angle a
# designer picks in degrees, not a fraction of a revolution.
TURN = math.tau

# --- screen height ----------------------------------------------------

# Lift: pixels up the screen from a ground point, for anything held or
# flying above the plane. PX is 1.0 and does nothing at runtime — it
# exists to be *written*, so that a screen height is visibly not a world
# distance at the point where someone is reading it.
PX = 1.0
