"""Native (MiSTer/PC) client transport: a background thread reads the WebSocket
and keeps the latest two snapshots for interpolation, while the game loop stays
synchronous -- it just reads `snapshot`/`prev` and calls `send_input`. Stdlib
sockets only, so it runs on the MiSTer. The browser (pygbag) build swaps this for
a JS-WebSocket transport exposing the same `snapshot`/`send_input` surface.
"""
from __future__ import annotations

import base64
import json
import os
import socket
import ssl
import struct
import threading
import time

from . import ws


class NetClient:
    def __init__(self, host: str, port: int, pid: str, class_id: str,
                 room: str = "", ticket: str = "", *, tls: bool = False):
        self.host = host
        self.port = port
        self.pid = pid
        self.class_id = class_id
        self.room = room
        self.ticket = ticket
        self.tls = tls
        self.sock: socket.socket | None = None

        self.you = pid
        self.started = False
        self.ended = None            # winner pid once the match is over
        self.roster: list[str] = []
        self.running = False

        self._lock = threading.Lock()
        self.snapshot = None         # most recent snapshot dict
        self.prev = None             # the one before it (for interpolation)
        self.snap_at = 0.0           # monotonic time the latest arrived
        self.error = None

    # -- lifecycle ------------------------------------------------------------
    def connect(self, timeout: float = 10.0) -> None:
        raw = socket.create_connection((self.host, self.port), timeout=timeout)
        self.sock = ssl.create_default_context().wrap_socket(
            raw, server_hostname=self.host) if self.tls else raw
        self._handshake()
        self._send({"t": "join", "room": self.room, "pid": self.pid,
                    "ticket": self.ticket, "class": self.class_id})
        self.running = True
        threading.Thread(target=self._rx, daemon=True).start()

    def close(self) -> None:
        self.running = False
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass

    # -- outgoing -------------------------------------------------------------
    def send_input(self, move, aim, attack: bool, dodge: bool = False, guard: bool = False) -> None:
        try:
            self._send({"t": "input", "mv": [move[0], move[1]], "aim": aim,
                        "atk": bool(attack), "dg": bool(dodge), "gd": bool(guard)})
        except OSError:
            self.running = False

    def _send(self, obj) -> None:
        self.sock.sendall(ws.encode(json.dumps(obj), mask=True))

    # -- snapshot access (called from the render loop) ------------------------
    def interpolated(self):
        """(players_by_id, alpha) where alpha 0..1 blends prev->snapshot for
        smooth motion between 30Hz snapshots. Falls back to the latest alone."""
        with self._lock:
            cur, prev, at = self.snapshot, self.prev, self.snap_at
        if cur is None:
            return None, None, 0.0
        return cur, prev, at

    # -- handshake + read loop ------------------------------------------------
    def _handshake(self) -> None:
        key = base64.b64encode(os.urandom(16)).decode()
        req = (
            f"GET / HTTP/1.1\r\nHost: {self.host}\r\n"
            "Upgrade: websocket\r\nConnection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(req.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = self.sock.recv(1024)
            if not chunk:
                raise ConnectionError("closed during handshake")
            buf += chunk

    def _recv_exact(self, n: int) -> bytes:
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("closed")
            buf += chunk
        return buf

    def _read_frame(self):
        h = self._recv_exact(2)
        opcode = h[0] & 0x0F
        masked = h[1] & 0x80
        ln = h[1] & 0x7F
        if ln == 126:
            ln = struct.unpack(">H", self._recv_exact(2))[0]
        elif ln == 127:
            ln = struct.unpack(">Q", self._recv_exact(8))[0]
        mask = self._recv_exact(4) if masked else b"\x00\x00\x00\x00"
        data = bytearray(self._recv_exact(ln))
        if masked:
            for i in range(ln):
                data[i] ^= mask[i % 4]
        return opcode, bytes(data)

    def _rx(self) -> None:
        try:
            while self.running:
                op, data = self._read_frame()
                if op == ws.OP_CLOSE:
                    break
                if op == ws.OP_PING:
                    self.sock.sendall(ws.encode(data, mask=True, opcode=ws.OP_PONG))
                    continue
                if op != ws.OP_TEXT:
                    continue
                m = json.loads(data)
                t = m.get("t")
                if t == "joined":
                    self.roster = m.get("roster", [])
                elif t == "start":
                    self.you = m.get("you", self.pid)
                    self.started = True
                elif t == "snap":
                    with self._lock:
                        self.prev = self.snapshot
                        self.snapshot = m["s"]
                        self.snap_at = time.monotonic()
                elif t == "end":
                    self.ended = m.get("winner")
                    break
        except (ConnectionError, OSError, json.JSONDecodeError, KeyError) as e:
            self.error = repr(e)
        finally:
            self.running = False
