"""Outlined text rendering. Uses pygame's bundled default font so the
same code works native and under pygbag (no system font lookups)."""

from __future__ import annotations  # defer annotations so importing this module

# doesn't require libSDL2_ttf (pygame.font) until a font is actually built --
# lets a headless server import it without the ttf lib present.
from typing import Dict, Tuple

import pygame

import settings
from . import platform
from .pixelart import rgb


def _text_scale() -> float:
    """Shrink all text on low-resolution displays (e.g. 320-wide on a 240p
    MiSTer CRT) so HUD/labels/floating text stay in proportion. 1.0 at 1280
    wide, so PC/web are unchanged. Read live from settings so a launcher that
    patches the resolution before import is honoured."""
    return max(0.28, settings.WIDTH / 1280.0)

_fonts: Dict[int, pygame.font.Font] = {}
_render_cache: Dict[tuple, pygame.Surface] = {}
_dummy: pygame.Surface | None = None


def _headless_dummy() -> pygame.Surface:
    """A 1x1 surface returned instead of rendered text on a headless server
    (never drawn) -- avoids building font surfaces and needing libSDL2_ttf."""
    global _dummy
    if _dummy is None:
        _dummy = pygame.Surface((1, 1), pygame.SRCALPHA)
    return _dummy


def get_font(px: int) -> pygame.font.Font:
    # The default font runs a bit small next to CSS px sizes; scale up
    # slightly so the layout matches the Phaser original.
    if settings.WIDTH < 640:
        # 240p: snap to an 8px body / 16px heading grid. 8 is the classic
        # pixel-font height and 16 doubles it exactly, so both stay crisp and
        # pixel-perfect when the 320-wide frame is scaled 2x to the display.
        size = 16 if px > 18 else 8
    else:
        size = int(px * 1.4)
    font = _fonts.get(size)
    if font is None:
        font = pygame.font.Font(None, size)
        _fonts[size] = font
    return font


def render_text(text: str, px: int, color, outline: int = 2,
                outline_color: Tuple[int, int, int] = (0, 0, 0)) -> pygame.Surface:
    """Render one line of text with a black outline (Phaser stroke)."""
    if platform.IS_HEADLESS:
        return _headless_dummy()
    if isinstance(color, int):
        color = rgb(color)
    key = (text, px, color, outline, outline_color)
    cached = _render_cache.get(key)
    if cached is not None:
        return cached

    font = get_font(px)
    base = font.render(text, True, color)
    if outline > 0:
        outline = max(1, round(outline * _text_scale()))   # keep the stroke in proportion
    if outline <= 0:
        _render_cache[key] = base
        return base

    shadow = font.render(text, True, outline_color)
    surf = pygame.Surface((base.get_width() + outline * 2, base.get_height() + outline * 2),
                          pygame.SRCALPHA)
    for dx in (-outline, 0, outline):
        for dy in (-outline, 0, outline):
            if dx or dy:
                surf.blit(shadow, (outline + dx, outline + dy), special_flags=platform.ALPHA_BLIT)
    surf.blit(base, (outline, outline), special_flags=platform.ALPHA_BLIT)

    if len(_render_cache) > 512:  # HUD text changes every frame; keep the cache bounded
        _render_cache.clear()
    _render_cache[key] = surf
    return surf


def draw_text(target: pygame.Surface, text: str, px: int, color,
              x: float, y: float, anchor: str = 'topleft', outline: int = 2) -> pygame.Rect:
    surf = render_text(text, px, color, outline)
    rect = surf.get_rect(**{anchor: (round(x), round(y))})
    target.blit(surf, rect)
    return rect


def wrap_lines(text: str, px: int, max_width: int):
    """Greedy word wrap using the actual font metrics."""
    font = get_font(px)
    words = text.split(' ')
    lines, current = [], ''
    for word in words:
        candidate = f'{current} {word}'.strip()
        if font.size(candidate)[0] <= max_width or not current:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines
