"""Small self-updating visual effects — the pygame stand-in for
Phaser's tweens. Each effect gets update(dt_ms) -> bool (alive) and
draw(surface); the scene owns a list and sweeps dead ones.

Effects hold **world** coordinates and project when they draw. Set
`ground = True` on anything that lies flat on the plane (swing arcs,
breath cones): the scene draws those beneath every body, which is most
of what sells the tilted camera."""

import math

import pygame

from gfx import camera, platform
from gfx.pixelart import draw_pointing, rgb
from gfx.text import render_text
from settings import WIDTH


def ease_out_cubic(t: float) -> float:
    """Fast off the mark, settling at the end — how a swung or raised
    object moves. Shared with the scene, which raises the knight's
    shield on the same curve its weapons swing on."""
    return 1 - (1 - t) ** 3


class Effect:
    # True = a decal on the ground plane, drawn under all bodies.
    ground = False

    def update(self, dt_ms: float) -> bool:
        raise NotImplementedError

    def draw(self, target: pygame.Surface) -> None:
        raise NotImplementedError


class FloatingText(Effect):
    """Text that rises 40px and fades out (level ups, YOU DIED, etc.)."""

    def __init__(self, x, y, text, px, color, duration_ms=1200):
        self.surf = render_text(text, px, color, outline=3)
        self.x, self.y = x, y
        self.duration = duration_ms
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.duration

    def draw(self, target):
        t = min(1.0, self.elapsed / self.duration)
        surf = self.surf.copy()
        surf.set_alpha(int(255 * (1 - t)))
        sx, sy = camera.project(self.x, self.y)
        target.blit(surf, surf.get_rect(center=(round(sx), round(sy - 40 * t))),
                    special_flags=platform.ALPHA_BLIT)


class BossAnnounce(Effect):
    """Boss name fading in, holding, fading out at the top of the arena."""

    FADE_MS = 400
    HOLD_MS = 1200

    def __init__(self, name):
        self.surf = render_text(name, 30, 0xECF0F1, outline=3)
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.FADE_MS * 2 + self.HOLD_MS

    def draw(self, target):
        if self.elapsed < self.FADE_MS:
            alpha = self.elapsed / self.FADE_MS
        elif self.elapsed < self.FADE_MS + self.HOLD_MS:
            alpha = 1.0
        else:
            alpha = max(0.0, 1 - (self.elapsed - self.FADE_MS - self.HOLD_MS) / self.FADE_MS)
        surf = self.surf.copy()
        surf.set_alpha(int(255 * alpha))
        target.blit(surf, surf.get_rect(center=(WIDTH // 2, 120)),
                    special_flags=platform.ALPHA_BLIT)


class Explosion(Effect):
    """Expanding, fading burst (fireball impact/fizzle). A ball in the
    air, not a decal — it stays circular (a sphere projects to a circle
    from any camera angle) and is lifted to the height it went off at."""

    def __init__(self, x, y, radius, color=0xE67E22, duration_ms=180, lift=0.0):
        self.x, self.y = x, y
        self.radius = radius
        self.color = rgb(color)
        self.duration = duration_ms
        self.lift = lift
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.duration

    def draw(self, target):
        t = min(1.0, self.elapsed / self.duration)
        r = max(1, int(self.radius * (1 + t)))  # scale 1 -> 2
        alpha = int(255 * 0.6 * (1 - t))
        surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        pygame.draw.circle(surf, self.color + (alpha,), (r, r), r)
        camera.blit_flat(target, surf, self.x, self.y, self.lift)


class ArcTrail(Effect):
    """A filled arc sector that fades out — the swing/breath trail. Built
    in world units and flattened once, so the ellipse it draws is exactly
    the projection of the circle the hit check uses."""

    ground = True

    def __init__(self, x, y, radius, angle, half_arc, color, base_alpha, duration_ms):
        r = int(radius)
        surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        steps = max(8, int(half_arc * 2 / 0.15))
        points = [(r, r)]
        for i in range(steps + 1):
            a = angle - half_arc + (half_arc * 2) * i / steps
            points.append((r + r * math.cos(a), r + r * math.sin(a)))
        pygame.draw.polygon(surf, rgb(color), points)
        self.surf = camera.flatten(surf)
        self.x, self.y = x, y
        self.base_alpha = base_alpha
        self.duration = duration_ms
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.duration

    def draw(self, target):
        t = min(1.0, self.elapsed / self.duration)
        self.surf.set_alpha(int(255 * self.base_alpha * (1 - t)))
        camera.blit_flat(target, self.surf, self.x, self.y)


class WeaponSweep(Effect):
    """Sweep a weapon sprite through an arc around its owner, eased.
    `pos_fn` is polled live so the weapon follows a moving owner."""

    def __init__(self, pos_fn, weapon_surf, angle, half_arc, grip_radius,
                 duration_ms, lift=0.0):
        self.pos_fn = pos_fn
        self.weapon = weapon_surf
        self.angle = angle
        self.half_arc = half_arc
        self.grip = grip_radius
        self.duration = duration_ms
        self.lift = lift
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.duration

    def draw(self, target):
        t = ease_out_cubic(min(1.0, self.elapsed / self.duration))
        a = self.angle + (-1 + 2 * t) * self.half_arc
        x, y = self.pos_fn()
        # The grip travels a circle on the plane (so it projects to an
        # ellipse), but the weapon is a held object, not a decal — it
        # rotates by the *apparent* angle, not the world one.
        gx, gy = camera.project(x + math.cos(a) * self.grip,
                                y + math.sin(a) * self.grip)
        draw_pointing(target, self.weapon, gx, gy - self.lift,
                      camera.project_angle(a))


class GroundFlare(Effect):
    """An expanding, fading disc of light lying on the plane — the mark a
    teleport leaves at both ends of the jump.

    A decal, so it is drawn *under* the bodies: light spilling across the
    floor rather than a bloom painted over the sprite that is standing
    in it. Flattened, because a circle on the ground projects to an
    ellipse under this camera."""

    ground = True

    def __init__(self, x, y, radius, color, base_alpha=0.75, duration_ms=260):
        r = int(radius)
        surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        # Radial falloff, drawn rim-inward. A flat fill at this size just
        # reads as a puddle of paint on the floor; light has a hot centre.
        rgb_color = rgb(color)
        for i in range(r, 0, -1):
            t = 1 - i / r                      # 0 at the rim, ~1 at the centre
            pygame.draw.circle(surf, rgb_color + (int(255 * t ** 2),),
                               (r, r), i)
        self.surf = camera.flatten(surf)
        self.x, self.y = x, y
        self.base_alpha = base_alpha
        self.duration = duration_ms
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.duration

    def draw(self, target):
        t = min(1.0, self.elapsed / self.duration)
        w = max(1, int(self.surf.get_width() * (1 + t * 0.8)))
        h = max(1, int(self.surf.get_height() * (1 + t * 0.8)))
        img = platform.smoothscale(self.surf, (w, h))
        img.set_alpha(int(255 * self.base_alpha * (1 - t)))
        camera.blit_flat(target, img, self.x, self.y)


class Barrier(Effect):
    """The prelate's ward: a sphere of light standing around him for as
    long as it holds.

    Deliberately NOT flattened — a ball in the air projects to a circle
    from any camera angle (same reasoning as Explosion), and a flattened
    one would read as a puddle he is standing in rather than something
    he is standing inside. Lifted to chest height for the same reason.

    `pos_fn` is polled live, so the ward travels with him — including
    through a blink, which lands him elsewhere still warded."""

    def __init__(self, pos_fn, radius, color, duration_ms, lift=0.0):
        self.pos_fn = pos_fn
        self.radius = int(radius)
        self.color = rgb(color)
        self.duration = duration_ms
        self.lift = lift
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.duration

    def draw(self, target):
        t = min(1.0, self.elapsed / self.duration)
        # It pulses while it holds and thins out over the last quarter,
        # so the seconds running out are something the player can see
        # rather than something they have to count.
        fade = 1.0 if t < 0.75 else (1 - t) / 0.25
        pulse = 0.8 + 0.2 * math.sin(self.elapsed / 90)
        r = self.radius
        surf = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
        centre = (r + 1, r + 1)
        pygame.draw.circle(surf, self.color + (int(38 * fade),), centre, r)
        pygame.draw.circle(surf, self.color + (int(210 * fade * pulse),), centre, r, 2)
        x, y = self.pos_fn()
        camera.blit_flat(target, surf, x, y, self.lift)


class Afterimage(Effect):
    """A body's own sprite left standing where it used to be, fading out
    — what makes a teleport read as "was there, is here" instead of as a
    body that skipped. Blitted standing, so the ghost's feet stay on the
    ground point it vanished from.

    The surface is copied once up front because `set_alpha` mutates it
    and the caller's is a cached, shared one."""

    def __init__(self, surf, x, y, duration_ms=220, start_alpha=0.4):
        self.surf = surf.copy()
        self.x, self.y = x, y
        self.duration = duration_ms
        self.start_alpha = start_alpha
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.duration

    def draw(self, target):
        t = min(1.0, self.elapsed / self.duration)
        self.surf.set_alpha(int(255 * self.start_alpha * (1 - t)))
        camera.blit_standing(target, self.surf, self.x, self.y)


class LerpParticle(Effect):
    """A sprite lerping from A to B while growing and fading — the
    flame/ice-shard breath particles."""

    def __init__(self, surf, x0, y0, x1, y1, scale0, scale1, duration_ms, lift=0.0):
        self.surf = surf
        self.x0, self.y0, self.x1, self.y1 = x0, y0, x1, y1
        self.scale0, self.scale1 = scale0, scale1
        self.duration = duration_ms
        self.lift = lift
        self.elapsed = 0.0

    def update(self, dt_ms):
        self.elapsed += dt_ms
        return self.elapsed < self.duration

    def draw(self, target):
        t = min(1.0, self.elapsed / self.duration)
        x = self.x0 + (self.x1 - self.x0) * t
        y = self.y0 + (self.y1 - self.y0) * t
        scale = self.scale0 + (self.scale1 - self.scale0) * t
        w = max(1, int(self.surf.get_width() * scale))
        h = max(1, int(self.surf.get_height() * scale))
        img = pygame.transform.scale(self.surf, (w, h))
        img.set_alpha(int(255 * (1 - t)))
        # Breath particles travel *over* the plane, so they keep their
        # own shape and only their position is projected.
        camera.blit_flat(target, img, x, y, self.lift)
