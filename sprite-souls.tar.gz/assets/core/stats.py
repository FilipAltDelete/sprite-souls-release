"""Primary attributes and derived combat stats. No pygame imports —
this layer stays pure so it can be unit-tested and serialized."""

from dataclasses import dataclass


@dataclass
class Attributes:
    strength: float
    dexterity: float
    intelligence: float
    vitality: float

    def copy(self) -> "Attributes":
        return Attributes(self.strength, self.dexterity, self.intelligence, self.vitality)


@dataclass
class DerivedStats:
    max_health: float
    max_mana: float
    attack_damage: float
    attack_speed: float  # attacks per second
    move_speed: float  # world units per second (core/units.UNIT)
    spell_power: float  # damage of spells (fireball etc.)
    mana_regen: float  # mana per second


def compute_derived_stats(attrs: Attributes, level: int) -> DerivedStats:
    """Turn raw attributes into combat stats. Tune these formulas freely —
    keeping them in one place makes balancing much easier later.

    These deliberately stay in raw world units rather than multiples of
    core.units.UNIT: they are tuning *curves*, not design statements, and
    `180 + dex` says what it does where `(5.625 + dex * 0.03125) * UNIT`
    would only obscure it. For reference, 180 is 5.6 UNIT/s."""
    return DerivedStats(
        max_health=40 + attrs.vitality * 6 + level * 4,
        max_mana=10 + attrs.intelligence * 4 + level * 2,
        attack_damage=4 + attrs.strength * 1.5 + attrs.dexterity * 0.5,
        attack_speed=1 + attrs.dexterity * 0.02,
        move_speed=180 + attrs.dexterity * 1.0,
        spell_power=4 + attrs.intelligence * 1.3,
        mana_regen=1 + attrs.intelligence * 0.12,
    )
