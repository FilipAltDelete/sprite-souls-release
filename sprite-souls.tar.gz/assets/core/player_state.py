"""The pure data/logic side of the player: class, level, attributes, XP.
Deliberately has no pygame dependency so it stays easy to test and to
serialize into save files later."""

from .classes import CharacterClass
from .stats import DerivedStats, compute_derived_stats
from .xp import apply_xp_gain, xp_for_next_level


class PlayerState:
    def __init__(self, character_class: CharacterClass):
        self.character_class = character_class
        self.level = 1
        self.xp = 0
        self.attributes = character_class.base_attributes.copy()
        self.health = self.derived_stats.max_health
        self.mana = self.derived_stats.max_mana

    @property
    def derived_stats(self) -> DerivedStats:
        stats = compute_derived_stats(self.attributes, self.level)
        stats.move_speed *= self.character_class.move_speed_multiplier
        return stats

    @property
    def xp_to_next_level(self) -> int:
        return xp_for_next_level(self.level)

    def take_damage(self, amount: float) -> bool:
        """Apply damage; returns True if the player died."""
        self.health = max(0, self.health - amount)
        return self.health <= 0

    def spend_mana(self, cost: float) -> bool:
        """Try to pay a mana cost; returns False if there isn't enough."""
        if self.mana < cost:
            return False
        self.mana -= cost
        return True

    def regenerate(self, dt_seconds: float) -> None:
        """Per-frame regeneration tick."""
        stats = self.derived_stats
        self.mana = min(stats.max_mana, self.mana + stats.mana_regen * dt_seconds)

    def restore(self) -> None:
        """Fully restore health and mana (level-up, respawn)."""
        self.health = self.derived_stats.max_health
        self.mana = self.derived_stats.max_mana

    def gain_xp(self, amount: int) -> int:
        """Grant XP; returns the number of levels gained (0 if none)."""
        result = apply_xp_gain(self.level, self.xp, amount)
        self.xp = result.new_xp

        for _ in range(result.levels_gained):
            self.level += 1
            growth = self.character_class.growth_per_level
            self.attributes.strength += growth.strength
            self.attributes.dexterity += growth.dexterity
            self.attributes.intelligence += growth.intelligence
            self.attributes.vitality += growth.vitality

        if result.levels_gained > 0:
            # Level-ups fully restore the character, Diablo-style.
            self.restore()

        return result.levels_gained
