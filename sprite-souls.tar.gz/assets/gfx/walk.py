"""The cut-out walk cycle — the waddle every body in this game moves
with.

A `Waddle` is one body's place in its stride and nothing else: feed it
the ground it actually covered this frame, and it hands back a lean and
a bounce. It draws nothing and imports no pygame; `pixelart.tilted()`
rocks the sprite about its feet and `camera.blit_body()` plants it.

Two decisions are baked in here rather than left to callers:

- **The stride advances by distance travelled, never by time.** A stride
  is a stride, so a knight shuffling behind his shield paces himself and
  a thief's faster feet take faster steps, without either being told.
  Pass 0 for a body standing still — or one being carried by something
  that is not a walk, like a roll or a lunge — and it eases out on its
  own.
- **The lean is quantised and the bounce is whole pixels.** That is the
  cut-out look (poses, not smooth rotation) and it is also the only
  thing holding `tilted()`'s cache down: it caches per pose per surface,
  so a continuous angle would cache a surface per degree per frame.

A caller that has a turn animation must also hold the lean at zero while
that runs — a body cannot lean and swap sides in the same frame without
looking broken. That rule lives at the call site because only the caller
knows it is turning.
"""

import math

from core.units import PX, SECOND, UNIT

# Ground covered per two-step cycle, for a body one UNIT across.
STRIDE = 1.5 * UNIT
# How far the body rocks either way. Judged by rendering: much under
# this is a sway rather than a waddle, much over and the rotation starts
# eating the outline of a 32px sprite — a capirote at 12 degrees comes
# back visibly chewed.
TILT_DEG = 9.0
# The lean is rounded to whole steps of this.
TILT_STEP = 3.0
# How high the bounce goes, in screen pixels, for a body one UNIT tall.
BOB = 3 * PX
# How quickly the waddle starts and stops. Without it, tapping a
# direction key snaps the body to a full lean and back.
EASE_MS = 0.12 * SECOND


class Waddle:
    """Where a body is in its stride, and how much of the walk is
    showing. `scale` stretches the stride and the bounce to the size of
    the body — a bigger thing takes longer steps and rides higher on
    them — while the lean stays the same angle, because a lean is a lean
    whatever size you are."""

    def __init__(self, scale: float = 1.0):
        self.stride = STRIDE * scale
        self.bob_height = BOB * scale
        self.phase = 0.0
        self.amount = 0.0

    def advance(self, distance: float, dt_ms: float) -> None:
        """Carry the stride forward by the ground actually covered."""
        if distance > 0:
            self.phase += (distance / self.stride) * math.tau
            self.amount = min(1.0, self.amount + dt_ms / EASE_MS)
        else:
            self.amount = max(0.0, self.amount - dt_ms / EASE_MS)
            if self.amount == 0.0:
                # Every walk sets off on the same foot rather than
                # picking up wherever the last one happened to stop.
                self.phase = 0.0

    @property
    def tilt(self) -> float:
        """Degrees the body is rocked this frame: it leans onto whichever
        foot is down, once each way per stride."""
        lean = TILT_DEG * self.amount * math.sin(self.phase)
        return round(lean / TILT_STEP) * TILT_STEP

    @property
    def bob(self) -> float:
        """Screen pixels the body is lifted this frame: the bounce, which
        comes twice a stride because there are two feet. Whole pixels — a
        body made of pixels does not hover between them."""
        return round(self.bob_height * self.amount * abs(math.sin(self.phase)))
