"""Authoritative game service: one long-running Python process on the API host
that hosts many matches at once, each in its own room. The .NET API does NOT
spawn a process per match -- it calls this service's control endpoint to CREATE
a room (handing over the authoritative roster/specs/seed), then points the two
players at it. Clients WebSocket-connect to their room, prove their identity with
a ticket, and send input only; the server owns every attribute, so stats can't be
faked. When a match ends the room reports the outcome back to the API and closes.

Two asyncio listeners:
  * control (HTTP, internal, .NET -> service):  POST /match  {roomId, players,
      specs, seed, bestOf, tickets, resultUrl, token, tickHz}
  * game (WebSocket, clients -> service):        join {room, pid, ticket, class}
      then input {mv, aim, atk}; server -> snap {s}, start, end.
"""
from __future__ import annotations

import asyncio
import json

from core.arena import Intent, Match, MatchConfig

from . import ws


class Room:
    """One match: its clients, their latest intents, the sim, and the tick loop."""

    def __init__(self, service, room_id, cfg):
        self.service = service
        self.room_id = room_id
        self.cfg = cfg                       # dict: players, specs, seed, bestOf, tickets, resultUrl, token, tickHz, density
        self.tick_ms = 1000.0 / cfg.get("tickHz", 30)
        self.writers = {}                    # pid -> StreamWriter
        self.intents = {}                    # pid -> Intent
        self.match = None
        self._started = False
        self.finished = asyncio.Event()

    def _valid(self, pid, ticket):
        if pid not in self.cfg["players"]:
            return False
        want = self.cfg.get("tickets", {}).get(pid)
        return want is None or want == ticket      # ticket check when the API set one

    async def add_client(self, pid, ticket, reader, writer):
        if not self._valid(pid, ticket):
            await _send(writer, {"t": "error", "reason": "bad ticket"})
            return
        self.writers[pid] = writer
        self.intents.setdefault(pid, Intent())
        await _send(writer, {"t": "joined", "pid": pid, "roster": list(self.cfg["players"])})
        if not self._started and set(self.writers) >= set(self.cfg["players"]):
            self._started = True
            asyncio.create_task(self._run())
        await self._input_loop(pid, reader, writer)

    async def _input_loop(self, pid, reader, writer):
        try:
            while True:
                op, data = await ws.read_frame(reader)
                if op == ws.OP_CLOSE:
                    break
                if op == ws.OP_PING:
                    writer.write(ws.encode(data, mask=False, opcode=ws.OP_PONG))
                    await writer.drain()
                    continue
                if op != ws.OP_TEXT:
                    continue
                m = json.loads(data)
                if m.get("t") == "input" and pid in self.intents:
                    self.intents[pid] = Intent(
                        move=tuple(m.get("mv", (0.0, 0.0))),
                        aim=m.get("aim"),
                        attack=bool(m.get("atk")),
                        dodge=bool(m.get("dg")),
                        guard=bool(m.get("gd")))
        except (asyncio.IncompleteReadError, ConnectionError, json.JSONDecodeError):
            pass
        finally:
            self.writers.pop(pid, None)

    async def _broadcast(self, obj):
        frame = ws.encode(json.dumps(obj), mask=False)
        for w in list(self.writers.values()):
            try:
                w.write(frame)
                await w.drain()
            except (ConnectionError, RuntimeError):
                pass

    async def _run(self):
        self.match = Match(MatchConfig(
            players=dict(self.cfg["players"]),
            best_of=int(self.cfg.get("bestOf", 5)),
            density=float(self.cfg.get("density", 0.15)),
            seed=int(self.cfg.get("seed", 0)),
            specs=dict(self.cfg.get("specs", {})),      # authoritative attributes from the API
        ))
        for pid, w in self.writers.items():
            await _send(w, {"t": "start", "you": pid, "best_of": self.match.cfg.best_of})
        try:
            while not self.match.over:
                for pid, intent in self.intents.items():
                    self.match.set_intent(pid, intent)
                self.match.tick(self.tick_ms)
                await self._broadcast({"t": "snap", "s": self.match.snapshot()})
                await asyncio.sleep(self.tick_ms / 1000.0)
            await self._broadcast({"t": "end", "winner": self.match.winner})
            await asyncio.get_event_loop().run_in_executor(None, self._report)
        finally:
            self.finished.set()
            self.service.rooms.pop(self.room_id, None)

    def _report(self):
        url = self.cfg.get("resultUrl")
        if not url or self.match is None:
            return
        import urllib.request
        snap = self.match.snapshot()
        payload = json.dumps({
            "token": self.cfg.get("token", ""),
            "roomId": self.room_id,
            "lobbyId": self.cfg.get("lobbyId", ""),
            "gameType": "spritesouls",
            "winner": self.match.winner,
            "players": [{"pid": p["id"], "wins": p["wins"],
                         "isWinner": p["id"] == self.match.winner} for p in snap["players"]],
        }).encode()
        req = urllib.request.Request(url, data=payload,
                                     headers={"Content-Type": "application/json"}, method="POST")
        try:
            urllib.request.urlopen(req, timeout=10).read()
        except Exception:
            pass


class MatchService:
    def __init__(self, control_token: str = ""):
        self.rooms = {}
        self.control_token = control_token       # optional shared secret for the control endpoint

    def create_room(self, room_id, cfg):
        self.rooms[room_id] = Room(self, room_id, cfg)

    # -- game (WebSocket clients) ---------------------------------------------
    async def handle_ws(self, reader, writer):
        try:
            await ws.server_handshake(reader, writer)
            op, data = await ws.read_frame(reader)
            m = json.loads(data)
            if m.get("t") != "join":
                writer.close()
                return
            room = self.rooms.get(str(m.get("room")))
            if room is None:
                await _send(writer, {"t": "error", "reason": "no such room"})
                writer.close()
                return
            await room.add_client(str(m["pid"]), m.get("ticket"), reader, writer)
        except (asyncio.IncompleteReadError, ConnectionError, json.JSONDecodeError, KeyError):
            pass
        finally:
            try:
                writer.close()
            except Exception:
                pass

    # -- control (internal HTTP from .NET) ------------------------------------
    async def handle_control(self, reader, writer):
        try:
            req = b""
            while b"\r\n\r\n" not in req:
                chunk = await reader.read(2048)
                if not chunk:
                    return
                req += chunk
            head, _, rest = req.partition(b"\r\n\r\n")
            headers = head.decode("latin1")
            length = 0
            token = ""
            for line in headers.split("\r\n"):
                low = line.lower()
                if low.startswith("content-length:"):
                    length = int(line.split(":", 1)[1].strip())
                elif low.startswith("x-control-token:"):
                    token = line.split(":", 1)[1].strip()
            body = bytearray(rest)
            while len(body) < length:
                body += await reader.read(length - len(body))
            ok = ("POST /match" in headers.split("\r\n", 1)[0]
                  and (not self.control_token or token == self.control_token))
            if ok:
                cfg = json.loads(bytes(body))
                self.create_room(str(cfg["roomId"]), cfg)
                resp_body = b'{"ok":true}'
                status = "200 OK"
            else:
                resp_body = b'{"ok":false}'
                status = "400 Bad Request"
            writer.write((f"HTTP/1.1 {status}\r\nContent-Type: application/json\r\n"
                          f"Content-Length: {len(resp_body)}\r\nConnection: close\r\n\r\n").encode() + resp_body)
            await writer.drain()
        except Exception:
            pass
        finally:
            try:
                writer.close()
            except Exception:
                pass

    async def serve(self, ws_port: int = 8765, control_port: int = 8764,
                    host: str = "0.0.0.0", control_host: str = "127.0.0.1"):
        # control_host defaults to loopback (safe for a standalone run on the API
        # host); a containerised deploy sets it to 0.0.0.0 so a sibling `api`
        # service can reach it over the compose network. It is never published to
        # the host and is guarded by SS_CONTROL_TOKEN.
        game = await asyncio.start_server(self.handle_ws, host, ws_port)
        ctrl = await asyncio.start_server(self.handle_control, control_host, control_port)
        async with game, ctrl:
            await asyncio.gather(game.serve_forever(), ctrl.serve_forever())


async def _send(writer, obj):
    writer.write(ws.encode(json.dumps(obj), mask=False))
    await writer.drain()


if __name__ == "__main__":
    import os
    svc = MatchService(control_token=os.environ.get("SS_CONTROL_TOKEN", ""))
    asyncio.run(svc.serve(
        ws_port=int(os.environ.get("SS_GAME_PORT", "8765")),
        control_port=int(os.environ.get("SS_CONTROL_PORT", "8764")),
        control_host=os.environ.get("SS_CONTROL_HOST", "127.0.0.1"),
    ))
